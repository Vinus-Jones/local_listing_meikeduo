/**
 * Token消耗配置
 * 定义不同模型的token消耗量
 */

export const TOKEN_CONFIG = {
  // 每张图片的token消耗量（假设值，可根据实际情况调整）
  models: {
    'default': {
      name: '标准模型',
      tokensPerImage: 50, // 每张图片消耗50 tokens
      description: '性价比高，适合日常使用'
    },
    'high-quality': {
      name: '高清模型',
      tokensPerImage: 125, // 每张图片消耗125 tokens（约0.05元）
      description: '画质更清晰，细节更丰富'
    },
    'ultra-quality': {
      name: '超清模型',
      tokensPerImage: 250, // 每张图片消耗250 tokens（约0.10元）
      description: '最高画质，适合商业用途'
    },
    'fast': {
      name: '快速模型',
      tokensPerImage: 12, // 每张图片消耗12 tokens（约0.005元）
      description: '生成速度快，适合快速预览'
    }
  },

  // Token与人民币的换算比例（假设值）
  tokensPerYuan: 2500 // 1元 = 2500 tokens

} as const;

/**
 * 获取模型的token消耗量
 */
export function getTokensForModel(modelId: string): number {
  return TOKEN_CONFIG.models[modelId as keyof typeof TOKEN_CONFIG.models]?.tokensPerImage || 50;
}

/**
 * 计算总token消耗量
 */
export function calculateTotalTokens(modelId: string, versionCount: number): number {
  return getTokensForModel(modelId) * versionCount;
}

/**
 * 格式化token显示
 */
export function formatTokens(tokens: number): string {
  if (tokens >= 1000) {
    return `${(tokens / 1000).toFixed(1)}k tokens`;
  }
  return `${tokens} tokens`;
}
