'use client';

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Upload, Loader2, X, Download, Check, Sparkles } from 'lucide-react';
import { formatTokens } from '@/config/token';

interface AutoTranslationResult {
  id: string;
  originalImage: string;
  generatedImages: string[];  // 改为数组，存储3个版本
  originalText: string;
  translatedText: string;
  targetLanguage: 'es' | 'pt';
  loading?: boolean;
  error?: string;
  usage?: {
    totalTokens: number;
    totalImages: number;
    source: 'api' | 'estimated';
  };
}

export default function AutoImageTranslation() {
  const [images, setImages] = useState<AutoTranslationResult[]>([]);
  const [targetLanguage, setTargetLanguage] = useState<'es' | 'pt'>('es');
  const [aspectRatio, setAspectRatio] = useState<'1:1' | 'original'>('1:1'); // 添加图片比例选择
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 固定配置：豆包4.5模型，1个版本，每张250 tokens
  const FIXED_CONFIG = {
    model: 'default',
    versionCount: 1,
    tokensPerImage: 250
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    // 处理所有上传的文件
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;

        const newImage: AutoTranslationResult = {
          id: `${Date.now()}-${Math.random()}`,
          originalImage: base64,
          generatedImages: [],  // 初始化为空数组
          originalText: '',
          translatedText: '',
          targetLanguage,
          loading: true
        };

        setImages(prev => [...prev, newImage]);
        processTranslation(newImage, base64);
      };
      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const processTranslation = async (imageResult: AutoTranslationResult, base64: string) => {
    try {
      const response = await fetch('/api/translate-image-auto', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: base64,
          targetLanguage,
          aspectRatio,
          model: FIXED_CONFIG.model,
          versionCount: FIXED_CONFIG.versionCount
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '翻译失败');
      }

      setImages(prev =>
        prev.map(img =>
          img.id === imageResult.id
            ? {
                ...img,
                generatedImages: data.generatedImages || [],
                originalText: data.originalText,
                translatedText: data.translatedText,
                loading: false,
                error: undefined,
                usage: data.usage
              }
            : img
        )
      );
    } catch (error) {
      setImages(prev =>
        prev.map(img =>
          img.id === imageResult.id
            ? {
                ...img,
                loading: false,
                error: error instanceof Error ? error.message : '翻译失败'
              }
            : img
        )
      );
    }
  };

  const removeImage = (id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  };

  // 修复：使用fetch+blob模式解决跨域下载问题
  const downloadImage = async (imageUrl: string, filename: string) => {
    try {
      // 1. 使用fetch下载图片数据
      const response = await fetch(imageUrl);
      if (!response.ok) {
        throw new Error('下载失败');
      }

      // 2. 转换为blob
      const blob = await response.blob();

      // 3. 创建blob URL
      const blobUrl = window.URL.createObjectURL(blob);

      // 4. 创建下载链接
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;

      // 5. 触发下载
      document.body.appendChild(link);
      link.click();

      // 6. 清理
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error('下载失败:', error);
      alert('下载失败，请重试');
    }
  };

  // 批量下载所有翻译图片
  const downloadAllImages = async (imageResult: AutoTranslationResult) => {
    if (imageResult.generatedImages.length === 0) {
      alert('没有可下载的图片');
      return;
    }

    // 顺序下载，避免同时触发太多下载
    for (let i = 0; i < imageResult.generatedImages.length; i++) {
      const imageUrl = imageResult.generatedImages[i];
      const filename = `translated_${imageResult.targetLanguage}_version${i + 1}_${imageResult.id}.png`;
      await downloadImage(imageUrl, filename);

      // 间隔500ms，避免浏览器拦截
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  };

  const clearAll = () => {
    setImages([]);
  };

  return (
    <Card className="mb-8 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              图片文字自动翻译（AI生成）
            </CardTitle>
            <CardDescription className="mt-1">
              上传图片，AI自动识别文字并生成翻译版本，保持原图风格
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* 语言选择 */}
          <div>
            <Label className="mb-2 block font-medium">目标语言</Label>
            <div className="flex gap-4">
              <button
                onClick={() => setTargetLanguage('es')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  targetLanguage === 'es'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                <div className="font-semibold">🇪🇸 西班牙语</div>
                <div className="text-xs text-gray-500 mt-1">Español</div>
              </button>
              <button
                onClick={() => setTargetLanguage('pt')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  targetLanguage === 'pt'
                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                <div className="font-semibold">🇧🇷 葡萄牙语</div>
                <div className="text-xs text-gray-500 mt-1">Português</div>
              </button>
            </div>
          </div>

          {/* 图片比例选择 */}
          <div>
            <Label className="mb-2 block font-medium">图片比例</Label>
            <div className="flex gap-4">
              <button
                onClick={() => setAspectRatio('1:1')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  aspectRatio === '1:1'
                    ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                <div className="font-semibold flex items-center gap-2 justify-center">
                  <div className="w-6 h-6 border-2 border-current rounded-sm"></div>
                  1:1 正方形
                </div>
                <div className="text-xs text-gray-500 mt-1">推荐，适合美客多</div>
              </button>
              <button
                onClick={() => setAspectRatio('original')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  aspectRatio === 'original'
                    ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-400'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                <div className="font-semibold flex items-center gap-2 justify-center">
                  <div className="w-8 h-5 border-2 border-current rounded-sm"></div>
                  保持原图比例
                </div>
                <div className="text-xs text-gray-500 mt-1">不裁剪图片</div>
              </button>
            </div>
          </div>

          {/* 上传区域 */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center cursor-pointer hover:border-blue-400 dark:hover:border-blue-600 transition-colors bg-gray-50 dark:bg-gray-800/50"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileChange}
              className="hidden"
            />
            <Upload className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600 dark:text-gray-300 mb-2">
              点击上传图片，支持批量选择多张图片
            </p>
            <p className="text-sm text-gray-500">
              支持 JPG、PNG、WebP 格式，每张图片将生成 1 个翻译版本
            </p>
          </div>

          {/* 图片列表 */}
          {images.length > 0 && (
            <>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">已处理 {images.length} 张图片</h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearAll}
                >
                  清空全部
                </Button>
              </div>

              <div className="grid gap-6">
                {images.map((image) => (
                  <Card key={image.id} className="overflow-hidden">
                    <CardContent className="p-6">
                      {image.loading ? (
                        <div className="flex flex-col items-center justify-center py-12">
                          <Loader2 className="w-12 h-12 text-blue-600 animate-spin mb-4" />
                          <p className="text-gray-600">AI正在识别文字并生成 1 个翻译版本...</p>
                          <p className="text-sm text-gray-500 mt-2">这可能需要20-60秒</p>
                        </div>
                      ) : image.error ? (
                        <div className="text-center py-12">
                          <X className="w-12 h-12 text-red-500 mx-auto mb-4" />
                          <p className="text-red-600 font-semibold">处理失败</p>
                          <p className="text-gray-600 mt-2">{image.error}</p>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          {/* 原始图片 */}
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <Label className="font-semibold">原始图片</Label>
                            </div>
                            <img
                              src={image.originalImage}
                              alt="原始图片"
                              className="w-full rounded-lg border-2 border-gray-200 dark:border-gray-700"
                            />
                          </div>

                          {/* 翻译后的图片 - 3个版本 */}
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <Label className="font-semibold flex items-center gap-2">
                                <Check className="w-4 h-4 text-green-600" />
                                翻译后的图片（{image.generatedImages.length}个版本，选择最合适的）
                              </Label>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => downloadAllImages(image)}
                                className="flex items-center gap-2"
                              >
                                <Download className="w-4 h-4" />
                                批量下载全部
                              </Button>
                            </div>
                            <div className="grid md:grid-cols-3 gap-4">
                              {image.generatedImages.map((generatedImage, index) => (
                                <div key={index} className="space-y-2">
                                  <div className="flex items-center justify-between">
                                    <Label className="text-sm font-medium">版本 {index + 1}</Label>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => downloadImage(generatedImage, `translated_${targetLanguage}_v${index + 1}_${image.id}.png`)}
                                    >
                                      <Download className="w-3 h-3 mr-1" />
                                      下载
                                    </Button>
                                  </div>
                                  <img
                                    src={generatedImage}
                                    alt={`翻译后的图片 - 版本${index + 1}`}
                                    className="w-full rounded-lg border-2 border-green-200 dark:border-green-800"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* 文字对比 */}
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <Label className="font-semibold mb-2 block">识别的文字（原文）</Label>
                              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 text-sm">
                                {image.originalText}
                              </div>
                            </div>
                            <div>
                              <Label className="font-semibold mb-2 block">
                                {targetLanguage === 'es' ? '🇪🇸 西班牙语翻译' : '🇧🇷 葡萄牙语翻译'}
                              </Label>
                              <div className={`rounded-lg p-4 text-sm ${targetLanguage === 'es' ? 'bg-blue-50 dark:bg-blue-900/20' : 'bg-green-50 dark:bg-green-900/20'}`}>
                                {image.translatedText}
                              </div>
                            </div>
                          </div>

                          {/* Token消耗统计 */}
                          {image.usage && (
                            <div className="mt-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                              <div className="flex items-center gap-2 mb-2">
                                <Sparkles className="w-4 h-4 text-purple-600" />
                                <Label className="font-semibold text-purple-800 dark:text-purple-200">
                                  Token消耗统计 {image.usage.source === 'api' ? '✅ (真实数据)' : '📊 (估算数据)'}
                                </Label>
                              </div>
                              <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                  <span className="text-gray-600 dark:text-gray-400">生成图片：</span>
                                  <span className="font-semibold text-purple-700 dark:text-purple-300 ml-2">
                                    {image.usage.totalImages} 张
                                  </span>
                                </div>
                                <div>
                                  <span className="text-gray-600 dark:text-gray-400">Token消耗：</span>
                                  <span className="font-semibold text-purple-700 dark:text-purple-300 ml-2">
                                    {formatTokens(image.usage.totalTokens)}
                                  </span>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {/* 删除按钮 */}
                      {!image.loading && (
                        <div className="flex justify-end mt-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeImage(image.id)}
                          >
                            <X className="w-4 h-4 mr-1" />
                            删除
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}

          {/* 使用说明 */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-purple-600 dark:text-purple-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-purple-800 dark:text-purple-200 mb-2">AI自动翻译说明：</p>
                <ul className="text-sm text-purple-700 dark:text-purple-300 space-y-1">
                  <li>• AI会自动识别图片中的文字（支持中英文等多种语言）</li>
                  <li>• 翻译为西班牙语或葡萄牙语</li>
                  <li>• 生成1-3个版本的新图片，保持原图风格，只改变文字内容</li>
                  <li>• 可选择图片比例：<b>1:1正方形</b>（推荐，适合美客多）或<b>保持原图比例</b></li>
                  <li>• 支持单个下载和批量下载全部版本</li>
                  <li>• 每张图片处理时间约20-60秒（取决于模型选择和版本数量）</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
