'use client';

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Copy, Edit, Sparkles, Loader2, Check, X, Upload, Image as ImageIcon } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface ListingResult {
  title_es?: string;
  title_pt?: string;
  description_es?: string;
  description_pt?: string;
  parameters_es?: string[];
  parameters_pt?: string[];
  keywords_es?: string[];
  keywords_pt?: string[];
}

interface ListingDisplayProps {
  result: ListingResult;
  onResultUpdate: (updatedResult: ListingResult) => void;
}

export default function ListingDisplay({ result, onResultUpdate }: ListingDisplayProps) {
  const [editingItem, setEditingItem] = useState<{
    type: 'title_es' | 'title_pt' | 'description_es' | 'description_pt';
    currentContent: string;
    refinedContent: string;
    instruction: string;
  } | null>(null);
  const [refining, setRefining] = useState(false);

  // 识图优化相关状态
  const [imageOptimization, setImageOptimization] = useState<{
    type: 'description_es' | 'description_pt';
    currentDescription: string;
    optimizedDescription: string;
    imageAnalysis: string;
    addedFeatures: string;
    improvements: string;
    uploadedImage: string;
  } | null>(null);
  const [analyzingImage, setAnalyzingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 识图生成描述相关状态
  const [imageGeneration, setImageGeneration] = useState<{
    type: 'description_es' | 'description_pt';
    uploadedImage: string;
    imageAnalysis: string;
    generatedDescription: string;
    isAnalyzing: boolean;
  } | null>(null);
  const generateFileInputRef = useRef<HTMLInputElement>(null);
  const [generatingFromImage, setGeneratingFromImage] = useState(false);

  const handleEdit = async (type: 'title_es' | 'title_pt' | 'description_es' | 'description_pt', instruction: string) => {
    if (!editingItem) return;

    setRefining(true);
    try {
      const content_type = type.startsWith('title') ? 'title' : 'description';
      const language = type.endsWith('es') ? 'es' : 'pt';

      const response = await fetch('/api/refine-listing', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: editingItem.currentContent,
          content_type,
          language,
          instruction
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '调整失败');
      }

      // 更新结果
      const updatedResult = { ...result };
      updatedResult[type] = data.refined_content;

      onResultUpdate(updatedResult);

      // 更新编辑状态
      setEditingItem({
        ...editingItem,
        refinedContent: data.refined_content
      });
    } catch (error) {
      alert(error instanceof Error ? error.message : '调整失败，请重试');
    } finally {
      setRefining(false);
    }
  };

  // 识图优化处理函数
  const handleImageUpload = (type: 'description_es' | 'description_pt', e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;

      setImageOptimization({
        type,
        currentDescription: (result as any)[type],
        optimizedDescription: '',
        imageAnalysis: '',
        addedFeatures: '',
        improvements: '',
        uploadedImage: base64
      });

      // 自动开始分析
      analyzeImage(type, base64);
    };
    reader.readAsDataURL(files[0]);
  };

  const analyzeImage = async (type: 'description_es' | 'description_pt', base64: string) => {
    setAnalyzingImage(true);
    try {
      const language = type.endsWith('es') ? 'es' : 'pt';

      const response = await fetch('/api/analyze-image-optimization', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: base64,
          currentDescription: (result as any)[type],
          targetLanguage: language
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '图片分析失败');
      }

      // 更新优化状态
      setImageOptimization(prev => prev ? {
        ...prev,
        optimizedDescription: data.optimizedDescription,
        imageAnalysis: data.imageAnalysis,
        addedFeatures: data.addedFeatures,
        improvements: data.improvements
      } : null);
    } catch (error) {
      alert(error instanceof Error ? error.message : '图片分析失败，请重试');
    } finally {
      setAnalyzingImage(false);
    }
  };

  const acceptImageOptimization = () => {
    if (!imageOptimization) return;

    const updatedResult = { ...result };
    updatedResult[imageOptimization.type] = imageOptimization.optimizedDescription;
    onResultUpdate(updatedResult);

    setImageOptimization(null);
  };

  const cancelImageOptimization = () => {
    setImageOptimization(null);
  };

  // 识图生成描述处理函数
  const handleImageGenerationUpload = (type: 'description_es' | 'description_pt', e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
      const base64 = event.target?.result as string;

      setImageGeneration({
        type,
        uploadedImage: base64,
        imageAnalysis: '',
        generatedDescription: '',
        isAnalyzing: true
      });

      // 自动开始生成
      generateDescriptionFromImage(type, base64);
    };

    reader.readAsDataURL(file);
  };

  const generateDescriptionFromImage = async (type: 'description_es' | 'description_pt', base64: string) => {
    setGeneratingFromImage(true);
    try {
      const targetLanguage = type.endsWith('es') ? 'es' : 'pt';

      const response = await fetch('/api/generate-description-from-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: base64,
          targetLanguage
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '生成失败');
      }

      // 更新生成状态
      setImageGeneration(prev => prev ? {
        ...prev,
        imageAnalysis: data.imageAnalysis,
        generatedDescription: data.generatedDescription,
        isAnalyzing: false
      } : null);
    } catch (error) {
      alert(error instanceof Error ? error.message : '生成失败，请重试');
      setImageGeneration(null);
    } finally {
      setGeneratingFromImage(false);
    }
  };

  const acceptImageGeneration = () => {
    if (!imageGeneration) return;

    const updatedResult = { ...result };
    updatedResult[imageGeneration.type] = imageGeneration.generatedDescription;
    onResultUpdate(updatedResult);

    setImageGeneration(null);
  };

  const cancelImageGeneration = () => {
    setImageGeneration(null);
  };

  // 合并描述和参数为一段文本
  const getCombinedText = (description: string | undefined, parameters?: string[]) => {
    if (!description) {
      return '';
    }
    if (!parameters || parameters.length === 0) {
      return description;
    }
    const paramsText = parameters.join('\n');
    return `${description}\n\n${paramsText}`;
  };

  const openEditor = (type: 'title_es' | 'title_pt' | 'description_es' | 'description_pt') => {
    setEditingItem({
      type,
      currentContent: (result as any)[type],
      refinedContent: (result as any)[type],
      instruction: ''
    });
  };

  const acceptRefinement = () => {
    if (!editingItem) return;

    const updatedResult = { ...result };
    updatedResult[editingItem.type] = editingItem.refinedContent;
    onResultUpdate(updatedResult);

    setEditingItem(null);
  };

  const cancelRefinement = () => {
    setEditingItem(null);
  };

  const copyToClipboard = (text: string | undefined, label: string) => {
    if (!text) {
      alert(`没有可复制的${label}`);
      return;
    }
    navigator.clipboard.writeText(text);
    alert(`${label} 已复制到剪贴板`);
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {/* 拉美西语部分 */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-blue-600 dark:text-blue-400 flex items-center gap-2">
            <span>🇪🇸</span>
            拉美西语 (Español)
          </CardTitle>
          <CardDescription>
            适用于墨西哥、哥伦比亚、智利等国家
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 标题 */}
          {result.title_es && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="font-semibold flex items-center gap-2">
                产品标题（≤60字符）
              </Label>
              <div className="flex gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditor('title_es')}
                    >
                      <Sparkles className="w-4 h-4 mr-1" />
                      AI调整
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>AI精细化调整 - 标题</DialogTitle>
                      <DialogDescription>
                        输入调整要求，AI将根据你的需求优化标题
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div>
                        <Label>原标题：</Label>
                        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 mt-1 text-sm">
                          {result.title_es}
                        </div>
                      </div>
                      <div>
                        <Label>AI调整建议：</Label>
                        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 mt-1 text-sm">
                          {editingItem?.type === 'title_es' && refining ? (
                            <div className="flex items-center gap-2">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              正在调整...
                            </div>
                          ) : editingItem?.type === 'title_es' ? (
                            editingItem.refinedContent
                          ) : (
                            '点击下方按钮生成'
                          )}
                        </div>
                      </div>
                      <div>
                        <Label>调整要求：</Label>
                        <Input
                          placeholder="例如：更简洁、突出材质、强调便携性..."
                          value={editingItem?.instruction || ''}
                          onChange={(e) =>
                            editingItem &&
                            setEditingItem({ ...editingItem, instruction: e.target.value })
                          }
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && editingItem) {
                              handleEdit('title_es', editingItem.instruction);
                            }
                          }}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => editingItem && handleEdit('title_es', editingItem.instruction)}
                          disabled={refining}
                          className="flex-1"
                        >
                          {refining ? '调整中...' : '开始调整'}
                        </Button>
                        {editingItem?.type === 'title_es' && editingItem.refinedContent !== editingItem.currentContent && (
                          <>
                            <Button
                              variant="outline"
                              onClick={acceptRefinement}
                            >
                              <Check className="w-4 h-4 mr-1" />
                              接受
                            </Button>
                            <Button
                              variant="ghost"
                              onClick={cancelRefinement}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(result.title_es, '西班牙语标题')}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
              <p className="font-medium">{result.title_es}</p>
              <p className="text-xs text-gray-500 mt-1">
                {result.title_es.length}/60 字符
              </p>
            </div>
          </div>
          )}

          {/* 完整Listing文本（描述+参数） */}
          {result.description_es && (
            <>
            <div className="mt-2">
              <div className="flex items-center justify-between mb-2">
              <Label className="font-semibold text-purple-600 dark:text-purple-400">
                完整Listing文本（描述+参数）
              </Label>
              <div className="flex gap-2">
                <Dialog open={imageGeneration?.type === 'description_es'} onOpenChange={(open) => !open && cancelImageGeneration()}>
                  <DialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setImageGeneration({ type: 'description_es', uploadedImage: '', imageAnalysis: '', generatedDescription: '', isAnalyzing: false });
                        generateFileInputRef.current?.click();
                      }}
                    >
                      <ImageIcon className="w-4 h-4 mr-1" />
                      识图生成
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>识图生成产品描述</DialogTitle>
                      <DialogDescription>
                        上传产品图片，AI将识别图片内容并生成完整的产品描述
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      {/* 上传区域 */}
                      {!imageGeneration?.uploadedImage ? (
                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center">
                          <input
                            ref={generateFileInputRef}
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageGenerationUpload('description_es', e)}
                            className="hidden"
                          />
                          <Button
                            onClick={() => generateFileInputRef.current?.click()}
                            variant="outline"
                            size="lg"
                          >
                            <Upload className="w-5 h-5 mr-2" />
                            上传产品图片
                          </Button>
                          <p className="text-xs text-gray-500 mt-2">
                            支持 JPG、PNG、WebP 格式，最大 10MB
                          </p>
                        </div>
                      ) : (
                        <>
                          {/* 图片预览 */}
                          <div className="flex justify-center mb-4">
                            <img
                              src={imageGeneration.uploadedImage}
                              alt="产品图片"
                              className="w-full rounded-lg border-2 border-gray-200 dark:border-gray-700"
                            />
                          </div>

                          {imageGeneration.isAnalyzing || generatingFromImage ? (
                            <div className="flex items-center justify-center py-8">
                              <div className="flex items-center gap-2">
                                <Loader2 className="w-5 h-5 animate-spin" />
                                <span>正在分析图片并生成描述...</span>
                              </div>
                            </div>
                          ) : (
                            <>
                              {imageGeneration.imageAnalysis && (
                                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-sm">
                                  <Label className="mb-2 block">图片识别结果</Label>
                                  <p className="whitespace-pre-wrap">{imageGeneration.imageAnalysis}</p>
                                </div>
                              )}

                              {imageGeneration.generatedDescription && (
                                <>
                                  <div>
                                    <Label className="mb-2 block">生成的产品描述</Label>
                                    <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-sm max-h-60 overflow-y-auto whitespace-pre-wrap">
                                      {imageGeneration.generatedDescription}
                                    </div>
                                  </div>

                                  <div className="flex gap-2 mt-4">
                                    <Button
                                      onClick={acceptImageGeneration}
                                      className="flex-1"
                                    >
                                      <Check className="w-4 h-4 mr-1" />
                                      接受生成
                                    </Button>
                                    <Button
                                      variant="outline"
                                      onClick={cancelImageGeneration}
                                    >
                                      <X className="w-4 h-4 mr-1" />
                                      取消
                                    </Button>
                                  </div>
                                </>
                              )}
                            </>
                          )}
                        </>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(getCombinedText(result.description_es, result.parameters_es), '西班牙语完整Listing')}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-3 text-sm whitespace-pre-wrap max-h-80 overflow-y-auto">
              {getCombinedText(result.description_es, result.parameters_es)}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              包含产品描述和所有参数，可直接复制到美客多
            </p>
          </div>

          {/* 搜索关键词 */}
          {result.keywords_es && result.keywords_es.length > 0 && (
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <Label className="font-semibold text-orange-600 dark:text-orange-400">
                搜索关键词（8-12个）
              </Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(result.keywords_es?.join(', '), '西班牙语关键词')}
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {result.keywords_es.map((keyword, index) => (
                <span
                  key={index}
                  className="bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-300 px-3 py-1 rounded-full text-sm"
                >
                  {keyword}
                </span>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              适用于美客多卡拉美地区，小写去重，无侵权风险
            </p>
          </div>
          )}

          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <Label className="font-semibold mb-2 block">高级优化选项</Label>
            <div className="flex gap-2 flex-wrap">
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openEditor('description_es')}
                  >
                    <Sparkles className="w-4 h-4 mr-1" />
                    AI调整描述
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>AI精细化调整 - 描述</DialogTitle>
                    <DialogDescription>
                      输入调整要求，AI将根据你的需求优化描述
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div>
                      <Label>原描述：</Label>
                      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 mt-1 text-sm max-h-40 overflow-y-auto">
                        {result.description_es}
                      </div>
                    </div>
                    <div>
                      <Label>AI调整建议：</Label>
                      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 mt-1 text-sm max-h-40 overflow-y-auto whitespace-pre-wrap">
                        {editingItem?.type === 'description_es' && refining ? (
                          <div className="flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            正在调整...
                          </div>
                        ) : editingItem?.type === 'description_es' ? (
                          editingItem.refinedContent
                        ) : (
                          '点击下方按钮生成'
                        )}
                      </div>
                    </div>
                    <div>
                      <Label>调整要求：</Label>
                      <Textarea
                        placeholder="例如：更简洁、突出材质、强调便携性、增加使用场景..."
                        rows={3}
                        value={editingItem?.instruction || ''}
                        onChange={(e) =>
                          editingItem &&
                          setEditingItem({ ...editingItem, instruction: e.target.value })
                        }
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => editingItem && handleEdit('description_es', editingItem.instruction)}
                        disabled={refining}
                        className="flex-1"
                      >
                        {refining ? '调整中...' : '开始调整'}
                      </Button>
                      {editingItem?.type === 'description_es' && editingItem.refinedContent !== editingItem.currentContent && (
                        <>
                          <Button
                            variant="outline"
                            onClick={acceptRefinement}
                          >
                            <Check className="w-4 h-4 mr-1" />
                            接受
                          </Button>
                          <Button
                            variant="ghost"
                            onClick={cancelRefinement}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={imageOptimization?.type === 'description_es'} onOpenChange={(open) => !open && cancelImageOptimization()}>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                  >
                    <ImageIcon className="w-4 h-4 mr-1" />
                    识图优化
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>识图优化 - 产品描述</DialogTitle>
                    <DialogDescription>
                      上传产品图片，AI将识别图片内容并优化产品描述
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    {!imageOptimization?.uploadedImage ? (
                      <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center">
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload('description_es', e)}
                          className="hidden"
                        />
                        <Button
                          onClick={() => fileInputRef.current?.click()}
                          variant="outline"
                          size="lg"
                        >
                          <Upload className="w-5 h-5 mr-2" />
                          上传产品图片
                        </Button>
                        <p className="text-sm text-gray-500 mt-2">
                          支持 JPG、PNG、WebP 格式
                        </p>
                      </div>
                    ) : (
                      <>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label className="mb-2 block">上传的图片</Label>
                            <img
                              src={imageOptimization.uploadedImage}
                              alt="产品图片"
                              className="w-full rounded-lg border-2 border-gray-200 dark:border-gray-700"
                            />
                          </div>
                          <div>
                            <Label className="mb-2 block">图片分析结果</Label>
                            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-sm max-h-[400px] overflow-y-auto whitespace-pre-wrap">
                              {analyzingImage ? (
                                <div className="flex items-center gap-2">
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                  正在分析图片...
                                </div>
                              ) : imageOptimization.imageAnalysis ? (
                                imageOptimization.imageAnalysis
                              ) : (
                                '等待分析...'
                              )}
                            </div>
                          </div>
                        </div>

                        {imageOptimization.imageAnalysis && !analyzingImage && (
                          <>
                            <div>
                              <Label className="mb-2 block">新增的产品特征</Label>
                              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-sm">
                                {imageOptimization.addedFeatures}
                              </div>
                            </div>

                            <div>
                              <Label className="mb-2 block">改进点说明</Label>
                              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-sm">
                                {imageOptimization.improvements}
                              </div>
                            </div>

                            <div>
                              <Label className="mb-2 block">原描述 vs 优化后的描述</Label>
                              <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-sm max-h-60 overflow-y-auto">
                                    {imageOptimization.currentDescription}
                                  </div>
                                  <p className="text-xs text-gray-500 mt-1">原描述</p>
                                </div>
                                <div>
                                  <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-3 text-sm max-h-60 overflow-y-auto">
                                    {imageOptimization.optimizedDescription}
                                  </div>
                                  <p className="text-xs text-gray-500 mt-1">优化后的描述</p>
                                </div>
                              </div>
                            </div>

                            <div className="flex gap-2">
                              <Button
                                onClick={acceptImageOptimization}
                                className="flex-1"
                              >
                                <Check className="w-4 h-4 mr-1" />
                                接受优化
                              </Button>
                              <Button
                                variant="outline"
                                onClick={cancelImageOptimization}
                              >
                                <X className="w-4 h-4 mr-1" />
                                取消
                              </Button>
                            </div>
                          </>
                        )}
                      </>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          </>)}
        </CardContent>
      </Card>

      {/* 巴西葡语部分 */}
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-green-600 dark:text-green-400 flex items-center gap-2">
            <span>🇧🇷</span>
            巴西葡语 (Português)
          </CardTitle>
          <CardDescription>
            适用于巴西市场
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 标题 */}
          {result.title_pt && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="font-semibold flex items-center gap-2">
                产品标题（≤60字符）
              </Label>
              <div className="flex gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditor('title_pt')}
                    >
                      <Sparkles className="w-4 h-4 mr-1" />
                      AI调整
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>AI精细化调整 - 标题</DialogTitle>
                      <DialogDescription>
                        输入调整要求，AI将根据你的需求优化标题
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div>
                        <Label>原标题：</Label>
                        <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 mt-1 text-sm">
                          {result.title_pt}
                        </div>
                      </div>
                      <div>
                        <Label>AI调整建议：</Label>
                        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 mt-1 text-sm">
                          {editingItem?.type === 'title_pt' && refining ? (
                            <div className="flex items-center gap-2">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              正在调整...
                            </div>
                          ) : editingItem?.type === 'title_pt' ? (
                            editingItem.refinedContent
                          ) : (
                            '点击下方按钮生成'
                          )}
                        </div>
                      </div>
                      <div>
                        <Label>调整要求：</Label>
                        <Input
                          placeholder="例如：更简洁、突出材质、强调便携性..."
                          value={editingItem?.instruction || ''}
                          onChange={(e) =>
                            editingItem &&
                            setEditingItem({ ...editingItem, instruction: e.target.value })
                          }
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && editingItem) {
                              handleEdit('title_pt', editingItem.instruction);
                            }
                          }}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={() => editingItem && handleEdit('title_pt', editingItem.instruction)}
                          disabled={refining}
                          className="flex-1"
                        >
                          {refining ? '调整中...' : '开始调整'}
                        </Button>
                        {editingItem?.type === 'title_pt' && editingItem.refinedContent !== editingItem.currentContent && (
                          <>
                            <Button
                              variant="outline"
                              onClick={acceptRefinement}
                            >
                              <Check className="w-4 h-4 mr-1" />
                              接受
                            </Button>
                            <Button
                              variant="ghost"
                              onClick={cancelRefinement}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(result.title_pt, '葡萄牙语标题')}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
              <p className="font-medium">{result.title_pt}</p>
              <p className="text-xs text-gray-500 mt-1">
                {result.title_pt.length}/60 字符
              </p>
            </div>
          </div>
          )}

          {/* AI调整和识图优化按钮（折叠式） */}
          {result.description_pt && (
          <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
            <Label className="font-semibold mb-2 block">高级优化选项</Label>
            <div className="flex gap-2 flex-wrap">
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openEditor('description_pt')}
                  >
                    <Sparkles className="w-4 h-4 mr-1" />
                    AI调整描述
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>AI精细化调整 - 描述</DialogTitle>
                    <DialogDescription>
                      输入调整要求，AI将根据你的需求优化描述
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div>
                      <Label>原描述：</Label>
                      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 mt-1 text-sm max-h-40 overflow-y-auto">
                        {result.description_pt}
                      </div>
                    </div>
                    <div>
                      <Label>AI调整建议：</Label>
                      <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 mt-1 text-sm max-h-40 overflow-y-auto whitespace-pre-wrap">
                        {editingItem?.type === 'description_pt' && refining ? (
                          <div className="flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin" />
                            正在调整...
                          </div>
                        ) : editingItem?.type === 'description_pt' ? (
                          editingItem.refinedContent
                        ) : (
                          '点击下方按钮生成'
                        )}
                      </div>
                    </div>
                    <div>
                      <Label>调整要求：</Label>
                      <Textarea
                        placeholder="例如：更简洁、突出材质、强调便携性、增加使用场景..."
                        rows={3}
                        value={editingItem?.instruction || ''}
                        onChange={(e) =>
                          editingItem &&
                          setEditingItem({ ...editingItem, instruction: e.target.value })
                        }
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => editingItem && handleEdit('description_pt', editingItem.instruction)}
                        disabled={refining}
                        className="flex-1"
                      >
                        {refining ? '调整中...' : '开始调整'}
                      </Button>
                      {editingItem?.type === 'description_pt' && editingItem.refinedContent !== editingItem.currentContent && (
                        <>
                          <Button
                            variant="outline"
                            onClick={acceptRefinement}
                          >
                            <Check className="w-4 h-4 mr-1" />
                            接受
                          </Button>
                          <Button
                            variant="ghost"
                            onClick={cancelRefinement}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={imageOptimization?.type === 'description_pt'} onOpenChange={(open) => !open && cancelImageOptimization()}>
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                  >
                    <ImageIcon className="w-4 h-4 mr-1" />
                    识图优化
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>识图优化 - 产品描述</DialogTitle>
                    <DialogDescription>
                      上传产品图片，AI将识别图片内容并优化产品描述
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    {!imageOptimization?.uploadedImage ? (
                      <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center">
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload('description_pt', e)}
                          className="hidden"
                        />
                        <Button
                          onClick={() => fileInputRef.current?.click()}
                          variant="outline"
                          size="lg"
                        >
                          <Upload className="w-5 h-5 mr-2" />
                          上传产品图片
                        </Button>
                        <p className="text-sm text-gray-500 mt-2">
                          支持 JPG、PNG、WebP 格式
                        </p>
                      </div>
                    ) : (
                      <>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label className="mb-2 block">上传的图片</Label>
                            <img
                              src={imageOptimization.uploadedImage}
                              alt="产品图片"
                              className="w-full rounded-lg border-2 border-gray-200 dark:border-gray-700"
                            />
                          </div>
                          <div>
                            <Label className="mb-2 block">图片分析结果</Label>
                            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-sm max-h-[400px] overflow-y-auto whitespace-pre-wrap">
                              {analyzingImage ? (
                                <div className="flex items-center gap-2">
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                  正在分析图片...
                                </div>
                              ) : imageOptimization.imageAnalysis ? (
                                imageOptimization.imageAnalysis
                              ) : (
                                '等待分析...'
                              )}
                            </div>
                          </div>
                        </div>

                        {imageOptimization.imageAnalysis && !analyzingImage && (
                          <>
                            <div>
                              <Label className="mb-2 block">新增的产品特征</Label>
                              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-sm">
                                {imageOptimization.addedFeatures}
                              </div>
                            </div>

                            <div>
                              <Label className="mb-2 block">改进点说明</Label>
                              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-3 text-sm">
                                {imageOptimization.improvements}
                              </div>
                            </div>

                            <div>
                              <Label className="mb-2 block">原描述 vs 优化后的描述</Label>
                              <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                  <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-sm max-h-60 overflow-y-auto">
                                    {imageOptimization.currentDescription}
                                  </div>
                                  <p className="text-xs text-gray-500 mt-1">原描述</p>
                                </div>
                                <div>
                                  <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-3 text-sm max-h-60 overflow-y-auto">
                                    {imageOptimization.optimizedDescription}
                                  </div>
                                  <p className="text-xs text-gray-500 mt-1">优化后的描述</p>
                                </div>
                              </div>
                            </div>

                            <div className="flex gap-2">
                              <Button
                                onClick={acceptImageOptimization}
                                className="flex-1"
                              >
                                <Check className="w-4 h-4 mr-1" />
                                接受优化
                              </Button>
                              <Button
                                variant="outline"
                                onClick={cancelImageOptimization}
                              >
                                <X className="w-4 h-4 mr-1" />
                                取消
                              </Button>
                            </div>
                          </>
                        )}
                      </>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
          )}

          {/* 合并后的文本（描述+参数） */}
          {result.parameters_pt && result.parameters_pt.length > 0 && (
            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <Label className="font-semibold text-orange-600 dark:text-orange-400">
                  完整Listing文本（描述+参数）
                </Label>
                <div className="flex gap-2">
                  <Dialog open={imageGeneration?.type === 'description_pt'} onOpenChange={(open) => !open && cancelImageGeneration()}>
                    <DialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setImageGeneration({ type: 'description_pt', uploadedImage: '', imageAnalysis: '', generatedDescription: '', isAnalyzing: false });
                          generateFileInputRef.current?.click();
                        }}
                      >
                        <ImageIcon className="w-4 h-4 mr-1" />
                        识图生成
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle>识图生成产品描述</DialogTitle>
                        <DialogDescription>
                          上传产品图片，AI将识别图片内容并生成完整的产品描述
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        {/* 上传区域 */}
                        {!imageGeneration?.uploadedImage ? (
                          <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center">
                            <input
                              ref={generateFileInputRef}
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleImageGenerationUpload('description_pt', e)}
                              className="hidden"
                            />
                            <Button
                              onClick={() => generateFileInputRef.current?.click()}
                              variant="outline"
                              size="lg"
                            >
                              <Upload className="w-5 h-5 mr-2" />
                              上传产品图片
                            </Button>
                            <p className="text-xs text-gray-500 mt-2">
                              支持 JPG、PNG、WebP 格式，最大 10MB
                            </p>
                          </div>
                        ) : (
                          <>
                            {/* 图片预览 */}
                            <div className="flex justify-center mb-4">
                              <img
                                src={imageGeneration.uploadedImage}
                                alt="产品图片"
                                className="w-full rounded-lg border-2 border-gray-200 dark:border-gray-700"
                              />
                            </div>

                            {imageGeneration.isAnalyzing || generatingFromImage ? (
                              <div className="flex items-center justify-center py-8">
                                <div className="flex items-center gap-2">
                                  <Loader2 className="w-5 h-5 animate-spin" />
                                  <span>正在分析图片并生成描述...</span>
                                </div>
                              </div>
                            ) : (
                              <>
                                {imageGeneration.imageAnalysis && (
                                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-sm">
                                    <Label className="mb-2 block">图片识别结果</Label>
                                    <p className="whitespace-pre-wrap">{imageGeneration.imageAnalysis}</p>
                                  </div>
                                )}

                                {imageGeneration.generatedDescription && (
                                  <>
                                    <div>
                                      <Label className="mb-2 block">生成的产品描述</Label>
                                      <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-sm max-h-60 overflow-y-auto whitespace-pre-wrap">
                                        {imageGeneration.generatedDescription}
                                      </div>
                                    </div>

                                    <div className="flex gap-2 mt-4">
                                      <Button
                                        onClick={acceptImageGeneration}
                                        className="flex-1"
                                      >
                                        <Check className="w-4 h-4 mr-1" />
                                        接受生成
                                      </Button>
                                      <Button
                                        variant="outline"
                                        onClick={cancelImageGeneration}
                                      >
                                        <X className="w-4 h-4 mr-1" />
                                        取消
                                      </Button>
                                    </div>
                                  </>
                                )}
                              </>
                            )}
                          </>
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => copyToClipboard(getCombinedText(result.description_pt, result.parameters_pt), '葡萄牙语完整Listing')}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-3 text-sm whitespace-pre-wrap max-h-80 overflow-y-auto">
                {getCombinedText(result.description_pt, result.parameters_pt)}
              </div>
              <p className="text-xs text-gray-500 mt-1">
                包含产品描述和所有参数，可直接复制到美客多
              </p>
            </div>
          )}

          {/* 搜索关键词 */}
          {result.keywords_pt && result.keywords_pt.length > 0 && (
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <Label className="font-semibold text-orange-600 dark:text-orange-400">
                搜索关键词（8-12个）
              </Label>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(result.keywords_pt?.join(', '), '葡萄牙语关键词')}
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {result.keywords_pt.map((keyword, index) => (
                <span
                  key={index}
                  className="bg-orange-50 dark:bg-orange-900/20 text-orange-700 dark:text-orange-300 px-3 py-1 rounded-full text-sm"
                >
                  {keyword}
                </span>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              适用于美客多巴西地区，小写去重，无侵权风险
            </p>
          </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
