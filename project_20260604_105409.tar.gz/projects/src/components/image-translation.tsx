'use client';

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Loader2, Upload, X, Copy, Image as ImageIcon, Download, ExternalLink } from 'lucide-react';

interface ImageResult {
  id: string;
  imageUrl: string;
  fileName: string;
  extractedText: string;
  translatedText: string;
  languageDetected: string;
  loading?: boolean;
  error?: string;
}

export default function ImageTranslation() {
  const [images, setImages] = useState<ImageResult[]>([]);
  const [targetLanguage, setTargetLanguage] = useState<'es' | 'pt'>('es');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const newImages: ImageResult[] = files.map((file, index) => ({
      id: `${Date.now()}-${Math.random()}`,
      imageUrl: URL.createObjectURL(file),
      fileName: file.name,
      extractedText: '',
      translatedText: '',
      languageDetected: '',
      loading: true,
      error: undefined
    }));

    setImages((prev) => [...prev, ...newImages]);

    // 逐个处理图片
    newImages.forEach((img, index) => {
      processImages(img, files[index]);
    });

    // 清空 input 以允许重复上传相同文件
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const processImages = async (imageResult: ImageResult, file: File) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;

      try {
        const response = await fetch('/api/translate-image', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            image: base64,
            targetLanguage
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || '翻译失败');
        }

        setImages((prev) =>
          prev.map((img) =>
            img.id === imageResult.id
              ? {
                  ...img,
                  extractedText: data.extractedText,
                  translatedText: data.translatedText,
                  languageDetected: data.languageDetected,
                  loading: false,
                  error: undefined
                }
              : img
          )
        );
      } catch (error) {
        setImages((prev) =>
          prev.map((img) =>
            img.id === imageResult.id
              ? {
                  ...img,
                  loading: false,
                  error: error instanceof Error ? error.message : '翻译失败'
                }
              : img
          )
        );
      }
    };
    reader.readAsDataURL(file);
  };

  const removeImage = (id: string) => {
    setImages((prev) => {
      const image = prev.find(img => img.id === id);
      if (image) {
        URL.revokeObjectURL(image.imageUrl);
      }
      return prev.filter((img) => img.id !== id);
    });
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    alert(`${label} 已复制到剪贴板`);
  };

  const clearAll = () => {
    images.forEach((img) => URL.revokeObjectURL(img.imageUrl));
    setImages([]);
  };

  const exportToCSV = () => {
    const completedImages = images.filter(img => !img.loading && !img.error && img.extractedText);
    if (completedImages.length === 0) {
      alert('没有可导出的翻译结果');
      return;
    }

    const headers = ['文件名', '原始文字', '检测语言', `翻译文字(${targetLanguage === 'es' ? '西班牙语' : '葡萄牙语'})`];
    const rows = completedImages.map(img => [
      img.fileName,
      `"${img.extractedText.replace(/"/g, '""')}"`,
      img.languageDetected,
      `"${img.translatedText.replace(/"/g, '""')}"`
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `翻译结果_${targetLanguage.toUpperCase()}_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const hasCompletedImages = images.some(img => !img.loading && !img.error && img.extractedText);

  return (
    <Card className="mb-8 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <ImageIcon className="w-5 h-5" />
              图片文字翻译（半自动替换方案）
            </CardTitle>
            <CardDescription className="mt-1">
              识别图片中的文字，翻译后在图片编辑器中手动替换
            </CardDescription>
          </div>
          {hasCompletedImages && (
            <Button
              variant="outline"
              size="sm"
              onClick={exportToCSV}
              className="flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              导出CSV
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* 工作流程说明 */}
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
            <p className="text-sm text-blue-800 dark:text-blue-200 font-semibold mb-2">
              📋 半自动替换流程：
            </p>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">1</div>
                <div className="text-blue-700 dark:text-blue-300">
                  <p className="font-medium">上传图片</p>
                  <p className="text-xs opacity-80">批量上传含文字的图片</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">2</div>
                <div className="text-blue-700 dark:text-blue-300">
                  <p className="font-medium">识别翻译</p>
                  <p className="text-xs opacity-80">AI自动识别并翻译文字</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">3</div>
                <div className="text-blue-700 dark:text-blue-300">
                  <p className="font-medium">手动替换</p>
                  <p className="text-xs opacity-80">在图片编辑器中替换文字</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">4</div>
                <div className="text-blue-700 dark:text-blue-300">
                  <p className="font-medium">保存图片</p>
                  <p className="text-xs opacity-80">导出最终产品图</p>
                </div>
              </div>
            </div>
          </div>

          {/* 语言选择 */}
          <div>
            <Label className="mb-2 block font-medium">目标语言</Label>
            <div className="flex gap-4">
              <button
                onClick={() => setTargetLanguage('es')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  targetLanguage === 'es'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                <div className="font-semibold">🇪🇸 西班牙语</div>
                <div className="text-xs text-gray-500 mt-1">Español - 适用于拉美市场</div>
              </button>
              <button
                onClick={() => setTargetLanguage('pt')}
                className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all ${
                  targetLanguage === 'pt'
                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                }`}
              >
                <div className="font-semibold">🇧🇷 葡萄牙语</div>
                <div className="text-xs text-gray-500 mt-1">Português - 适用于巴西</div>
              </button>
            </div>
          </div>

          {/* 上传区域 */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center cursor-pointer hover:border-blue-400 dark:hover:border-blue-600 transition-colors bg-gray-50 dark:bg-gray-800/50"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileChange}
              className="hidden"
            />
            <Upload className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600 dark:text-gray-300 mb-2">
              点击上传图片或拖拽图片到此处
            </p>
            <p className="text-sm text-gray-500">
              支持 JPG、PNG、WebP 格式，可批量上传
            </p>
          </div>

          {/* 图片列表 */}
          {images.length > 0 && (
            <>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">已上传 {images.length} 张图片</h3>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={clearAll}
                  >
                    清空全部
                  </Button>
                  {hasCompletedImages && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open('/replacement-tutorial.html', '_blank')}
                      className="flex items-center gap-2"
                    >
                      <ExternalLink className="w-4 h-4" />
                      替换教程
                    </Button>
                  )}
                </div>
              </div>

              <div className="grid gap-4">
                {images.map((image) => (
                  <Card key={image.id} className="overflow-hidden">
                    <div className="p-4">
                      <div className="flex gap-4 mb-4">
                        {/* 图片预览 */}
                        <div className="flex-shrink-0 w-40 h-40 bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden border-2 border-gray-200 dark:border-gray-700">
                          <img
                            src={image.imageUrl}
                            alt="上传的图片"
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* 结果展示 */}
                        <div className="flex-1 min-w-0 space-y-3">
                          {image.loading ? (
                            <div className="flex items-center gap-2 text-gray-500">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              <span>正在识别和翻译 {image.fileName}...</span>
                            </div>
                          ) : image.error ? (
                            <div className="text-red-600 dark:text-red-400">
                              ❌ {image.fileName}: {image.error}
                            </div>
                          ) : (
                            <>
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <Label className="text-sm font-medium flex items-center gap-2">
                                    <span className="px-2 py-0.5 bg-gray-200 dark:bg-gray-700 rounded text-xs">原文</span>
                                    {image.languageDetected}
                                  </Label>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => copyToClipboard(image.extractedText, '识别文字')}
                                  >
                                    <Copy className="w-4 h-4" />
                                  </Button>
                                </div>
                                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-sm whitespace-pre-wrap border border-gray-200 dark:border-gray-700">
                                  {image.extractedText}
                                </div>
                              </div>

                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <Label className="text-sm font-medium flex items-center gap-2">
                                    <span className={`px-2 py-0.5 rounded text-xs ${targetLanguage === 'es' ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300' : 'bg-green-100 dark:bg-green-900/50 text-green-700 dark:text-green-300'}`}>
                                      {targetLanguage === 'es' ? '🇪🇸 西班牙语' : '🇧🇷 葡萄牙语'}
                                    </span>
                                    翻译
                                  </Label>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => copyToClipboard(image.translatedText, '翻译结果')}
                                  >
                                    <Copy className="w-4 h-4" />
                                  </Button>
                                </div>
                                <div className={`rounded-lg p-3 text-sm whitespace-pre-wrap border ${targetLanguage === 'es' ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' : 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'}`}>
                                  {image.translatedText}
                                </div>
                              </div>

                              <div className="text-xs text-gray-500">
                                💡 提示：复制翻译结果，在图片编辑器中用新文字替换原图片中的英文文字
                              </div>
                            </>
                          )}
                        </div>

                        {/* 删除按钮 */}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeImage(image.id)}
                          className="flex-shrink-0"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </>
          )}

          {/* 推荐工具 */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
            <p className="text-sm text-purple-800 dark:text-purple-200 font-semibold mb-2">
              🛠️ 推荐图片编辑工具：
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
              <a href="https://www.canva.com/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-purple-700 dark:text-purple-300 hover:underline">
                <span>🎨</span>
                <span><strong>Canva</strong> - 在线免费，易上手</span>
              </a>
              <a href="https://www.adobe.com/products/photoshop.html" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-purple-700 dark:text-purple-300 hover:underline">
                <span>🖼️</span>
                <span><strong>Photoshop</strong> - 专业级，功能强大</span>
              </a>
              <a href="https://www.gimp.org/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-purple-700 dark:text-purple-300 hover:underline">
                <span>🔧</span>
                <span><strong>GIMP</strong> - 开源免费，功能全面</span>
              </a>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
