/**
 * 标题审查和删减工具
 * 确保标题在60字符内且不以介词结尾
 * 原则：只做删减，不做优化修改
 */

import { invokeLLM } from './deepseek-client';

// 西班牙语常见介词
const SPANISH_PREPOSITIONS = [
  'a', 'ante', 'bajo', 'cabe', 'con', 'contra', 'de', 'desde', 'en', 'entre',
  'hacia', 'hasta', 'para', 'por', 'según', 'sin', 'so', 'sobre', 'tras',
  'durante', 'mediante', 'versus', 'vía', 'excepto', 'salvo', 'incluso',
  'más', 'menos'
];

// 葡萄牙语常见介词
const PORTUGUESE_PREPOSITIONS = [
  'a', 'ante', 'após', 'até', 'com', 'contra', 'de', 'desde', 'em', 'entre',
  'para', 'per', 'perante', 'por', 'sem', 'sob', 'sobre', 'trás',
  'durante', 'mediante', 'segundo', 'visto', 'exceto', 'salvo', 'inclusive',
  'menos', 'tirante'
];

/**
 * 检查标题是否以介词结尾
 */
function endsWithPreposition(title: string, language: 'es' | 'pt'): { 
  hasPreposition: boolean; 
  preposition: string; 
  wordAfterPreposition: string 
} {
  const words = title.trim().split(/\s+/);
  const prepositions = language === 'es' ? SPANISH_PREPOSITIONS : PORTUGUESE_PREPOSITIONS;
  
  // 检查最后两个词
  if (words.length >= 2) {
    const lastWord = words[words.length - 1].toLowerCase().replace(/[.,!?;:]/g, '');
    const secondLastWord = words[words.length - 2].toLowerCase().replace(/[.,!?;:]/g, '');
    
    // 检查倒数第二个词是否是介词
    if (prepositions.includes(secondLastWord)) {
      return {
        hasPreposition: true,
        preposition: secondLastWord,
        wordAfterPreposition: lastWord
      };
    }
  }
  
  // 检查最后一个词是否是介词
  if (words.length >= 1) {
    const lastWord = words[words.length - 1].toLowerCase().replace(/[.,!?;:]/g, '');
    if (prepositions.includes(lastWord)) {
      return {
        hasPreposition: true,
        preposition: lastWord,
        wordAfterPreposition: ''
      };
    }
  }
  
  return {
    hasPreposition: false,
    preposition: '',
    wordAfterPreposition: ''
  };
}

/**
 * 智能截断标题（避免在介词后截断）
 * 原则：只做删减，不做优化修改
 * 约束：确保标题长度在30-60字符之间
 */
function smartTruncate(title: string, maxLength: number, language: 'es' | 'pt', minLength: number = 30): string {
  if (title.length <= maxLength) {
    return title;
  }
  
  // 首先简单截断到最大长度
  let truncated = title.substring(0, maxLength);
  
  // 检查是否以介词结尾
  const prepositionCheck = endsWithPreposition(truncated, language);
  
  if (prepositionCheck.hasPreposition) {
    // 如果以介词结尾，去掉介词及其后面的词
    const words = truncated.trim().split(/\s+/);
    
    // 找到介词的位置
    const prepositionIndex = words.findIndex(
      w => w.toLowerCase().replace(/[.,!?;:]/g, '') === prepositionCheck.preposition
    );
    
    if (prepositionIndex !== -1) {
      // 截断到介词之前（保留介词前的所有词）
      let result = words.slice(0, prepositionIndex).join(' ');
      
      // 如果截断后太短（少于最小长度），尝试保留介词但去掉最后一个词
      if (result.length < minLength && words.length > 1) {
        result = words.slice(0, -1).join(' ');
      }
      
      // 如果仍然太短，尝试保留更多内容（保留到倒数第二个词）
      if (result.length < minLength && words.length > 2) {
        result = words.slice(0, -2).join(' ');
      }
      
      // 清理末尾的标点符号和空格
      result = result.trim().replace(/[.,!?;:\s]+$/, '');
      
      return result;
    }
  }
  
  // 检查是否截断在介词中间（如 "para" 变成 "pa"）
  const truncatedWords = truncated.trim().split(/\s+/);
  const lastWord = truncatedWords[truncatedWords.length - 1]?.toLowerCase().replace(/[.,!?;:]/g, '') || '';
  
  // 检查最后一个词是否是某个介词的前缀
  const allPrepositions = language === 'es' ? SPANISH_PREPOSITIONS : PORTUGUESE_PREPOSITIONS;
  const matchingPreposition = allPrepositions.find(p => p.startsWith(lastWord) && p !== lastWord);
  
  if (matchingPreposition && truncatedWords.length > 1) {
    // 如果最后一个词是介词的前缀，去掉这个不完整的词
    const newWords = truncatedWords.slice(0, -1);
    let result = newWords.join(' ');
    
    // 如果截断后太短，尝试保留更多内容
    if (result.length < minLength && newWords.length > 1) {
      result = result.trim().replace(/[.,!?;:\s]+$/, '');
    }
    
    console.log(`[${language.toUpperCase()}] 检测到截断的介词 "${lastWord}"，完整介词应为 "${matchingPreposition}"，已删除不完整词`);
    
    return result;
  }
  
  // 如果没有介词问题，清理末尾的标点符号
  truncated = truncated.trim().replace(/[.,!?;:\s]+$/, '');
  
  return truncated;
}

/**
 * 确保标题长度在30-60字符之间
 */
function ensureLengthConstraint(title: string, minLength: number = 30, maxLength: number = 60): string {
  let result = title;
  
  // 如果超过最大长度，截断
  if (result.length > maxLength) {
    result = result.substring(0, maxLength);
    result = result.trim().replace(/[.,!?;:\s]+$/, '');
  }
  
  // 如果小于最小长度，需要扩展（通过重复最后一个词的方式）
  if (result.length < minLength) {
    console.log(`⚠️ 标题过短 (${result.length}字符)，需要补充`);
    // 尝试从原标题中获取更多内容
    // 这种情况较少发生，因为原始标题通常足够长
  }
  
  return result;
}

/**
 * 智能删除标题中的"语法问题"部分
 * 原则：只删除问题词，不重新组织语句
 * 约束：确保标题长度不小于30字符
 */
function removeGrammarIssues(title: string, language: 'es' | 'pt'): string {
  let result = title;
  
  // 检查是否以介词结尾
  const prepositionCheck = endsWithPreposition(result, language);
  
  if (prepositionCheck.hasPreposition) {
    // 智能删减：去掉介词及其后面的词（保持最小长度30字符）
    result = smartTruncate(result, 60, language, 30);
    
    console.log(`[${language.toUpperCase()}] 检测到介词结尾 "${prepositionCheck.preposition}"，已智能删减`);
  }
  
  // 检查是否有未完成的括号
  const openParens = (result.match(/[(【「]/g) || []).length;
  const closeParens = (result.match(/[)】」]/g) || []).length;
  
  if (openParens > closeParens) {
    // 去掉未闭合的括号内容
    result = result.replace(/[(【「][^)】」]*$/, '');
    console.log(`[${language.toUpperCase()}] 检测到未闭合括号，已删除`);
  }
  
  // 清理末尾标点
  result = result.trim().replace(/[.,!?;:\s]+$/, '');
  
  return result;
}

/**
 * 审查标题语法问题（只删减，不优化）
 * 约束：确保标题长度在30-60字符之间
 */
export async function reviewAndTruncateTitle(
  title: string,
  language: 'es' | 'pt'
): Promise<string> {
  const MIN_LENGTH = 30;
  const MAX_LENGTH = 60;
  
  console.log(`========== 标题审查 (${language === 'es' ? '西语' : '葡语'}) ==========`);
  console.log(`原始标题: "${title}" (${title.length}字符)`);
  console.log(`长度约束: ${MIN_LENGTH}-${MAX_LENGTH}字符`);
  
  // 如果标题已经符合要求，直接返回
  if (title.length <= MAX_LENGTH && title.length >= MIN_LENGTH) {
    const prepositionCheck = endsWithPreposition(title, language);
    if (!prepositionCheck.hasPreposition) {
      console.log(`✅ 标题无需修改`);
      return title;
    }
    console.log(`⚠️ 标题以介词结尾，需要删减`);
  } else if (title.length > MAX_LENGTH) {
    console.log(`⚠️ 标题超过${MAX_LENGTH}字符，需要删减`);
  } else {
    console.log(`ℹ️ 标题短于${MIN_LENGTH}字符`);
  }
  
  let result = title;
  
  // 第一步：智能截断到最大长度（同时保持最小长度）
  result = smartTruncate(result, MAX_LENGTH, language, MIN_LENGTH);
  console.log(`截断后: "${result}" (${result.length}字符)`);
  
  // 第二步：检查是否以介词结尾，智能删减
  result = removeGrammarIssues(result, language);
  console.log(`删减后: "${result}" (${result.length}字符)`);
  
  // 第三步：确保不超过最大长度
  if (result.length > MAX_LENGTH) {
    result = smartTruncate(result, MAX_LENGTH, language, MIN_LENGTH);
    console.log(`二次截断: "${result}" (${result.length}字符)`);
  }
  
  // 最终验证
  if (result.length > MAX_LENGTH) {
    console.error(`❌ 错误：标题仍然超过${MAX_LENGTH}字符`);
    result = result.substring(0, MAX_LENGTH);
    result = result.trim().replace(/[.,!?;:\s]+$/, '');
  }
  
  // 检查是否以介词结尾
  const finalCheck = endsWithPreposition(result, language);
  if (finalCheck.hasPreposition) {
    console.warn(`⚠️ 最终检查：仍然以介词结尾`);
    result = result.replace(new RegExp(`\\s+${finalCheck.preposition}.*$`), '');
    result = result.trim();
  }
  
  // 检查最小长度
  if (result.length < MIN_LENGTH) {
    console.warn(`⚠️ 最终检查：标题短于${MIN_LENGTH}字符`);
  }
  
  console.log(`✅ 最终结果: "${result}" (${result.length}字符)`);
  
  return result;
}

/**
 * 使用LLM检查语法问题并提供删减建议（可选）
 * 仅在标题仍然存在问题且需要智能删减建议时调用
 */
async function checkGrammarWithLLM(
  title: string,
  language: 'es' | 'pt'
): Promise<string> {
  const languageName = language === 'es' ? '西班牙语' : '葡萄牙语';
  
  const systemPrompt = `你是专业的${languageName}语法专家。你的任务：
1. 检查标题是否存在语法问题
2. 如果存在问题，只能删减问题词，不能重新组织语句
3. 确保删减后标题在60字符以内
4. 保持产品核心信息完整

原则：只做删减，不做优化！`;

  const userPrompt = `请审查以下${languageName}标题，删除有语法问题的部分：

原标题：${title}

问题类型：
- 以介词结尾（如 "para", "con", "de" 等）
- 未完成的句子
- 不通顺的词组

要求：
1. 只能删减，不能重新写
2. 删除问题词后确保标题在60字符以内
3. 保持标题通顺
4. 只输出删减后的标题，不要有其他说明`;

  try {
    const response = await invokeLLM(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      {
        temperature: 0.3,
        model: 'deepseek-v4-flash'
      }
    );
    
    let result = response.content.trim();
    
    // 移除可能的引号
    result = result.replace(/^["']|["']$/g, '');
    
    // 确保不超过60字符且不小于30字符
    if (result.length > 60) {
      result = smartTruncate(result, 60, language, 30);
    }
    
    return result;
    
  } catch (error) {
    console.error('LLM语法检查失败:', error);
    // 如果LLM失败，返回智能截断的结果
    return smartTruncate(title, 60, language);
  }
}

/**
 * 批量审查标题
 */
export async function reviewTitles(
  titles: { es: string; pt: string }
): Promise<{ es: string; pt: string }> {
  const [reviewedEs, reviewedPt] = await Promise.all([
    reviewAndTruncateTitle(titles.es, 'es'),
    reviewAndTruncateTitle(titles.pt, 'pt')
  ]);
  
  return {
    es: reviewedEs,
    pt: reviewedPt
  };
}

/**
 * 保留原有函数名作为别名，确保向后兼容
 */
export const optimizeTitles = reviewTitles;
