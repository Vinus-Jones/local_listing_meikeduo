import { S3Storage } from 'coze-coding-dev-sdk';

/**
 * 对象存储工具函数
 * 用于上传图片并返回永久可访问的URL
 */

// 初始化对象存储客户端
const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: '',
  secretKey: '',
  bucketName: process.env.COZE_BUCKET_NAME,
  region: 'cn-beijing',
});

/**
 * 从URL下载图片并上传到对象存储
 * @param imageUrl 图片URL
 * @param fileName 文件名（可选，不传则自动生成）
 * @returns 对象存储的访问URL
 */
export async function uploadImageFromUrl(
  imageUrl: string,
  fileName?: string
): Promise<string> {
  try {
    // 如果没有提供文件名，从URL中提取
    if (!fileName) {
      const urlParts = imageUrl.split('/');
      const originalName = urlParts[urlParts.length - 1] || 'image.jpg';
      // 添加时间戳避免冲突
      fileName = `generated_${Date.now()}_${originalName}`;
    }

    // 从URL下载并上传到对象存储
    const key = await storage.uploadFromUrl({
      url: imageUrl,
      timeout: 30000, // 30秒超时
    });

    // 生成永久可访问的URL（有效期7天）
    const signedUrl = await storage.generatePresignedUrl({
      key,
      expireTime: 7 * 24 * 60 * 60, // 7天
    });

    return signedUrl;
  } catch (error) {
    console.error('上传图片到对象存储失败:', error);
    throw new Error('上传图片失败，请重试');
  }
}

/**
 * 上传Buffer到对象存储
 * @param buffer 图片Buffer
 * @param fileName 文件名
 * @param contentType 文件类型
 * @returns 对象存储的访问URL
 */
export async function uploadImageBuffer(
  buffer: Buffer,
  fileName: string,
  contentType: string
): Promise<string> {
  try {
    // 添加时间戳避免冲突
    const uniqueFileName = `generated_${Date.now()}_${fileName}`;

    // 上传Buffer到对象存储
    const key = await storage.uploadFile({
      fileContent: buffer,
      fileName: uniqueFileName,
      contentType,
    });

    // 生成永久可访问的URL（有效期7天）
    const signedUrl = await storage.generatePresignedUrl({
      key,
      expireTime: 7 * 24 * 60 * 60, // 7天
    });

    return signedUrl;
  } catch (error) {
    console.error('上传Buffer到对象存储失败:', error);
    throw new Error('上传图片失败，请重试');
  }
}

/**
 * 批量上传图片URL到对象存储
 * @param imageUrls 图片URL数组
 * @param prefix 文件名前缀（用于区分不同批次的图片）
 * @returns 对象存储的访问URL数组
 */
export async function batchUploadImagesFromUrls(
  imageUrls: string[],
  prefix: string = 'batch'
): Promise<string[]> {
  try {
    const uploadPromises = imageUrls.map((url, index) =>
      uploadImageFromUrl(url, `${prefix}_${index}.jpg`)
    );

    const urls = await Promise.all(uploadPromises);
    return urls;
  } catch (error) {
    console.error('批量上传图片到对象存储失败:', error);
    throw new Error('批量上传图片失败，请重试');
  }
}

/**
 * 从对象存储获取文件URL
 * @param fileKey 对象存储的key
 * @param expireTime URL有效期（秒），默认7天
 * @returns 签名URL
 */
export async function getFileUrl(
  fileKey: string,
  expireTime: number = 7 * 24 * 60 * 60
): Promise<string> {
  try {
    return await storage.generatePresignedUrl({
      key: fileKey,
      expireTime,
    });
  } catch (error) {
    console.error('获取文件URL失败:', error);
    throw new Error('获取文件URL失败');
  }
}

/**
 * 检查文件是否存在
 * @param fileKey 对象存储的key
 * @returns 文件是否存在
 */
export async function fileExists(fileKey: string): Promise<boolean> {
  try {
    return await storage.fileExists({ fileKey });
  } catch (error) {
    console.error('检查文件存在性失败:', error);
    return false;
  }
}

/**
 * 删除文件
 * @param fileKey 对象存储的key
 * @returns 是否删除成功
 */
export async function deleteFile(fileKey: string): Promise<boolean> {
  try {
    return await storage.deleteFile({ fileKey });
  } catch (error) {
    console.error('删除文件失败:', error);
    return false;
  }
}

export default storage;
