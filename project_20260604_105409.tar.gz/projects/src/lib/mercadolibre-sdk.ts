/**
 * 美客多Listing生成器 - 客户端SDK
 *
 * 使用示例:
 *
 * ```typescript
 * import { MercadoLibreSDK } from '@/lib/mercadolibre-sdk';
 *
 * const sdk = new MercadoLibreSDK({
 *   baseUrl: 'https://your-domain.com',
 *   maxRetries: 3,
 *   retryDelay: 1000,
 * });
 *
 * // 单个生成
 * const result = await sdk.generateListing({
 *   title: 'Wireless Bluetooth Headphones',
 *   features: 'Noise cancellation, 30h battery',
 *   language: 'es'
 * });
 *
 * // 批量生成
 * const results = await sdk.generateBatch([
 *   { title: 'Product 1', language: 'es' },
 *   { title: 'Product 2', language: 'pt' },
 * ], { concurrency: 3 });
 *
 * // 带进度回调
 * sdk.onProgress((progress) => {
 *   console.log(`进度: ${progress.completed}/${progress.total}`);
 * });
 * ```
 */

export interface GenerateListingParams {
  title?: string;
  description?: string;
  features?: string;
  targetCountry?: 'MX' | 'BR' | 'CO' | 'AR' | 'CL';
  language?: 'es' | 'pt';
}

export interface ListingResult {
  title_es?: string;
  title_pt?: string;
  description_es?: string;
  description_pt?: string;
  parameters_es?: string[];
  parameters_pt?: string[];
  keywords_es?: string[];
  keywords_pt?: string[];
}

export interface BatchItem {
  productName?: string;
  title?: string;
  description?: string;
  features?: string;
  targetCountry?: 'MX' | 'BR' | 'CO' | 'AR' | 'CL';
  language?: 'es' | 'pt';
}

export interface BatchResult {
  index: number;
  success: boolean;
  data?: ListingResult;
  error?: string;
}

export interface SDKConfig {
  baseUrl: string;
  maxRetries?: number;
  retryDelay?: number;
  timeout?: number;
  headers?: Record<string, string>;
}

export interface ProgressEvent {
  total: number;
  completed: number;
  failed: number;
  current?: BatchItem;
}

/**
 * MercadoLibre SDK 客户端
 */
export class MercadoLibreSDK {
  private baseUrl: string;
  private maxRetries: number;
  private retryDelay: number;
  private timeout: number;
  private headers: Record<string, string>;
  private progressCallbacks: Array<(event: ProgressEvent) => void> = [];

  constructor(config: SDKConfig) {
    this.baseUrl = config.baseUrl.replace(/\/$/, ''); // 去除末尾斜杠
    this.maxRetries = config.maxRetries ?? 3;
    this.retryDelay = config.retryDelay ?? 1000;
    this.timeout = config.timeout ?? 60000; // 默认60秒
    this.headers = {
      'Content-Type': 'application/json',
      ...config.headers,
    };
  }

  /**
   * 注册进度回调
   */
  onProgress(callback: (event: ProgressEvent) => void): void {
    this.progressCallbacks.push(callback);
  }

  /**
   * 触发进度事件
   */
  private emitProgress(event: ProgressEvent): void {
    this.progressCallbacks.forEach((cb) => cb(event));
  }

  /**
   * 带重试的fetch请求
   */
  private async fetchWithRetry<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);

        const response = await fetch(`${this.baseUrl}${endpoint}`, {
          ...options,
          headers: this.headers,
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        // 处理HTTP错误
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(
            errorData.error || errorData.message || `HTTP ${response.status}`
          );
        }

        const data = await response.json();

        // 检查业务错误
        if (!data.success && data.error) {
          throw new Error(data.error);
        }

        return data.data ?? data;
      } catch (error) {
        lastError =
          error instanceof Error
            ? error
            : new Error('未知错误');

        // 如果是AbortError（超时），立即重试
        if (error instanceof DOMException && error.name === 'AbortError') {
          lastError = new Error('请求超时');
        }

        if (attempt < this.maxRetries) {
          console.warn(
            `请求失败 (${lastError.message})，${this.retryDelay * (attempt + 1)}ms后重试...`
          );
          await this.sleep(this.retryDelay * (attempt + 1));
        }
      }
    }

    throw lastError || new Error('请求失败');
  }

  /**
   * 延迟函数
   */
  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * 生成单个Listing
   */
  async generateListing(
    params: GenerateListingParams
  ): Promise<ListingResult> {
    // 构建请求参数
    const requestParams: Record<string, string> = {};

    if (params.title) requestParams.title = params.title;
    if (params.description) requestParams.description = params.description;

    // 使用generate-listing-manual端点
    return this.fetchWithRetry<ListingResult>(
      '/api/generate-listing-manual',
      {
        method: 'POST',
        body: JSON.stringify(requestParams),
      }
    );
  }

  /**
   * 生成单个Listing（优化版本，使用新接口）
   */
  async generateListingOptimized(
    productName: string,
    features: string,
    options?: {
      targetCountry?: 'MX' | 'BR' | 'CO' | 'AR' | 'CL';
      language?: 'es' | 'pt';
    }
  ): Promise<ListingResult> {
    return this.fetchWithRetry<ListingResult>('/api/generate-listing', {
      method: 'POST',
      body: JSON.stringify({
        productName,
        features,
        targetCountry: options?.targetCountry || 'MX',
        language: options?.language || 'es',
      }),
    });
  }

  /**
   * 批量生成Listing
   */
  async generateBatch(
    products: BatchItem[],
    options?: {
      concurrency?: number;
      onProgress?: (event: ProgressEvent) => void;
    }
  ): Promise<BatchResult[]> {
    if (options?.onProgress) {
      this.onProgress(options.onProgress);
    }

    const response = await this.fetchWithRetry<{
      total: number;
      success: number;
      failed: number;
      results: BatchResult[];
    }>(
      '/api/generate-listing-batch',
      {
        method: 'POST',
        body: JSON.stringify({
          products: products.map((p) => ({
            productName: p.productName || p.title || '',
            features: p.features || p.description || '',
            targetCountry: p.targetCountry || 'MX',
            language: p.language || 'es',
          })),
          maxConcurrency: options?.concurrency || 3,
        }),
      }
    );

    // 触发进度完成事件
    this.emitProgress({
      total: response.total,
      completed: response.success,
      failed: response.failed,
    });

    return response.results;
  }

  /**
   * 识图生成Listing
   */
  async generateFromImage(
    imageUrl: string,
    options?: {
      language?: 'es' | 'pt';
      enhance?: boolean;
    }
  ): Promise<ListingResult> {
    return this.fetchWithRetry<ListingResult>('/api/generate-listing-image', {
      method: 'POST',
      body: JSON.stringify({
        imageUrl,
        language: options?.language || 'es',
        enhance: options?.enhance ?? false,
      }),
    });
  }

  /**
   * 批量识图生成Listing
   */
  async generateBatchFromImages(
    images: string[],
    options?: {
      concurrency?: number;
      language?: 'es' | 'pt';
      enhance?: boolean;
      onProgress?: (event: ProgressEvent) => void;
    }
  ): Promise<BatchResult[]> {
    if (options?.onProgress) {
      this.onProgress(options.onProgress);
    }

    const response = await this.fetchWithRetry<{
      total: number;
      success: number;
      failed: number;
      results: BatchResult[];
    }>(
      '/api/generate-listing-image-batch',
      {
        method: 'POST',
        body: JSON.stringify({
          images,
          language: options?.language || 'es',
          enhance: options?.enhance ?? false,
          maxConcurrency: options?.concurrency || 2,
        }),
      }
    );

    return response.results;
  }

  /**
   * 图片识别优化
   */
  async enhanceFromImage(
    originalDescription: string,
    imageUrl: string,
    options?: {
      language?: 'es' | 'pt';
    }
  ): Promise<{ enhancedDescription: string }> {
    return this.fetchWithRetry<{ enhancedDescription: string }>(
      '/api/image-description-enhance',
      {
        method: 'POST',
        body: JSON.stringify({
          originalDescription,
          imageUrl,
          language: options?.language || 'es',
        }),
      }
    );
  }

  /**
   * 健康检查
   */
  async healthCheck(): Promise<boolean> {
    try {
      await this.fetchWithRetry<{ status: string }>('/api/health', {
        method: 'GET',
      });
      return true;
    } catch {
      return false;
    }
  }
}

// 导出默认实例工厂函数
export function createSDK(baseUrl: string): MercadoLibreSDK {
  return new MercadoLibreSDK({ baseUrl });
}

// 导出类型
export type { SDKConfig as MercadoLibreSDKConfig };
