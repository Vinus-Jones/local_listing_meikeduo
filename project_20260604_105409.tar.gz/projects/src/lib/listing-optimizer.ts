/**
 * 美客多Listing优化器
 * 包含：本地化词库、关键词分层、质量评分
 */

// ==================== 本地化词库 ====================

/**
 * 产品品类核心词汇（墨西哥西语 / 巴西葡语）
 */
export const CATEGORY_VOCABULARY: Record<string, { es: string; pt: string; esPriority: number; ptPriority: number }> = {
  // 电子产品
  headphones: { es: 'audífonos', pt: 'fones de ouvido', esPriority: 1, ptPriority: 1 },
  earbuds: { es: 'auriculares', pt: 'auriculares', esPriority: 2, ptPriority: 2 },
  speaker: { es: 'altavoz', pt: 'alto-falante', esPriority: 1, ptPriority: 1 },
  charger: { es: 'cargador', pt: 'carregador', esPriority: 1, ptPriority: 1 },
  cable: { es: 'cable', pt: 'cabo', esPriority: 1, ptPriority: 1 },
  phone_case: { es: 'funda', pt: 'capa', esPriority: 1, ptPriority: 1 },
  screen_protector: { es: 'protector de pantalla', pt: 'protetor de tela', esPriority: 1, ptPriority: 1 },
  power_bank: { es: 'batería externa', pt: 'power bank', esPriority: 1, ptPriority: 1 },
  smartwatch: { es: 'reloj inteligente', pt: 'smartwatch', esPriority: 1, ptPriority: 1 },
  
  // 家居用品
  lamp: { es: 'lámpara', pt: 'lâmpada', esPriority: 1, ptPriority: 1 },
  pillow: { es: 'almohada', pt: 'travesseiro', esPriority: 1, ptPriority: 1 },
  blanket: { es: 'manta', pt: 'cobertor', esPriority: 1, ptPriority: 1 },
  rug: { es: 'tapete', pt: 'tapete', esPriority: 1, ptPriority: 1 },
  curtain: { es: 'cortina', pt: 'cortina', esPriority: 1, ptPriority: 1 },
  organizer: { es: 'organizador', pt: 'organizador', esPriority: 1, ptPriority: 1 },
  
  // 户外运动
  backpack: { es: 'mochila', pt: 'mochila', esPriority: 1, ptPriority: 1 },
  water_bottle: { es: 'botella de agua', pt: 'garrafa de água', esPriority: 1, ptPriority: 1 },
  fitness: { es: 'fitness', pt: 'fitness', esPriority: 1, ptPriority: 1 },
  sports: { es: 'deportes', pt: 'esportes', esPriority: 1, ptPriority: 1 },
  
  // 美妆个护
  makeup: { es: 'maquillaje', pt: 'maquiagem', esPriority: 1, ptPriority: 1 },
  skincare: { es: 'cuidado de la piel', pt: 'cuidados com a pele', esPriority: 1, ptPriority: 1 },
  hair: { es: 'cabello', pt: 'cabelo', esPriority: 1, ptPriority: 1 },
  
  // 服饰配饰
  watch: { es: 'reloj', pt: 'relógio', esPriority: 1, ptPriority: 1 },
  sunglasses: { es: 'lentes de sol', pt: 'óculos de sol', esPriority: 1, ptPriority: 1 },
  jewelry: { es: 'joyería', pt: 'joias', esPriority: 1, ptPriority: 1 },
  bag: { es: 'bolsa', pt: 'bolsa', esPriority: 1, ptPriority: 1 },
  wallet: { es: 'cartera', pt: 'carteira', esPriority: 1, ptPriority: 1 },
  
  // 玩具儿童
  toys: { es: 'juguetes', pt: 'brinquedos', esPriority: 1, ptPriority: 1 },
  kids: { es: 'niños', pt: 'crianças', esPriority: 1, ptPriority: 1 },
  baby: { es: 'bebé', pt: 'bebê', esPriority: 1, ptPriority: 1 },
};

/**
 * 功能属性词汇（属性词层）
 */
export const ATTRIBUTE_VOCABULARY: Record<string, { es: string; pt: string }> = {
  // 连接方式
  wireless: { es: 'inalámbrico', pt: 'sem fio' },
  bluetooth: { es: 'bluetooth', pt: 'bluetooth' },
  usb: { es: 'USB', pt: 'USB' },
  
  // 防护特性
  waterproof: { es: 'impermeable', pt: 'impermeável' },
  water_resistant: { es: 'resistente al agua', pt: 'resistente à água' },
  dustproof: { es: 'a prueba de polvo', pt: 'à prova de poeira' },
  
  // 电池续航
  rechargeable: { es: 'recargable', pt: 'recarregável' },
  long_battery: { es: 'larga duración', pt: 'longa duração' },
  
  // 尺寸形态
  portable: { es: 'portátil', pt: 'portátil' },
  compact: { es: 'compacto', pt: 'compacto' },
  mini: { es: 'mini', pt: 'mini' },
  foldable: { es: 'plegable', pt: 'dobrável' },
  
  // 设计风格
  ergonomic: { es: 'ergonómico', pt: 'ergonômico' },
  modern: { es: 'moderno', pt: 'moderno' },
  elegant: { es: 'elegante', pt: 'elegante' },
  minimalist: { es: 'minimalista', pt: 'minimalista' },
  
  // 使用特性
  automatic: { es: 'automático', pt: 'automático' },
  adjustable: { es: 'ajustable', pt: 'ajustável' },
  multifunction: { es: 'multifunción', pt: 'multifuncional' },
  smart: { es: 'inteligente', pt: 'inteligente' },
  
  // 音频特性
  noise_canceling: { es: 'cancelación de ruido', pt: 'cancelamento de ruído' },
  surround_sound: { es: 'sonido envolvente', pt: 'som surround' },
  stereo: { es: 'estéreo', pt: 'estéreo' },
  bass: { es: 'graves', pt: 'graves' },
  
  // 显示特性
  hd: { es: 'alta definición', pt: 'alta definição' },
  led: { es: 'LED', pt: 'LED' },
  touch_screen: { es: 'pantalla táctil', pt: 'tela sensível ao toque' },
};

/**
 * 使用场景词汇（场景词层）
 */
export const SCENE_VOCABULARY: Record<string, { es: string; pt: string }> = {
  // 场所场景
  home: { es: 'hogar', pt: 'casa' },
  office: { es: 'oficina', pt: 'escritório' },
  outdoor: { es: 'exterior', pt: 'ao ar livre' },
  indoor: { es: 'interior', pt: 'interno' },
  car: { es: 'coche', pt: 'carro' },
  travel: { es: 'viaje', pt: 'viagem' },
  
  // 活动场景
  gaming: { es: 'gamer', pt: 'gamer' },
  sports: { es: 'deportes', pt: 'esportes' },
  workout: { es: 'ejercicio', pt: 'exercício' },
  running: { es: 'correr', pt: 'corrida' },
  camping: { es: 'camping', pt: 'acampamento' },
  party: { es: 'fiesta', pt: 'festa' },
  
  // 用户群体
  professional: { es: 'profesional', pt: 'profissional' },
  student: { es: 'estudiante', pt: 'estudante' },
  gift: { es: 'regalo', pt: 'presente' },
  family: { es: 'familia', pt: 'família' },
  
  // 时间场景
  daily: { es: 'uso diario', pt: 'uso diário' },
  night: { es: 'nocturno', pt: 'noturno' },
  weekend: { es: 'fin de semana', pt: 'fim de semana' },
};

/**
 * 长尾关键词模板
 */
export const LONGTAIL_TEMPLATES = {
  es: [
    'para {scene}',
    'ideal para {scene}',
    'con {feature}',
    'para {user}',
    'de {material}',
    'con {duration} horas',
    'versión {version}',
  ],
  pt: [
    'para {scene}',
    'ideal para {scene}',
    'com {feature}',
    'para {user}',
    'de {material}',
    'com {duration} horas',
    'versão {version}',
  ],
};

// ==================== 禁用词库 ====================

/**
 * 禁用词汇列表
 */
export const FORBIDDEN_WORDS = {
  // 夸大类
  exaggerated: {
    es: ['mejor', 'número 1', 'garantizado', '100%', 'único', 'increíble', 'perfecto', 'milagro'],
    pt: ['melhor', 'número 1', 'garantido', '100%', 'único', 'incrível', 'perfeito', 'milagre'],
  },
  // 医疗类
  medical: {
    es: ['cura', 'trata', 'elimina', 'previene', 'saludable', 'terapéutico', 'medicinal'],
    pt: ['cura', 'trata', 'elimina', 'previne', 'saudável', 'terapêutico', 'medicinal'],
  },
  // 法律风险类
  legal: {
    es: ['garantía de por vida', 'reembolso total', 'dinero devuelto', 'satisfacción garantizada'],
    pt: ['garantia vitalícia', 'reembolso total', 'dinheiro devolvido', 'satisfação garantida'],
  },
};

/**
 * 品牌词（需授权使用）
 */
export const BRAND_WORDS = [
  'Apple', 'Samsung', 'Sony', 'Nike', 'Adidas', 'Xiaomi', 'Huawei',
  'iPhone', 'Galaxy', 'AirPods', 'PlayStation', 'Xbox', 'Nintendo',
];

// ==================== 关键词分层体系 ====================

export interface KeywordLayer {
  layer: 'core' | 'attribute' | 'scene' | 'longtail';
  keywords: string[];
  priority: number; // 1-4, 1最高
}

export interface OptimizedKeywords {
  core: string[];      // 核心词 3-5个
  attribute: string[]; // 属性词 5-8个
  scene: string[];     // 场景词 4-6个
  longtail: string[];  // 长尾词 3-5个
  total: number;
}

// ==================== 质量评分系统 ====================

export interface QualityScore {
  overall: number;     // 总分 0-100
  dimensions: {
    keywordCoverage: number;    // 关键词覆盖 0-30分
    charUtilization: number;    // 字符利用 0-20分
    grammar: number;            // 语法正确 0-20分
    localization: number;       // 本地化程度 0-15分
    conversion: number;         // 转化元素 0-15分
  };
  issues: string[];    // 问题列表
  suggestions: string[]; // 优化建议
}

/**
 * 计算标题质量评分
 */
export function scoreTitle(title: string, lang: 'es' | 'pt'): QualityScore {
  const issues: string[] = [];
  const suggestions: string[] = [];
  const dimensions = {
    keywordCoverage: 0,
    charUtilization: 0,
    grammar: 0,
    localization: 0,
    conversion: 0,
  };

  // 1. 字符利用率评分 (0-20分)
  const length = title.length;
  if (length >= 50 && length <= 60) {
    // 最佳范围：50-60字符
    dimensions.charUtilization = 20;
  } else if (length >= 40 && length < 50) {
    dimensions.charUtilization = 15;
    suggestions.push(lang === 'es' 
      ? '可添加更多关键词提升字符利用率' 
      : 'Pode adicionar mais palavras-chave');
  } else if (length >= 30 && length < 40) {
    dimensions.charUtilization = 12;
    suggestions.push(lang === 'es' 
      ? '字符利用率偏低，建议补充关键词' 
      : 'Utilização de caracteres baixa, adicione mais palavras-chave');
  } else if (length < 30) {
    dimensions.charUtilization = 5;
    issues.push('标题过短（少于30字符），严重影响曝光');
  } else {
    dimensions.charUtilization = 10;
    issues.push('标题超过60字符将被截断');
  }

  // 2. 关键词覆盖评分 (0-30分)
  const titleLower = title.toLowerCase();
  let keywordCount = 0;
  
  // 检查核心品类词
  Object.values(CATEGORY_VOCABULARY).forEach(vocab => {
    const word = lang === 'es' ? vocab.es : vocab.pt;
    if (titleLower.includes(word.toLowerCase())) {
      keywordCount++;
    }
  });
  
  // 检查属性词
  Object.values(ATTRIBUTE_VOCABULARY).forEach(vocab => {
    const word = lang === 'es' ? vocab.es : vocab.pt;
    if (titleLower.includes(word.toLowerCase())) {
      keywordCount++;
    }
  });
  
  if (keywordCount >= 5) {
    dimensions.keywordCoverage = 30;
  } else if (keywordCount >= 4) {
    dimensions.keywordCoverage = 25;
  } else if (keywordCount >= 3) {
    dimensions.keywordCoverage = 20;
  } else if (keywordCount >= 2) {
    dimensions.keywordCoverage = 15;
    issues.push('关键词数量不足');
  } else {
    dimensions.keywordCoverage = 10;
    issues.push('严重缺少关键词');
  }

  // 3. 本地化程度评分 (0-15分)
  // 检查是否使用了正确的本地化词汇
  let localizationScore = 10; // 基础分
  
  // 检查是否有典型错误用法
  if (lang === 'es') {
    if (titleLower.includes('fones') || titleLower.includes('ouvido')) {
      issues.push('标题中使用了葡语词汇');
      localizationScore -= 5;
    }
  } else {
    if (titleLower.includes('audífonos') || titleLower.includes('inalámbrico')) {
      issues.push('标题中使用了西语词汇');
      localizationScore -= 5;
    }
  }
  
  dimensions.localization = Math.max(0, localizationScore);

  // 4. 语法评分 (基础分，实际需要LLM检查)
  dimensions.grammar = 15; // 假设通过语法检查

  // 5. 转化元素评分 (0-15分)
  const conversionWords = lang === 'es' 
    ? ['nuevo', 'oferta', 'envío gratis', 'original', 'premium']
    : ['novo', 'oferta', 'frete grátis', 'original', 'premium'];
  
  let conversionScore = 8; // 基础分
  conversionWords.forEach(word => {
    if (titleLower.includes(word)) {
      conversionScore += 2;
    }
  });
  dimensions.conversion = Math.min(15, conversionScore);

  // 计算总分
  const overall = Object.values(dimensions).reduce((a, b) => a + b, 0);

  return {
    overall,
    dimensions,
    issues,
    suggestions,
  };
}

/**
 * 计算描述质量评分
 */
export function scoreDescription(description: string, lang: 'es' | 'pt'): QualityScore {
  const issues: string[] = [];
  const suggestions: string[] = [];
  const dimensions = {
    keywordCoverage: 0,
    charUtilization: 0,
    grammar: 0,
    localization: 0,
    conversion: 0,
  };

  // 1. 字符长度评分
  const length = description.length;
  if (length >= 200 && length <= 1000) {
    dimensions.charUtilization = 20;
  } else if (length < 200) {
    dimensions.charUtilization = 10;
    issues.push('描述过短，建议添加更多产品信息');
  } else {
    dimensions.charUtilization = 15;
    suggestions.push('描述较长，确保移动端阅读体验');
  }

  // 2. 关键词覆盖
  const descLower = description.toLowerCase();
  let keywordCount = 0;
  
  Object.values(ATTRIBUTE_VOCABULARY).forEach(vocab => {
    const word = lang === 'es' ? vocab.es : vocab.pt;
    if (descLower.includes(word.toLowerCase())) {
      keywordCount++;
    }
  });
  
  dimensions.keywordCoverage = Math.min(30, 10 + keywordCount * 3);

  // 3. 本地化程度
  dimensions.localization = 12;

  // 4. 语法
  dimensions.grammar = 15;

  // 5. 转化元素
  const hasCallToAction = lang === 'es'
    ? /incluye|contiene|ideal|perfecto/.test(descLower)
    : /inclui|contém|ideal|perfeito/.test(descLower);
  
  dimensions.conversion = hasCallToAction ? 15 : 10;

  const overall = Object.values(dimensions).reduce((a, b) => a + b, 0);

  return {
    overall,
    dimensions,
    issues,
    suggestions,
  };
}

/**
 * 检查禁用词
 */
export function checkForbiddenWords(text: string, lang: 'es' | 'pt'): string[] {
  const found: string[] = [];
  const textLower = text.toLowerCase();
  
  const forbiddenList = [
    ...FORBIDDEN_WORDS.exaggerated[lang],
    ...FORBIDDEN_WORDS.medical[lang],
    ...FORBIDDEN_WORDS.legal[lang],
  ];
  
  forbiddenList.forEach(word => {
    if (textLower.includes(word.toLowerCase())) {
      found.push(word);
    }
  });
  
  // 检查品牌词
  BRAND_WORDS.forEach(brand => {
    if (textLower.includes(brand.toLowerCase())) {
      found.push(`品牌词: ${brand}`);
    }
  });
  
  return found;
}

// ==================== 标题优化函数 ====================

/**
 * 分析标题关键词
 */
export function analyzeTitleKeywords(title: string, lang: 'es' | 'pt'): {
  core: string[];
  attribute: string[];
  scene: string[];
  coverage: number;
} {
  const titleLower = title.toLowerCase();
  const core: string[] = [];
  const attribute: string[] = [];
  const scene: string[] = [];
  
  // 检查核心词
  Object.entries(CATEGORY_VOCABULARY).forEach(([key, vocab]) => {
    const word = lang === 'es' ? vocab.es : vocab.pt;
    if (titleLower.includes(word.toLowerCase())) {
      core.push(word);
    }
  });
  
  // 检查属性词
  Object.entries(ATTRIBUTE_VOCABULARY).forEach(([key, vocab]) => {
    const word = lang === 'es' ? vocab.es : vocab.pt;
    if (titleLower.includes(word.toLowerCase())) {
      attribute.push(word);
    }
  });
  
  // 检查场景词
  Object.entries(SCENE_VOCABULARY).forEach(([key, vocab]) => {
    const word = lang === 'es' ? vocab.es : vocab.pt;
    if (titleLower.includes(word.toLowerCase())) {
      scene.push(word);
    }
  });
  
  const totalKeywords = core.length + attribute.length + scene.length;
  const coverage = Math.min(100, totalKeywords * 10);
  
  return { core, attribute, scene, coverage };
}

/**
 * 生成标题优化建议
 */
export function getTitleOptimizationSuggestions(
  title: string, 
  lang: 'es' | 'pt'
): string[] {
  const suggestions: string[] = [];
  const analysis = analyzeTitleKeywords(title, lang);
  
  // 字符长度建议
  if (title.length < 55) {
    const remaining = 60 - title.length;
    suggestions.push(`还可添加 ${remaining} 个字符`);
  }
  
  // 关键词建议
  if (analysis.core.length === 0) {
    suggestions.push('缺少核心品类词，建议添加产品类型关键词');
  }
  
  if (analysis.attribute.length < 2) {
    suggestions.push('属性词不足，建议添加功能特性关键词');
  }
  
  if (analysis.scene.length === 0) {
    suggestions.push('缺少场景词，建议添加使用场景关键词');
  }
  
  return suggestions;
}
