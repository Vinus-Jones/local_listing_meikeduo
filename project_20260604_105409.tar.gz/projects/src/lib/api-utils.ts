/**
 * 提高API效率和成功率的工具函数
 */

// 最大重试次数
const MAX_RETRIES = 3;
// 重试延迟（毫秒）
const RETRY_DELAY = 1000;
// 并发限制
const MAX_CONCURRENT = 5;

/**
 * 带重试机制的API调用
 */
export async function fetchWithRetry(
  url: string,
  options: RequestInit = {},
  retries: number = MAX_RETRIES
): Promise<Response> {
  for (let i = 0; i < retries; i++) {
    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      // 如果是服务器错误（5xx），重试
      if (response.status >= 500) {
        console.warn(`请求失败 (${response.status})，${RETRY_DELAY}ms后重试... (${i + 1}/${retries})`);
        await sleep(RETRY_DELAY * (i + 1)); // 递增延迟
        continue;
      }

      return response;
    } catch (error) {
      if (i === retries - 1) {
        throw error;
      }
      console.warn(`网络错误，${RETRY_DELAY}ms后重试... (${i + 1}/${retries})`);
      await sleep(RETRY_DELAY * (i + 1));
    }
  }

  throw new Error('重试次数耗尽');
}

/**
 * 批量处理API调用
 * 支持并行处理多个请求，同时限制并发数
 */
export async function batchProcess<T, R>(
  items: T[],
  processor: (item: T) => Promise<R>,
  concurrency: number = MAX_CONCURRENT
): Promise<R[]> {
  const results: R[] = [];
  const queue = [...items];
  const processing: Promise<void>[] = [];

  while (queue.length > 0 || processing.length > 0) {
    // 控制并发数
    while (queue.length > 0 && processing.length < concurrency) {
      const item = queue.shift()!;
      const promise = processor(item)
        .then((result) => {
          results.push(result);
        })
        .catch((error) => {
          console.error('批量处理出错:', error);
          results.push({ error: error.message } as unknown as R);
        })
        .finally(() => {
          const index = processing.indexOf(promise);
          if (index > -1) {
            processing.splice(index, 1);
          }
        });

      processing.push(promise);
    }

    // 等待任意一个完成
    if (processing.length > 0) {
      await Promise.race(processing);
    }
  }

  return results;
}

/**
 * 简单延迟函数
 */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * 请求限流器
 */
export class RateLimiter {
  private tokens: number;
  private readonly maxTokens: number;
  private readonly refillRate: number; // 每秒补充的token数
  private lastRefill: number;

  constructor(maxTokens: number = 10, refillPerSecond: number = 5) {
    this.maxTokens = maxTokens;
    this.tokens = maxTokens;
    this.refillRate = refillPerSecond;
    this.lastRefill = Date.now();
  }

  async acquire(): Promise<void> {
    this.refill();

    if (this.tokens > 0) {
      this.tokens--;
      return;
    }

    // 等待一个token
    await sleep(1000 / this.refillRate);
    return this.acquire();
  }

  private refill(): void {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000;
    const newTokens = elapsed * this.refillRate;

    this.tokens = Math.min(this.maxTokens, this.tokens + newTokens);
    this.lastRefill = now;
  }
}

/**
 * 缓存管理器
 */
export class CacheManager {
  private cache: Map<string, { value: unknown; expiry: number }> = new Map();
  private readonly defaultTTL: number; // 默认过期时间（毫秒）

  constructor(defaultTTL: number = 1000 * 60 * 30) {
    // 30分钟默认过期
    this.defaultTTL = defaultTTL;
  }

  get<T>(key: string): T | null {
    const item = this.cache.get(key);

    if (!item) {
      return null;
    }

    if (Date.now() > item.expiry) {
      this.cache.delete(key);
      return null;
    }

    return item.value as T;
  }

  set(key: string, value: unknown, ttl?: number): void {
    this.cache.set(key, {
      value,
      expiry: Date.now() + (ttl || this.defaultTTL),
    });
  }

  delete(key: string): void {
    this.cache.delete(key);
  }

  clear(): void {
    this.cache.clear();
  }

  // 生成缓存key
  static generateKey(prefix: string, params: Record<string, unknown>): string {
    const sortedParams = Object.keys(params)
      .sort()
      .map((k) => `${k}=${params[k]}`)
      .join('&');
    return `${prefix}:${sortedParams}`;
  }
}

/**
 * API响应格式化
 */
export function formatResponse<T>(data: T, message?: string): {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  timestamp: string;
} {
  return {
    success: true,
    data,
    message,
    timestamp: new Date().toISOString(),
  };
}

/**
 * API错误响应格式化
 */
export function formatErrorResponse(error: unknown, context?: string): {
  success: boolean;
  error: string;
  message: string;
  timestamp: string;
} {
  const errorMessage =
    error instanceof Error ? error.message : '未知错误';

  return {
    success: false,
    error: errorMessage,
    message: context
      ? `在 ${context} 时发生错误: ${errorMessage}`
      : errorMessage,
    timestamp: new Date().toISOString(),
  };
}

/**
 * 验证必填参数
 */
export function validateRequired(
  params: Record<string, unknown>,
  requiredFields: string[]
): string[] {
  const errors: string[] = [];

  for (const field of requiredFields) {
    if (params[field] === undefined || params[field] === null || params[field] === '') {
      errors.push(`缺少必填参数: ${field}`);
    }
  }

  return errors;
}

/**
 * 输入清理
 */
export function sanitizeInput(input: string): string {
  return input
    .trim() // 去除首尾空白
    .replace(/\s+/g, ' ') // 合并多个空格
    .replace(/[<>]/g, '') // 移除潜在HTML标签
    .substring(0, 10000); // 限制最大长度
}

/**
 * 创建超时控制器
 */
export function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number = 30000
): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error('请求超时')), timeoutMs)
    ),
  ]);
}
