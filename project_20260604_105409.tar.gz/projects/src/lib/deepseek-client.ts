/**
 * DeepSeek LLM 客户端封装
 * 基于 OpenAI SDK，配置 DeepSeek API
 */

import OpenAI from 'openai';

// DeepSeek API 配置
const DEEPSEEK_CONFIG = {
  baseURL: 'https://api.deepseek.com',
  apiKey: process.env.DEEPSEEK_API_KEY || 'sk-f4fc430e2bc345b8afe2d37aee02dd13',
  model: 'deepseek-v4-flash',
};

// 创建 DeepSeek 客户端实例
let deepseekClient: OpenAI | null = null;

export function getDeepSeekClient(): OpenAI {
  if (!deepseekClient) {
    deepseekClient = new OpenAI({
      baseURL: DEEPSEEK_CONFIG.baseURL,
      apiKey: DEEPSEEK_CONFIG.apiKey,
    });
  }
  return deepseekClient;
}

// 消息类型定义
export interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

// LLM 调用选项
export interface LLMOptions {
  temperature?: number;
  maxTokens?: number;
  model?: string;
}

// LLM 响应类型
export interface LLMResponse {
  content: string;
  model: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

/**
 * 调用 DeepSeek LLM
 * @param messages 消息列表
 * @param options 调用选项
 * @returns LLM 响应
 */
export async function invokeLLM(
  messages: Message[],
  options: LLMOptions = {}
): Promise<LLMResponse> {
  const client = getDeepSeekClient();
  
  const {
    temperature = 0.7,
    maxTokens = 2000,
    model = DEEPSEEK_CONFIG.model,
  } = options;

  console.log('========== DeepSeek LLM 调用 ==========');
  console.log('模型:', model);
  console.log('温度:', temperature);
  console.log('最大Token:', maxTokens);
  console.log('消息数量:', messages.length);
  console.log('系统消息长度:', messages.find(m => m.role === 'system')?.content.length || 0);
  console.log('用户消息长度:', messages.find(m => m.role === 'user')?.content.length || 0);

  const response = await client.chat.completions.create({
    model: model,
    messages: messages as OpenAI.Chat.ChatCompletionMessageParam[],
    temperature: temperature,
    max_tokens: maxTokens,
  });

  const content = response.choices[0]?.message?.content || '';
  
  console.log('========== DeepSeek LLM 响应 ==========');
  console.log('响应长度:', content.length, '字符');
  console.log('响应前200字符:', content.substring(0, 200));
  console.log('Token使用:', response.usage);

  return {
    content,
    model: response.model,
    usage: response.usage ? {
      promptTokens: response.usage.prompt_tokens,
      completionTokens: response.usage.completion_tokens,
      totalTokens: response.usage.total_tokens,
    } : undefined,
  };
}

/**
 * 调用 DeepSeek LLM（流式版本）
 * @param messages 消息列表
 * @param options 调用选项
 * @returns ReadableStream
 */
export function invokeLLMStream(
  messages: Message[],
  options: LLMOptions = {}
): ReadableStream {
  const client = getDeepSeekClient();
  
  const {
    temperature = 0.7,
    maxTokens = 2000,
    model = DEEPSEEK_CONFIG.model,
  } = options;

  console.log('========== DeepSeek LLM 流式调用 ==========');
  console.log('模型:', model);
  console.log('温度:', temperature);

  const encoder = new TextEncoder();

  return new ReadableStream({
    async start(controller) {
      try {
        const stream = await client.chat.completions.create({
          model: model,
          messages: messages as OpenAI.Chat.ChatCompletionMessageParam[],
          temperature: temperature,
          max_tokens: maxTokens,
          stream: true,
        });

        // 使用流式响应
        const reader = stream.toReadableStream().getReader();
        
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = value.toString();
          if (chunk) {
            controller.enqueue(encoder.encode(chunk));
          }
        }
      } catch (error) {
        controller.error(error);
      } finally {
        controller.close();
      }
    },
  });
}

/**
 * 创建 SSE 流响应
 */
export function createSSEStream(stream: ReadableStream): Response {
  const encoder = new TextEncoder();
  
  const readable = new ReadableStream({
    async start(controller) {
      const reader = stream.getReader();
      
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = `data: ${value}\n\n`;
          controller.enqueue(encoder.encode(chunk));
        }
      } catch (error) {
        console.error('Stream error:', error);
      } finally {
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        controller.close();
      }
    },
  });

  return new Response(readable, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
