import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';
import { invokeLLM } from '@/lib/deepseek-client';

export async function POST(request: NextRequest) {
  try {
    const { image, currentDescription, targetLanguage } = await request.json();

    // 验证参数
    if (!image) {
      return NextResponse.json(
        { error: '请上传图片' },
        { status: 400 }
      );
    }

    if (!currentDescription) {
      return NextResponse.json(
        { error: '请提供当前的产品描述' },
        { status: 400 }
      );
    }

    if (!targetLanguage || !['es', 'pt'].includes(targetLanguage)) {
      return NextResponse.json(
        { error: '目标语言必须是 es (西班牙语) 或 pt (葡萄牙语)' },
        { status: 400 }
      );
    }

    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const visionClient = new LLMClient(config, customHeaders);

    const languageNames: Record<string, string> = {
      es: '西班牙语',
      pt: '葡萄牙语'
    };

    // 第1步：使用 Vision LLM 识别图片中的产品信息
    const visionMessages = [
      {
        role: 'user' as const,
        content: [
          {
            type: 'text' as const,
            text: `请详细分析这张产品图片，提取以下信息：

1. 产品类型和名称
2. 产品的外观特征（颜色、形状、尺寸等）
3. 材质和工艺特点
4. 使用场景和适用环境
5. 目标用户群体
6. 图片中的任何文字内容
7. 产品的核心卖点和优势

请按照以下格式输出：

【产品识别结果】
产品类型：
外观特征：
材质工艺：
使用场景：
目标用户：
图片文字：
核心卖点：`
          },
          {
            type: 'image_url' as const,
            image_url: {
              url: image,
              detail: 'high' as const
            }
          }
        ]
      }
    ];

    console.log('========== 步骤1：识别图片内容 ==========');
    const visionResponse = await visionClient.invoke(visionMessages, {
      model: 'doubao-seed-2-0-pro-260215',
      temperature: 0.3
    });

    const imageAnalysis = visionResponse.content;
    console.log('图片识别结果:', imageAnalysis.substring(0, 200));

    // 第2步：基于图片识别结果优化产品描述（使用DeepSeek）
    console.log('========== 步骤2：优化描述（DeepSeek） ==========');
    
    const systemPrompt = `你是一位美客多平台资深运营专家，精通${languageNames[targetLanguage]}。

【角色定位】
- 美客多SEO优化专家
- 精通关键词权重分析、本地化文案、转化率提升

【描述分层结构】
第1层：吸引力开篇（50字符内）
第2层：核心卖点（100-150字符）
第3层：使用场景（80-120字符）
第4层：信任要素（50-80字符）
第5层：行动召唤（30-50字符）

【禁用内容】
- 表情符号、链接、品牌词、夸大词`;

    const userPrompt = `请根据图片识别结果优化产品描述。

当前产品描述（${languageNames[targetLanguage]}）：
${currentDescription}

图片识别结果：
${imageAnalysis}

═══════════════════════════════════════
执行步骤：
1. 分析原描述的优缺点
2. 补充图片识别出的产品特征
3. 按5层结构重组描述
4. 增强描述的生动性

═══════════════════════════════════════
JSON输出格式：

{
  "optimized_description": "优化后的产品描述",
  "added_features": "从图片中提取并添加的新特征说明",
  "improvements": "相比原描述的改进点说明"
}

只输出JSON，不要其他文字。`;

    const llmResponse = await invokeLLM(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      {
        temperature: 0.3,
        model: 'deepseek-v4-flash'
      }
    );

    console.log('优化响应:', llmResponse.content.substring(0, 200));

    // 解析JSON响应
    let result;
    try {
      const jsonMatch = llmResponse.content.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? jsonMatch[0] : llmResponse.content;
      result = JSON.parse(jsonString);
    } catch (parseError) {
      console.error('JSON解析失败:', parseError);
      throw new Error('解析优化结果失败，请重试');
    }

    // 验证结果
    if (!result.optimized_description) {
      console.error('结果不完整:', result);
      throw new Error('优化结果不完整，请重试');
    }

    // 清理表情符号和特殊符号
    const cleanText = (text: string) => {
      return text
        .replace(/https?:\/\/[^\s]+/gi, '') // 删除HTTP链接
        .replace(/www\.[^\s]+/gi, '') // 删除www链接
        .replace(/[\u{1F600}-\u{1F64F}]/gu, '') // emoji
        .replace(/[\u{1F300}-\u{1F5FF}]/gu, '') // symbols
        .replace(/[\u{1F680}-\u{1F6FF}]/gu, '') // transport
        .replace(/[\u{1F700}-\u{1F77F}]/gu, '') // alchemical
        .replace(/[\u{1F780}-\u{1F7FF}]/gu, '') // geometric
        .replace(/[\u{1F800}-\u{1F8FF}]/gu, '') // arrows
        .replace(/[\u{1F900}-\u{1F9FF}]/gu, '') // supplemental
        .replace(/[\u{1FA00}-\u{1FA6F}]/gu, '') // chess
        .replace(/[\u{1FA70}-\u{1FAFF}]/gu, '') // symbols extended
        .replace(/[\u{2600}-\u{26FF}]/gu, '') // misc
        .replace(/[\u{2700}-\u{27BF}]/gu, '') // dingbats
        .replace(/[★✓✔✅❌]/g, '') // common symbols
        .replace(/【|】|「|」|『|』|《|》|〈|〉|（|）|〔|〕]/g, '') // brackets
        .replace(/─│┌┐└┘├┤┬┴┼═║╔╗╚╝╠╣╦╩╬]/g, '') // box drawing
        .replace(/→←↑↓↔↕↖↗↘↙/g, '') // arrows
        .trim();
    };

    result.optimized_description = cleanText(result.optimized_description);

    console.log('优化成功');

    return NextResponse.json({
      optimizedDescription: result.optimized_description,
      imageAnalysis: imageAnalysis,
      addedFeatures: result.added_features,
      improvements: result.improvements,

    });
  } catch (error) {
    console.error('优化失败:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : '优化失败，请重试' },
      { status: 500 }
    );
  }
}
