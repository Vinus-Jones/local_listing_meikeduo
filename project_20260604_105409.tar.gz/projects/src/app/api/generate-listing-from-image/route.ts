import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';
import { invokeLLM } from '@/lib/deepseek-client';
import { scoreTitle, scoreDescription, checkForbiddenWords } from '@/lib/listing-optimizer';

export async function POST(request: NextRequest) {
  try {
    const { image } = await request.json();

    if (!image) {
      return NextResponse.json({ error: '请提供图片' }, { status: 400 });
    }

    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const visionClient = new LLMClient(config, customHeaders);

    // 步骤1：使用Vision模型识别图片内容
    const visionPrompt = '请详细分析这张产品图片，识别以下信息：\n' +
      '1. 产品名称和类型\n' +
      '2. 颜色、材质、尺寸等外观特征\n' +
      '3. 主要功能和特点\n' +
      '4. 使用场景和适用人群\n' +
      '5. 包装包含的内容\n' +
      '6. 技术参数（如果可见）\n\n' +
      '请用简洁清晰的语言描述，格式为：\n' +
      '产品类型：[描述]\n' +
      '外观特征：[描述]\n' +
      '功能特点：[描述]\n' +
      '使用场景：[描述]\n' +
      '包装清单：[描述]\n' +
      '技术参数：[描述]';

    const visionMessages = [
      {
        role: 'user' as const,
        content: [
          { type: 'text' as const, text: visionPrompt },
          {
            type: 'image_url' as const,
            image_url: {
              url: image,
              detail: 'high' as const
            }
          }
        ]
      }
    ];

    console.log('========== 步骤1：识别图片内容 ==========');
    const visionResponse = await visionClient.invoke(visionMessages, {
      model: 'doubao-seed-2-0-pro-260215',
      temperature: 0.3
    });

    const imageAnalysis = visionResponse.content;
    console.log('图片识别结果:', imageAnalysis.substring(0, 200));

    // 步骤2：基于识别结果生成完整Listing（使用DeepSeek）
    console.log('========== 步骤2：生成Listing（DeepSeek） ==========');
    
    const systemPrompt = `你是一位美客多平台资深运营专家，精通拉美电商市场。你的核心能力是：

【角色定位】
- 美客多SEO优化专家，专注于墨西哥/智利/哥伦比亚（西语）和巴西（葡语）市场
- 精通关键词权重分析、本地化文案、转化率提升

【标题优化策略】
结构公式：[核心品类词] + [关键属性词] + [使用场景] + [差异化卖点]
字符权重：目标55-60字符
关键词密度：3-5个核心关键词

【描述分层结构】
第1层：吸引力开篇（50字符内）
第2层：核心卖点（100-150字符）
第3层：使用场景（80-120字符）
第4层：信任要素（50-80字符）
第5层：行动召唤（30-50字符）

【关键词分层体系】
核心词（3-5个）+ 属性词（5-8个）+ 场景词（4-6个）+ 长尾词（3-5个）

【禁用内容】
- 表情符号、链接、品牌词、夸大词
- 医疗类、法律风险类词汇

输出格式：严格JSON格式`;

    const userPrompt = `请根据以下产品图片识别结果，生成优化的美客多Listing：

【图片识别结果】
${imageAnalysis}

═══════════════════════════════════════
执行步骤：
1. 分析产品品类和核心特征
2. 规划关键词（核心词+属性词+场景词+长尾词）
3. 生成标题（55-60字符）
4. 生成描述（200-500字符，5层结构）
5. 提取参数（5-8个关键规格）

═══════════════════════════════════════
JSON输出格式：

{
  "title_es": "西语标题，55-60字符",
  "title_pt": "葡语标题，55-60字符",
  "description_es": "西语描述，200-500字符",
  "description_pt": "葡语描述，200-500字符",
  "parameters_es": ["• 参数1: 值1", "• 参数2: 值2"],
  "parameters_pt": ["• 参数1: 值1", "• 参数2: 值2"],
  "keywords_es": ["关键词1", "关键词2", "关键词3"],
  "keywords_pt": ["关键词1", "关键词2", "关键词3"]
}

只输出JSON，无其他文字。`;

    const llmResponse = await invokeLLM(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      {
        temperature: 0.3,
        model: 'deepseek-v4-flash'
      }
    );

    const content = llmResponse.content.trim();
    console.log('DeepSeek响应长度:', content.length);

    // 解析JSON响应
    let result;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      result = JSON.parse(jsonMatch ? jsonMatch[0] : content);
    } catch (parseError) {
      console.error('JSON解析失败:', parseError);
      throw new Error('解析LLM响应失败，请重试');
    }

    // 格式化参数
    if (result.parameters_es) {
      result.parameters_es = formatParameters(result.parameters_es);
    }
    if (result.parameters_pt) {
      result.parameters_pt = formatParameters(result.parameters_pt);
    }

    // 计算质量评分
    const qualityScore = {
      title_es: result.title_es ? scoreTitle(result.title_es, 'es') : null,
      title_pt: result.title_pt ? scoreTitle(result.title_pt, 'pt') : null,
      description_es: result.description_es ? scoreDescription(result.description_es, 'es') : null,
      description_pt: result.description_pt ? scoreDescription(result.description_pt, 'pt') : null,
    };

    // 检查禁用词
    const forbiddenCheck = {
      title_es: result.title_es ? checkForbiddenWords(result.title_es, 'es') : [],
      title_pt: result.title_pt ? checkForbiddenWords(result.title_pt, 'pt') : [],
      description_es: result.description_es ? checkForbiddenWords(result.description_es, 'es') : [],
      description_pt: result.description_pt ? checkForbiddenWords(result.description_pt, 'pt') : [],
    };

    // 添加质量评分
    result.quality = {
      score: qualityScore,
      forbiddenWords: forbiddenCheck,
    };

    console.log('========== 生成完成 ==========');
    console.log('西语标题:', result.title_es, `(${result.title_es?.length}字符)`);
    console.log('葡语标题:', result.title_pt, `(${result.title_pt?.length}字符)`);

    return NextResponse.json(result);

  } catch (error) {
    console.error('生成Listing失败:', error);
    return NextResponse.json(
      { error: '生成失败，请重试' },
      { status: 500 }
    );
  }
}

// 辅助函数：格式化参数
function formatParameters(params: any): string[] {
  if (!params) return [];
  if (!Array.isArray(params)) return [];
  return params.map((p: any) => {
    if (typeof p === 'string') {
      if (!p.startsWith('•')) {
        return '• ' + p;
      }
      return p;
    }
    return String(p);
  });
}
