import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';
import { invokeLLM } from '@/lib/deepseek-client';

export async function POST(request: NextRequest) {
  try {
    const { image, targetLanguage } = await request.json();

    if (!image) {
      return NextResponse.json({ error: '请提供图片' }, { status: 400 });
    }

    if (!targetLanguage || !['es', 'pt'].includes(targetLanguage)) {
      return NextResponse.json({ error: '请提供有效的目标语言（es 或 pt）' }, { status: 400 });
    }

    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const visionClient = new LLMClient(config, customHeaders);

    // 步骤1：使用Vision模型识别图片内容
    const visionPrompt = '请详细分析这张产品图片，识别以下信息：\n' +
      '1. 产品名称和类型\n' +
      '2. 颜色、材质、尺寸等外观特征\n' +
      '3. 主要功能和特点\n' +
      '4. 使用场景和适用人群\n' +
      '5. 包装包含的内容\n' +
      '6. 技术参数（如果可见）\n\n' +
      '请用简洁清晰的语言描述，格式为：\n' +
      '产品类型：[描述]\n' +
      '外观特征：[描述]\n' +
      '功能特点：[描述]\n' +
      '使用场景：[描述]\n' +
      '包装清单：[描述]\n' +
      '技术参数：[描述]';

    const visionMessages = [
      {
        role: 'user' as const,
        content: [
          { type: 'text' as const, text: visionPrompt },
          {
            type: 'image_url' as const,
            image_url: {
              url: image,
              detail: 'high' as const
            }
          }
        ]
      }
    ];

    console.log('========== 步骤1：识别图片内容 ==========');
    const visionResponse = await visionClient.invoke(visionMessages, {
      model: 'doubao-seed-2-0-pro-260215',
      temperature: 0.3
    });

    const imageAnalysis = visionResponse.content;
    console.log('图片识别结果:', imageAnalysis.substring(0, 200));

    // 步骤2：根据识别结果生成产品描述（使用DeepSeek）
    console.log('========== 步骤2：生成描述（DeepSeek） ==========');
    
    const languageName = targetLanguage === 'es' ? '拉美西语' : '巴西葡语';
    const marketInfo = targetLanguage === 'es' 
      ? '墨西哥、智利、哥伦比亚' 
      : '巴西';

    const systemPrompt = `你是一位美客多平台资深运营专家，精通${languageName}。

【角色定位】
- 美客多SEO优化专家，专注于${marketInfo}市场
- 精通关键词权重分析、本地化文案、转化率提升

【描述分层结构】
第1层：吸引力开篇（50字符内）
第2层：核心卖点（100-150字符）
第3层：使用场景（80-120字符）
第4层：信任要素（50-80字符）
第5层：行动召唤（30-50字符）

【禁用内容】
- 表情符号、链接、品牌词、夸大词`;

    const userPrompt = `请根据以下产品图片识别结果，生成一段符合美客多平台要求的优质产品描述（${languageName}）：

【图片识别结果】
${imageAnalysis}

═══════════════════════════════════════
执行步骤：
1. 分析产品核心特征
2. 规划描述结构（5层）
3. 生成描述文本（200-500字符）
4. 自然融入关键词

═══════════════════════════════════════
输出要求：
- 纯文本格式，无表情符号
- 短句分段，移动端友好
- 每句不超过15词
- 使用地道的${languageName}表达
- 只输出描述内容，不要其他说明`;

    const llmResponse = await invokeLLM(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      {
        temperature: 0.3,
        model: 'deepseek-v4-flash'
      }
    );

    const generatedDescription = llmResponse.content.trim();
    console.log('描述生成完成，长度:', generatedDescription.length);

    return NextResponse.json({
      success: true,
      imageAnalysis,
      generatedDescription
    });

  } catch (error) {
    console.error('识图生成描述失败:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : '识图生成描述失败，请重试' },
      { status: 500 }
    );
  }
}
