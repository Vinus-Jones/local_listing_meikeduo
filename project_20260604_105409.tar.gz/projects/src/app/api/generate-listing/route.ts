import { NextRequest, NextResponse } from 'next/server';
import { invokeLLM } from '@/lib/deepseek-client';
import { optimizeTitles } from '@/lib/title-review';

export async function POST(request: NextRequest) {
  try {
    const { amazonUrl } = await request.json();

    if (!amazonUrl) {
      return NextResponse.json(
        { error: '请提供亚马逊产品链接' },
        { status: 400 }
      );
    }

    // 验证URL格式
    try {
      new URL(amazonUrl);
    } catch {
      return NextResponse.json(
        { error: '请输入有效的URL地址' },
        { status: 400 }
      );
    }

    console.log('收到请求:', amazonUrl);

    // 注意：由于亚马逊反爬虫限制，无法直接获取页面内容
    // 此接口需要配合前端识图功能使用
    return NextResponse.json(
      { 
        error: '由于亚马逊反爬虫限制，无法直接获取页面内容。请使用手动输入或图片识别功能。',
        hint: '推荐使用"手动输入模式"或"图片识别模式"生成Listing'
      },
      { status: 400 }
    );
  } catch (error) {
    console.error('生成Listing错误:', error);
    return NextResponse.json(
      { error: '生成失败，请重试' },
      { status: 500 }
    );
  }
}
