import { NextRequest, NextResponse } from 'next/server';
import { invokeLLM } from '@/lib/deepseek-client';

export async function POST(request: NextRequest) {
  try {
    const { content, content_type, language, instruction } = await request.json();

    // 验证参数
    if (!content || !content_type || !language) {
      return NextResponse.json(
        { error: '请提供内容、类型和语言' },
        { status: 400 }
      );
    }

    if (!['title', 'description', 'parameters'].includes(content_type)) {
      return NextResponse.json(
        { error: '类型必须是 title、description 或 parameters' },
        { status: 400 }
      );
    }

    if (!['es', 'pt'].includes(language)) {
      return NextResponse.json(
        { error: '语言必须是 es (西班牙语) 或 pt (葡萄牙语)' },
        { status: 400 }
      );
    }

    const languageNames: Record<string, string> = {
      es: '西班牙语',
      pt: '葡萄牙语'
    };

    const typeNames: Record<string, string> = {
      title: '标题',
      description: '产品描述',
      parameters: '产品参数'
    };

    const systemPrompt = `你是一位精通美客多和亚马逊的高级Listing优化专家。你的任务是：
1. 根据用户的自定义指令调整内容
2. 对标亚马逊A+页面风格
3. 使用地道拉美西语（墨西哥/智利/哥伦比亚市场）
4. 移动端优化：短句分段，简洁易懂
5. 遵守美客多平台规范
6. 避免侵权和不适当内容
7. 输出纯JSON格式`;

    const userPrompt = `请调整以下美客多Listing的${typeNames[content_type]}（${languageNames[language]}）：

原始内容：
${content}

用户调整要求：
${instruction || '请优化内容，使其更具吸引力和专业性'}

调整规则：
${content_type === 'title' ? `
- 标题必须控制在60字符以内（包括空格）
- 优先保留产品类型和核心特征
- 使用简洁有力的词汇
- 避免修饰词堆砌
` : content_type === 'description' ? `
- 保持8段式结构：产品简介、核心价值、使用场景、功能优势、材质特点、包装清单、使用提示、贴心说明
- 短句分段，每句不超过20个词
- 每段不超过3-4行，移动端友好
- 使用地道拉美西语表达
- 包装清单和使用提示是必须项
` : `
- 参数格式：• 参数名称: 参数值
- 每个参数独立成行
- 按重要性排序
`}

语言规范：
- 使用地道拉美西语（墨西哥/智利/哥伦比亚习惯）
- 短句为主，避免复杂从句
- 简洁直白的表达

禁止内容：
- 所有表情符号
- 任何链接（URL、www、http等）
- 夸大宣传用语
- 违规承诺
- 任何装饰性符号

请按照以下JSON格式输出：
{
  "refined_content": "调整后的内容"
}

核心要求：
1. 严格遵守用户指定的调整要求
2. ${content_type === 'title' ? '标题不超过60字符' : '保持8段式结构，短句分段，移动端友好'}
3. ${content_type === 'description' ? '确保包含包装清单和使用提示' : ''}
4. 删除所有符号装饰（emoji、链接、星号、括号等）
5. 只输出JSON格式，不要有任何其他文字说明`;

    const llmResponse = await invokeLLM(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      {
        temperature: 0.3,
        model: 'deepseek-v4-flash'
      }
    );

    console.log('LLM响应:', llmResponse.content.substring(0, 200));

    // 解析JSON响应
    let result;
    try {
      const jsonMatch = llmResponse.content.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? jsonMatch[0] : llmResponse.content;
      result = JSON.parse(jsonString);
    } catch (parseError) {
      console.error('JSON解析失败:', parseError);
      console.error('原始响应:', llmResponse.content);
      throw new Error('解析LLM响应失败，请重试');
    }

    // 验证结果
    if (!result.refined_content) {
      console.error('结果不完整:', result);
      throw new Error('生成的内容不完整，请重试');
    }

    // 清理表情符号和特殊符号
    const cleanText = (text: string) => {
      return text
        .replace(/https?:\/\/[^\s]+/gi, '') // 删除HTTP链接
        .replace(/www\.[^\s]+/gi, '') // 删除www链接
        .replace(/[\u{1F600}-\u{1F64F}]/gu, '') // emoji
        .replace(/[\u{1F300}-\u{1F5FF}]/gu, '') // symbols
        .replace(/[\u{1F680}-\u{1F6FF}]/gu, '') // transport
        .replace(/[\u{1F700}-\u{1F77F}]/gu, '') // alchemical
        .replace(/[\u{1F780}-\u{1F7FF}]/gu, '') // geometric
        .replace(/[\u{1F800}-\u{1F8FF}]/gu, '') // arrows
        .replace(/[\u{1F900}-\u{1F9FF}]/gu, '') // supplemental
        .replace(/[\u{1FA00}-\u{1FA6F}]/gu, '') // chess
        .replace(/[\u{1FA70}-\u{1FAFF}]/gu, '') // symbols extended
        .replace(/[\u{2600}-\u{26FF}]/gu, '') // misc
        .replace(/[\u{2700}-\u{27BF}]/gu, '') // dingbats
        .replace(/[★✓✓✔✅❌●◆▪▫○◇◈◉⦿]/g, '') // common symbols
        .replace(/[•··]/g, '') // bullets
        .replace(/【|】|「|」|『|』|《|》|〈|〉|（|）|〔|〕|【|】]/g, '') // brackets
        .replace(/─│┌┐└┘├┤┬┴┼═║╔╗╚╝╠╣╦╩╬]/g, '') // box drawing
        .replace(/→←↑↓↔↕↖↗↘↙/g, '') // arrows
        .replace(/-+/g, ' - ')
        .replace(/\s+/g, ' ')
        .trim();
    };

    result.refined_content = cleanText(result.refined_content);

    // 如果是标题，检查字符数
    if (content_type === 'title' && result.refined_content.length > 60) {
      result.refined_content = result.refined_content.substring(0, 60);
    }

    console.log('调整成功');

    return NextResponse.json(result);

  } catch (error) {
    console.error('调整Listing失败:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : '调整失败，请重试'
      },
      { status: 500 }
    );
  }
}
