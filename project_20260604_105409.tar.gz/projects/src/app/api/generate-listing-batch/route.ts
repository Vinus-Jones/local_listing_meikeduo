import { NextRequest, NextResponse } from 'next/server';
import { invokeLLM } from '@/lib/deepseek-client';
import { optimizeTitles } from '@/lib/title-review';
import { formatResponse, formatErrorResponse } from '@/lib/api-utils';

/**
 * 批量生成Listing API
 *
 * POST /api/generate-listing-batch
 *
 * 请求体:
 * {
 *   "products": [
 *     {
 *       "productName": "产品名称",
 *       "features": "产品特性",
 *       "targetCountry": "MX|BR|CO|AR|CL",
 *       "language": "es|pt"
 *     }
 *   ],
 *   "maxConcurrency": 3  // 可选，最大并发数
 * }
 */

// 辅助函数：从可能格式错误的JSON中提取字段
function extractJsonFields(jsonString: string): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  
  const extractStringField = (text: string, fieldName: string): string | null => {
    const regex = new RegExp(`"${fieldName}"\\s*:\\s*"([\\s\\S]*?)"(?:\\s*[,}]|$)`);
    const match = text.match(regex);
    if (match) {
      return match[1]
        .replace(/\\n/g, ' ')
        .replace(/\n/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    }
    return null;
  };
  
  const extractArrayField = (text: string, fieldName: string): string[] | null => {
    const regex = new RegExp(`"${fieldName}"\\s*:\\s*\\[([\\s\\S]*?)\\]\\s*[,}]`);
    const match = text.match(regex);
    if (match) {
      try {
        const arrayContent = '[' + match[1] + ']';
        const parsed = JSON.parse(arrayContent);
        return Array.isArray(parsed) ? parsed : null;
      } catch {
        const items = match[1].match(/"([^"]*)"/g);
        if (items) {
          return items.map(item => item.replace(/"/g, '').trim());
        }
      }
    }
    return null;
  };
  
  const stringFields = ['title_es', 'title_pt', 'description_es', 'description_pt'];
  const arrayFields = ['parameters_es', 'parameters_pt', 'keywords_es', 'keywords_pt'];
  
  for (const field of stringFields) {
    const value = extractStringField(jsonString, field);
    if (value) result[field] = value;
  }
  
  for (const field of arrayFields) {
    const value = extractArrayField(jsonString, field);
    if (value) result[field] = value;
  }
  
  return result;
}

// 清理文本中的表情符号和特殊符号
function cleanText(text: string): string {
  return text
    .replace(/https?:\/\/[^\s]+/gi, '')
    .replace(/www\.[^\s]+/gi, '')
    .replace(/[\u{1F600}-\u{1F64F}]/gu, '')
    .replace(/[\u{1F300}-\u{1F5FF}]/gu, '')
    .replace(/[\u{1F680}-\u{1F6FF}]/gu, '')
    .replace(/[\u{1F700}-\u{1F77F}]/gu, '')
    .replace(/[\u{1F780}-\u{1F7FF}]/gu, '')
    .replace(/[\u{1F800}-\u{1F8FF}]/gu, '')
    .replace(/[\u{1F900}-\u{1F9FF}]/gu, '')
    .replace(/[\u{1FA00}-\u{1FA6F}]/gu, '')
    .replace(/[\u{1FA70}-\u{1FAFF}]/gu, '')
    .replace(/[\u{2600}-\u{26FF}]/gu, '')
    .replace(/[\u{2700}-\u{27BF}]/gu, '')
    .replace(/[★✓✔✅❌]/g, '')
    .replace(/【|】|「|」|『|』|【|】|（|）|〔|〕]/g, '')
    .replace(/─│┌┐└┘├┤┬┴┼═║╔╗╚╝╠╣╦╩╬]/g, '')
    .replace(/→←↑↓↔↕↖↗↘↙/g, '')
    .trim();
}

/**
 * 生成单个产品的Listing
 */
async function generateSingleListing(productName: string, features: string): Promise<Record<string, unknown>> {
  const systemPrompt = `你是一位美客多平台资深运营专家，精通拉美电商市场。你的核心能力是：

【角色定位】
- 美客多SEO优化专家，专注于墨西哥/智利/哥伦比亚（西语）和巴西（葡语）市场
- 精通关键词权重分析、本地化文案、转化率提升
- 深度理解消费者搜索习惯和购买决策因素

【目标】生成高曝光、高转化的Listing内容

════════════════════════════════════════════════════════════
                    标题优化策略（30-60字符限制）
════════════════════════════════════════════════════════════

【标题结构公式】
[核心品类词] + [关键属性词] + [使用场景/目标用户] + [差异化卖点]

【字符权重分布】
- 前15字符：核心品类词（必须有，决定搜索排名）
- 前30字符：核心品类词 + 核心功能词（高权重区域）
- 中段：使用场景词、目标用户词
- 末尾：差异化属性词、长尾词

【标题优化原则】
1. 字符利用率：目标50-60字符，固定范围30-60字符
2. 关键词密度：包含3-5个核心关键词
3. 核心词前置：品类词必须在标题开头
4. 无重复词：同义词选择一个即可
5. 可读性优先：避免关键词堆砌

【本地化词汇对照】
- 耳机：西语 audífonos / 葡语 fones de ouvido
- 音箱：西语 altavoz / 葡语 alto-falante
- 手机壳：西语 funda / 葡语 capa
- 充电器：西语 cargador / 葡语 carregador
- 无线：西语 inalámbrico / 葡语 sem fio
- 防水：西语 impermeable / 葡语 impermeável

════════════════════════════════════════════════════════════
                    描述优化策略（200-500字符）
════════════════════════════════════════════════════════════

【描述分层结构】

第1层：吸引力开篇（50字符内）
- 一句话说明产品是什么
- 使用强动词，避免被动语态
- 立即抓住注意力

第2层：核心卖点（100-150字符）
- 2-3个最核心的功能/特点
- 数据化表达（如"12小时续航"）
- 差异化优势强调

第3层：使用场景（80-120字符）
- 2-3个具体使用场景
- 目标用户画像
- 解决的问题

第4层：信任要素（50-80字符）
- 材质/工艺说明
- 包装清单
- 质量承诺（避免夸大）

第5层：行动召唤（30-50字符）
- 简单使用提示
- 售后服务说明

【描述写作规范】
- 短句为主，每句不超过15词
- 段落间用空行分隔
- 移动端友好，每段不超过3行
- 自然融入5-8个属性关键词

════════════════════════════════════════════════════════════
                    关键词分层体系（15-20个）
════════════════════════════════════════════════════════════

【第一层：核心词】（3-5个）
- 品类主词：audífonos, altavoz, funda 等产品类型词
- 必须在标题中出现
- 搜索量最高

【第二层：属性词】（5-8个）
- 功能属性：inalámbrico, bluetooth, impermeable
- 产品特性：portátil, recargable, ergonómico
- 描述中高频出现

【第三层：场景词】（4-6个）
- 使用场景：gamer, deportivo, oficina, hogar
- 目标用户：profesional, estudiante
- 覆盖长尾搜索

【第四层：长尾词】（3-5个）
- 具体需求：para running, con micrófono, para regalo
- 精准匹配用户意图

【关键词格式要求】
- 全部小写
- 去除重复
- 以单词或短语形式输出
- 无品牌词/商标词

════════════════════════════════════════════════════════════
                    禁用内容清单
════════════════════════════════════════════════════════════

【绝对禁止】
- 所有表情符号和装饰符号
- 任何链接（URL、www、http）
- 品牌名、商标词（除非授权）
- 分段标题符号【】●★等

【夸大类禁用词】
西语：mejor, número 1, garantizado, 100%, único, increíble, perfecto
葡语：melhor, número 1, garantido, 100%, único, incrível, perfeito

【医疗类禁用词】
西语：cura, trata, elimina, previene, saludable
葡语：cura, trata, elimina, previne, saudável

【法律风险禁用词】
西语：garantía de por vida, reembolso total
葡语：garantia vitalícia, reembolso total

════════════════════════════════════════════════════════════
                    输出格式要求
════════════════════════════════════════════════════════════

严格按照JSON格式输出，无任何其他文字。`;

  const userPrompt = `请分析以下产品信息，生成优化的美客多Listing：

【产品名称】${productName}
【产品特性】${features}

═══════════════════════════════════════
              执行步骤
═══════════════════════════════════════

【步骤1】产品分析
- 识别产品品类（电子产品/家居/户外/美妆/服饰等）
- 提取核心功能（3-5个）
- 确定目标用户和使用场景

【步骤2】关键词规划
- 核心词（3-5个）：品类主词、产品类型词
- 属性词（5-8个）：功能特性、材质工艺
- 场景词（4-6个）：使用场景、目标用户
- 长尾词（3-5个）：具体需求、差异化卖点

【步骤3】标题生成
- 应用公式：[核心品类词] + [关键属性词] + [使用场景] + [差异化卖点]
- 字符控制：55-60字符
- 核心词前置：品类词放在标题开头
- 关键词密度：3-5个核心关键词

【步骤4】描述撰写
根据具体产品信息定制化撰写描述，必须包含以下内容：

【属性介绍】- 具体说明产品的主要属性（如：防水等级IPX7、蓝牙5.0、30小时续航等）
【用途说明】- 具体说明产品能做什么、解决什么问题（如：适合跑步时听音乐、适合户外使用等）
【特征描述】- 具体描述产品特点（如：轻量化设计、折叠便携、触控操作等）
【参数信息】- 重要技术参数（如：电池容量、充电时间、重量尺寸等）
【包装清单】- 包装内含物品（如：主机x1、充电线x1、说明书x1）
【使用说明】- 使用注意事项（如：首次充电3小时、避免高温环境等）

总长度：200-500字符
内容要求：根据产品实际情况撰写，不要使用通用模板，不要虚构参数

【步骤5】关键词规划
- 核心词（3-5个）：品类主词如 altavoz, fones
- 属性词（5-8个）：功能特性如 bluetooth, impermeable
- 场景词（4-6个）：使用场景如 playa, praia
- 长尾词（3-5个）：具体需求如 para fiesta

【步骤6】参数提取
- 提取5-8个关键规格参数
- 格式：• 参数名: 参数值

═══════════════════════════════════════
              JSON输出格式（必须完整输出）
═══════════════════════════════════════

{
  "title_es": "西语标题，30-60字符（推荐50-60字符），核心品类词在开头",
  "title_pt": "葡语标题，30-60字符（推荐50-60字符），结构与西语相同",
  "description_es": "西语产品描述，必须包含：①属性介绍（具体参数）②用途说明（能做什么）③特征描述（产品特点）④参数信息⑤包装清单⑥使用说明。根据产品实际情况撰写，段落用空行分隔。",
  "description_pt": "葡语产品描述，必须包含：①属性介绍（具体参数）②用途说明（能做什么）③特征描述（产品特点）④参数信息⑤包装清单⑥使用说明。根据产品实际情况撰写，段落用空行分隔。",
  "parameters_es": ["• 参数1: 值1", "• 参数2: 值2"],
  "parameters_pt": ["• 参数1: 值1", "• 参数2: 值2"],
  "keywords_es": ["核心词1", "核心词2", "属性词1", "核心词3", "属性词2", "场景词1", "属性词3", "长尾词1"],
  "keywords_pt": ["核心词1", "核心词2", "属性词1", "核心词3", "属性词2", "场景词1", "属性词3", "长尾词1"]
}

注意：keywords必须包含15-20个关键词，全部小写，无品牌词

═══════════════════════════════════════
              质量检查清单
═══════════════════════════════════════

✓ 标题字符数：30-60字符（推荐50-60字符）
✓ 标题核心词：品类词在开头
✓ 标题关键词：3-5个
✓ 描述长度：200-500字符
✓ 描述内容：必须包含属性、用途、特征、参数、包装、使用说明
✓ 描述真实性：根据产品实际信息撰写，不要虚构
✓ 关键词总数：15-20个
✓ 无禁用词：无品牌词、无夸大词
✓ 本地化正确：西语用audífonos、葡语用fones de ouvido等

只输出JSON，无其他文字。`;

  // 调用 LLM
  const llmResponse = await invokeLLM(
    [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ],
    {
      temperature: 0.3,
      model: 'deepseek-v4-flash'
    }
  );

  // 解析 JSON 响应
  let result;
  try {
    const jsonMatch = llmResponse.content.match(/\{[\s\S]*\}/);
    let jsonString = jsonMatch ? jsonMatch[0] : llmResponse.content;
    
    try {
      result = JSON.parse(jsonString);
    } catch {
      result = extractJsonFields(jsonString);
    }
  } catch {
    throw new Error('解析LLM响应失败');
  }

  // 标题审查和优化
  if (result.title_es || result.title_pt) {
    const optimizedTitles = await optimizeTitles({
      es: result.title_es || '',
      pt: result.title_pt || ''
    });
    
    if (result.title_es) result.title_es = optimizedTitles.es;
    if (result.title_pt) result.title_pt = optimizedTitles.pt;
  }

  // 清理文本
  if (result.description_es) result.description_es = cleanText(result.description_es);
  if (result.description_pt) result.description_pt = cleanText(result.description_pt);

  return result;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { products, maxConcurrency = 3 } = body;

    // 验证请求
    if (!products || !Array.isArray(products)) {
      return NextResponse.json(
        formatErrorResponse(new Error('products 必须是数组'), '参数验证'),
        { status: 400 }
      );
    }

    if (products.length === 0) {
      return NextResponse.json(
        formatErrorResponse(new Error('products 不能为空'), '参数验证'),
        { status: 400 }
      );
    }

    if (products.length > 10) {
      return NextResponse.json(
        formatErrorResponse(new Error('单次最多支持10个产品'), '参数验证'),
        { status: 400 }
      );
    }

    // 验证每个产品
    const errors: string[] = [];
    const validatedProducts = products.map((product: Record<string, unknown>, index: number) => {
      if (!product.productName) {
        errors.push(`产品 ${index + 1}: 缺少 productName`);
      }
      return {
        productName: String(product.productName || '').trim(),
        features: String(product.features || '').trim(),
      };
    });

    if (errors.length > 0) {
      return NextResponse.json(
        formatErrorResponse(new Error(errors.join('; ')), '参数验证'),
        { status: 400 }
      );
    }

    // 批量处理（使用信号量控制并发）
    const results: Array<{
      index: number;
      success: boolean;
      data?: Record<string, unknown>;
      error?: string;
    }> = [];
    
    let running = 0;
    let index = 0;
    const total = validatedProducts.length;

    await new Promise<void>((resolve) => {
      function processNext() {
        while (running < maxConcurrency && index < total) {
          const currentIndex = index;
          const product = validatedProducts[currentIndex];
          index++;
          running++;

          generateSingleListing(product.productName, product.features)
            .then((data) => {
              results[currentIndex] = {
                index: currentIndex,
                success: true,
                data,
              };
            })
            .catch((error) => {
              results[currentIndex] = {
                index: currentIndex,
                success: false,
                error: error instanceof Error ? error.message : '未知错误',
              };
            })
            .finally(() => {
              running--;
              processNext();
              if (results.filter((r) => r !== undefined).length === total) {
                resolve();
              }
            });
        }
      }

      processNext();
    });

    const successCount = results.filter((r) => r.success).length;
    const failedCount = results.filter((r) => !r.success).length;

    return NextResponse.json(
      formatResponse({
        total,
        success: successCount,
        failed: failedCount,
        results,
      })
    );
  } catch (error) {
    console.error('批量生成失败:', error);
    return NextResponse.json(
      formatErrorResponse(error, '批量生成Listing'),
      { status: 500 }
    );
  }
}
