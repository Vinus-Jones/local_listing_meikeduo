import { NextRequest, NextResponse } from "next/server";
import { LLMClient, Config, HeaderUtils } from "coze-coding-dev-sdk";

export async function POST(request: NextRequest) {
  try {
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    const { image, targetLanguage } = await request.json();

    // 验证参数
    if (!image) {
      return NextResponse.json(
        { error: "请上传图片" },
        { status: 400 }
      );
    }

    if (!targetLanguage || !['es', 'pt'].includes(targetLanguage)) {
      return NextResponse.json(
        { error: "目标语言必须是 es (西班牙语) 或 pt (葡萄牙语)" },
        { status: 400 }
      );
    }

    const languageNames: Record<string, string> = {
      es: "西班牙语",
      pt: "葡萄牙语"
    };

    const languageCode: Record<string, string> = {
      es: "español",
      pt: "português"
    };

    // 构建消息 - 使用多模态格式
    const messages = [
      {
        role: "user" as const,
        content: [
          {
            type: "text" as const,
            text: `请识别这张图片中的所有文字内容，然后将其翻译为${languageNames[targetLanguage]}。

请按照以下JSON格式返回结果：
\`\`\`json
{
  "extractedText": "图片中提取的原始文字",
  "translatedText": "翻译后的${languageNames[targetLanguage]}文字",
  "languageDetected": "检测到的语言"
}
\`\`\`

要求：
1. 准确识别图片中的所有文字
2. 保持原文的段落结构
3. 翻译要准确、地道，符合${languageNames[targetLanguage]}的表达习惯
4. 只返回JSON格式，不要包含其他解释文字`
          },
          {
            type: "image_url" as const,
            image_url: {
              url: image,
              detail: "high" as const
            }
          }
        ]
      }
    ];

    // 调用 LLM API - 使用 vision 模型
    const response = await client.invoke(messages, {
      model: "doubao-seed-2-0-pro-260215",
      temperature: 0.3 // 使用较低温度确保翻译准确性
    });

    // 解析响应
    const content = response.content;

    // 尝试提取 JSON
    let jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/);
    if (!jsonMatch) {
      // 尝试直接提取 JSON
      jsonMatch = content.match(/\{[\s\S]*\}/);
    }

    if (!jsonMatch) {
      // 如果无法提取 JSON，返回原始文本
      return NextResponse.json({
        extractedText: content,
        translatedText: "",
        languageDetected: "unknown",
        warning: "无法提取结构化结果，请手动复制文本"
      });
    }

    const result = JSON.parse(jsonMatch[1]);

    return NextResponse.json({
      extractedText: result.extractedText || "",
      translatedText: result.translatedText || "",
      languageDetected: result.languageDetected || "unknown"
    });

  } catch (error) {
    console.error("图片翻译错误:", error);
    return NextResponse.json(
      { error: "图片翻译失败，请重试" },
      { status: 500 }
    );
  }
}
