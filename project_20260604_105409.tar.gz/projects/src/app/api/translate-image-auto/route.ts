import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';
import { ImageGenerationClient } from 'coze-coding-dev-sdk';
import { uploadImageBuffer } from '@/lib/storage';

export async function POST(request: NextRequest) {
  try {
    const { image, targetLanguage, aspectRatio = '1:1', model = 'default', versionCount = 3 } = await request.json();

    // 验证参数
    if (!image) {
      return NextResponse.json(
        { error: '请上传图片' },
        { status: 400 }
      );
    }

    if (!targetLanguage || !['es', 'pt'].includes(targetLanguage)) {
      return NextResponse.json(
        { error: '目标语言必须是 es (西班牙语) 或 pt (葡萄牙语)' },
        { status: 400 }
      );
    }

    // 验证aspectRatio参数
    if (!['1:1', 'original'].includes(aspectRatio)) {
      return NextResponse.json(
        { error: '图片比例必须是 1:1 或 original' },
        { status: 400 }
      );
    }

    // 验证model参数
    const validModels = ['default', 'high-quality', 'ultra-quality', 'fast'];
    if (!validModels.includes(model)) {
      return NextResponse.json(
        { error: '无效的模型参数' },
        { status: 400 }
      );
    }

    // 验证versionCount参数
    if (!versionCount || versionCount < 1 || versionCount > 3) {
      return NextResponse.json(
        { error: '版本数量必须是1、2或3' },
        { status: 400 }
      );
    }

    // 模型配置 - 根据不同质量级别优化prompt
    const modelConfig: Record<string, any> = {
      'default': {
        description: '标准模型',
        qualityPrompt: ''
      },
      'high-quality': {
        description: '高清模型',
        qualityPrompt: ' Ultra high quality, sharp details, professional grade, accurate text rendering, perfect composition.'
      },
      'ultra-quality': {
        description: '超清模型',
        qualityPrompt: ' Maximum quality, photorealistic, sharp focus, professional photography, ultra-detailed, perfect text integration.'
      },
      'fast': {
        description: '快速模型',
        qualityPrompt: ' Clean and clear.'
      }
    };

    const configDetails = modelConfig[model];

    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();

    // 第1步：使用 Vision LLM 识别图片中的文字
    const llmClient = new LLMClient(config, customHeaders);

    const languageNames: Record<string, string> = {
      es: '西班牙语',
      pt: '葡萄牙语'
    };

    const visionMessages = [
      {
        role: 'user' as const,
        content: [
          {
            type: 'text' as const,
            text: `请识别这张图片中的所有文字内容，并将其翻译为${languageNames[targetLanguage]}。

请按照以下格式输出（只返回文本，不要JSON格式）：

原文：
[图片中识别到的原始文字]

翻译（${languageNames[targetLanguage]}）：
[翻译后的${languageNames[targetLanguage]}文字]

要求：
1. 准确识别图片中的所有文字（无论是什么语言）
2. 将识别到的文字准确翻译为${languageNames[targetLanguage]}
3. 翻译要准确、地道，符合${languageNames[targetLanguage]}的表达习惯
4. 只返回文本，不要有其他格式说明
5. 如果图片中没有文字，请返回"图片中未检测到文字"`
          },
          {
            type: 'image_url' as const,
            image_url: {
              url: image,
              detail: 'high' as const
            }
          }
        ]
      }
    ];

    const visionResponse = await llmClient.invoke(visionMessages, {
      model: 'doubao-seed-2-0-pro-260215',
      temperature: 0.3
    });

    const ocrResult = visionResponse.content;

    // 检查是否有文字
    if (ocrResult.includes('未检测到文字') || ocrResult.includes('no text')) {
      return NextResponse.json({
        error: '图片中未检测到文字内容',
        ocrResult
      });
    }

    // 提取原文和译文
    let originalText = '';
    let translatedText = '';

    const originalMatch = ocrResult.match(/原文：\s*([\s\S]*?)(?=\n翻译|$)/i);
    const translatedMatch = ocrResult.match(/翻译（[^)]*）：\s*([\s\S]*?)(?=$)/i);

    if (originalMatch) {
      originalText = originalMatch[1].trim();
    }
    if (translatedMatch) {
      translatedText = translatedMatch[1].trim();
    }

    if (!originalText || !translatedText) {
      return NextResponse.json({
        error: '无法识别或翻译图片中的文字',
        ocrResult
      });
    }

    // 根据比例参数决定输出尺寸和prompt
    const imageSize = aspectRatio === '1:1'
      ? '1024x1024' // 1:1 正方形
      : '1024x768'; // 保持原比例（假设为4:3）

    // 根据比例参数生成基础prompt
    const basePrompt = aspectRatio === '1:1'
      ? `Perfectly maintain the original image's composition, colors, style, lighting, and atmosphere. Only replace the text "${originalText}" with "${translatedText}" in ${languageNames[targetLanguage]}. The image should be square (1:1 ratio).`
      : `Perfectly maintain the original image's composition, colors, style, lighting, and atmosphere. Only replace the text "${originalText}" with "${translatedText}" in ${languageNames[targetLanguage]}.`;

    // 根据模型添加质量增强prompt
    const prompt = basePrompt + modelConfig[model].qualityPrompt;

    console.log(`使用模型: ${configDetails.description}, 图片比例: ${aspectRatio}, 生成版本数: ${versionCount}`);

    // 第3步：使用 Image-to-Image 生成新图片（根据用户选择生成1-3个版本）
    const imageClient = new ImageGenerationClient(config, customHeaders);

    // 根据versionCount动态生成指定数量的版本
    const generatedImages: string[] = [];
    const usageList: Array<{ tokens: number; imageCount: number }> = []; // 收集每个版本的usage信息

    const generatePromises = Array.from({ length: versionCount }, async (_, i) => {
      try {
        const imageResponse = await imageClient.generate({
          prompt: prompt,
          image: image,
          size: imageSize,
          responseFormat: 'b64_json',
          watermark: false
        });

        const helper = imageClient.getResponseHelper(imageResponse);

        if (helper.success && helper.imageB64List.length > 0) {
          // 提取usage信息
          const rawResponse = imageResponse as any;
          if (rawResponse.usage) {
            usageList.push({
              tokens: rawResponse.usage.total_tokens || rawResponse.usage.output_tokens || 0,
              imageCount: rawResponse.usage.generated_images || 1
            });
          } else {
            // 如果没有usage信息，使用固定值250 tokens（豆包4.5模型）
            usageList.push({
              tokens: 250,
              imageCount: 1
            });
          }

          // 将base64转换为Buffer
          const base64Data = helper.imageB64List[0];
          const buffer = Buffer.from(base64Data, 'base64');

          // 上传到对象存储并获取永久URL
          const fileName = `translate_${targetLanguage}_version${i + 1}.png`;
          const imageUrl = await uploadImageBuffer(buffer, fileName, 'image/png');

          return imageUrl;
        }
        return null;
      } catch (error) {
        console.error(`生成版本${i + 1}失败:`, error);
        return null;
      }
    });

    const results = await Promise.all(generatePromises);
    results.forEach(result => {
      if (result) generatedImages.push(result);
    });

    if (generatedImages.length === 0) {
      return NextResponse.json({
        error: '图片生成失败',
        originalText,
        translatedText
      });
    }

    // 第4步：返回结果（包含所有生成的版本和token消耗信息）
    // 计算总token消耗
    const totalTokens = usageList.reduce((sum, usage) => sum + usage.tokens, 0);

    return NextResponse.json({
      originalText,
      translatedText,
      originalImage: image,
      generatedImages,
      usage: {
        totalTokens,
        totalImages: generatedImages.length,
        details: usageList,
        // 标记数据来源
        source: usageList.every(u => u.tokens > 0) ? 'api' : 'estimated'
      },
      success: true
    });

  } catch (error) {
    console.error('自动翻译图片失败:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : '翻译失败，请重试',
        success: false
      },
      { status: 500 }
    );
  }
}
