import { NextRequest, NextResponse } from 'next/server';
import { invokeLLM } from '@/lib/deepseek-client';
import { optimizeTitles } from '@/lib/title-review';
import { 
  scoreTitle, 
  scoreDescription, 
  checkForbiddenWords,
  getTitleOptimizationSuggestions
} from '@/lib/listing-optimizer';

// 辅助函数：从可能格式错误的JSON中提取字段
function extractJsonFields(jsonString: string): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  
  // 提取字符串字段的函数
  const extractStringField = (text: string, fieldName: string): string | null => {
    const regex = new RegExp(`"${fieldName}"\\s*:\\s*"([\\s\\S]*?)"(?:\\s*[,}]|$)`);
    const match = text.match(regex);
    if (match) {
      // 清理提取的字符串：移除多余的空白和换行
      return match[1]
        .replace(/\\n/g, ' ') // 将转义换行符替换为空格
        .replace(/\n/g, ' ') // 将实际换行符替换为空格
        .replace(/\s+/g, ' ') // 将多个空格合并为一个
        .trim();
    }
    return null;
  };
  
  // 提取数组字段的函数
  const extractArrayField = (text: string, fieldName: string): string[] | null => {
    const regex = new RegExp(`"${fieldName}"\\s*:\\s*\\[([\\s\\S]*?)\\]\\s*[,}]`);
    const match = text.match(regex);
    if (match) {
      try {
        // 尝试解析数组内容
        const arrayContent = '[' + match[1] + ']';
        const parsed = JSON.parse(arrayContent);
        return Array.isArray(parsed) ? parsed : null;
      } catch {
        // 如果解析失败，尝试手动提取
        const items = match[1].match(/"([^"]*)"/g);
        if (items) {
          return items.map(item => item.replace(/"/g, '').trim());
        }
      }
    }
    return null;
  };
  
  // 提取所有已知字段
  const stringFields = [
    'title_es', 'title_pt', 
    'description_es', 'description_pt'
  ];
  
  const arrayFields = [
    'parameters_es', 'parameters_pt',
    'keywords_es', 'keywords_pt'
  ];
  
  for (const field of stringFields) {
    const value = extractStringField(jsonString, field);
    if (value) {
      result[field] = value;
    }
  }
  
  for (const field of arrayFields) {
    const value = extractArrayField(jsonString, field);
    if (value) {
      result[field] = value;
    }
  }
  
  return result;
}

export async function POST(request: NextRequest) {
  try {
    const { title, description } = await request.json();

    // 至少提供标题或描述之一
    if (!title && !description) {
      return NextResponse.json(
        { error: '请提供产品标题或描述（至少一项）' },
        { status: 400 }
      );
    }

    // 使用DeepSeek生成listing
    const systemPrompt = `你是一位美客多平台资深运营专家，精通拉美电商市场。你的核心能力是：

【角色定位】
- 美客多SEO优化专家，专注于墨西哥/智利/哥伦比亚（西语）和巴西（葡语）市场
- 精通关键词权重分析、本地化文案、转化率提升
- 深度理解消费者搜索习惯和购买决策因素

【目标】生成高曝光、高转化的Listing内容

════════════════════════════════════════════════════════════
                    标题优化策略（30-60字符限制）
════════════════════════════════════════════════════════════

【标题结构公式】
[核心品类词] + [关键属性词] + [使用场景/目标用户] + [差异化卖点]

【字符权重分布】
- 前15字符：核心品类词（必须有，决定搜索排名）
- 前30字符：核心品类词 + 核心功能词（高权重区域）
- 中段：使用场景词、目标用户词
- 末尾：差异化属性词、长尾词

【标题优化原则】
1. 字符利用率：目标50-60字符，固定范围30-60字符
2. 关键词密度：包含3-5个核心关键词
3. 核心词前置：品类词必须在标题开头
4. 无重复词：同义词选择一个即可
5. 可读性优先：避免关键词堆砌

【本地化词汇对照】
- 耳机：西语 audífonos / 葡语 fones de ouvido
- 音箱：西语 altavoz / 葡语 alto-falante
- 手机壳：西语 funda / 葡语 capa
- 充电器：西语 cargador / 葡语 carregador
- 无线：西语 inalámbrico / 葡语 sem fio
- 防水：西语 impermeable / 葡语 impermeável

════════════════════════════════════════════════════════════
                    描述优化策略（200-500字符）
════════════════════════════════════════════════════════════

【描述分层结构】

第1层：吸引力开篇（50字符内）
- 一句话说明产品是什么
- 使用强动词，避免被动语态
- 立即抓住注意力

第2层：核心卖点（100-150字符）
- 2-3个最核心的功能/特点
- 数据化表达（如"12小时续航"）
- 差异化优势强调

第3层：使用场景（80-120字符）
- 2-3个具体使用场景
- 目标用户画像
- 解决的问题

第4层：信任要素（50-80字符）
- 材质/工艺说明
- 包装清单
- 质量承诺（避免夸大）

第5层：行动召唤（30-50字符）
- 简单使用提示
- 售后服务说明

【描述写作规范】
- 短句为主，每句不超过15词
- 段落间用空行分隔
- 移动端友好，每段不超过3行
- 自然融入5-8个属性关键词

════════════════════════════════════════════════════════════
                    关键词分层体系（15-20个）
════════════════════════════════════════════════════════════

【第一层：核心词】（3-5个）
- 品类主词：audífonos, altavoz, funda 等产品类型词
- 必须在标题中出现
- 搜索量最高

【第二层：属性词】（5-8个）
- 功能属性：inalámbrico, bluetooth, impermeable
- 产品特性：portátil, recargable, ergonómico
- 描述中高频出现

【第三层：场景词】（4-6个）
- 使用场景：gamer, deportivo, oficina, hogar
- 目标用户：profesional, estudiante
- 覆盖长尾搜索

【第四层：长尾词】（3-5个）
- 具体需求：para running, con micrófono, para regalo
- 精准匹配用户意图

【关键词格式要求】
- 全部小写
- 去除重复
- 以单词或短语形式输出
- 无品牌词/商标词

════════════════════════════════════════════════════════════
                    禁用内容清单
════════════════════════════════════════════════════════════

【绝对禁止】
- 所有表情符号和装饰符号
- 任何链接（URL、www、http）
- 品牌名、商标词（除非授权）
- 分段标题符号【】●★等

【夸大类禁用词】
西语：mejor, número 1, garantizado, 100%, único, increíble, perfecto
葡语：melhor, número 1, garantido, 100%, único, incrível, perfeito

【医疗类禁用词】
西语：cura, trata, elimina, previene, saludable
葡语：cura, trata, elimina, previne, saudável

【法律风险禁用词】
西语：garantía de por vida, reembolso total
葡语：garantia vitalícia, reembolso total

════════════════════════════════════════════════════════════
                    输出格式要求
════════════════════════════════════════════════════════════

严格按照JSON格式输出，无任何其他文字。`;

    const userPrompt = `请分析以下产品信息，生成优化的美客多Listing：

${title ? `【原始标题】${title}` : ''}
${description ? `【原始描述】${description}` : ''}
${!title ? '(未提供标题)' : ''}
${!description ? '(未提供描述)' : ''}

═══════════════════════════════════════
              执行步骤
═══════════════════════════════════════

【步骤1】产品分析
- 识别产品品类（电子产品/家居/户外/美妆/服饰等）
- 提取核心功能（3-5个）
- 确定目标用户和使用场景

【步骤2】关键词规划
- 核心词（3-5个）：品类主词、产品类型词
- 属性词（5-8个）：功能特性、材质工艺
- 场景词（4-6个）：使用场景、目标用户
- 长尾词（3-5个）：具体需求、差异化卖点

【步骤3】标题生成
- 应用公式：[核心品类词] + [关键属性词] + [使用场景] + [差异化卖点]
- 字符控制：55-60字符
- 核心词前置：品类词放在标题开头
- 关键词密度：3-5个核心关键词

【步骤4】描述撰写
根据具体产品信息定制化撰写描述，必须包含以下内容：

【属性介绍】- 具体说明产品的主要属性（如：防水等级IPX7、蓝牙5.0、30小时续航等）
【用途说明】- 具体说明产品能做什么、解决什么问题（如：适合跑步时听音乐、适合户外使用等）
【特征描述】- 具体描述产品特点（如：轻量化设计、折叠便携、触控操作等）
【参数信息】- 重要技术参数（如：电池容量、充电时间、重量尺寸等）
【包装清单】- 包装内含物品（如：主机x1、充电线x1、说明书x1）
【使用说明】- 使用注意事项（如：首次充电3小时、避免高温环境等）

总长度：200-500字符
内容要求：根据产品实际情况撰写，不要使用通用模板，不要虚构参数

【步骤5】关键词规划
- 核心词（3-5个）：品类主词如 altavoz, fones
- 属性词（5-8个）：功能特性如 bluetooth, impermeable
- 场景词（4-6个）：使用场景如 playa, praia
- 长尾词（3-5个）：具体需求如 para fiesta

【步骤6】参数提取
- 提取5-8个关键规格参数
- 格式：• 参数名: 参数值

═══════════════════════════════════════
              JSON输出格式（必须完整输出）
═══════════════════════════════════════

{
${title ? `  "title_es": "西语标题，30-60字符（推荐50-60字符），核心品类词在开头",` : ''}
${title ? `  "title_pt": "葡语标题，30-60字符（推荐50-60字符），结构与西语相同",` : ''}
${description ? `  "description_es": "西语产品描述，必须包含：①属性介绍（具体参数）②用途说明（能做什么）③特征描述（产品特点）④参数信息⑤包装清单⑥使用说明。根据产品实际情况撰写，段落用空行分隔。",` : ''}
${description ? `  "description_pt": "葡语产品描述，必须包含：①属性介绍（具体参数）②用途说明（能做什么）③特征描述（产品特点）④参数信息⑤包装清单⑥使用说明。根据产品实际情况撰写，段落用空行分隔。",` : ''}
${description ? `  "parameters_es": ["• 参数1: 值1", "• 参数2: 值2"],` : ''}
${description ? `  "parameters_pt": ["• 参数1: 值1", "• 参数2: 值2"],` : ''}
  "keywords_es": ["核心词1", "核心词2", "属性词1", "属性词2", "属性词3", "场景词1", "场景词2", "长尾词1"],
  "keywords_pt": ["核心词1", "核心词2", "属性词1", "属性词2", "属性词3", "场景词1", "场景词2", "长尾词1"]
}

注意：keywords必须包含15-20个关键词，全部小写，无品牌词

═══════════════════════════════════════
              质量检查清单
═══════════════════════════════════════

✓ 标题字符数：30-60字符（推荐50-60字符）
✓ 标题核心词：品类词在开头
✓ 标题关键词：3-5个
✓ 描述长度：200-500字符
✓ 描述内容：必须包含属性、用途、特征、参数、包装、使用说明
✓ 描述真实性：根据产品实际信息撰写，不要虚构
✓ 关键词总数：15-20个
✓ 无禁用词：无品牌词、无夸大词
✓ 本地化正确：西语用audífonos、葡语用fones de ouvido等

只输出JSON，无其他文字。`;

    console.log('========== 开始生成Listing ==========');
    console.log('输入参数:', { 
      hasTitle: !!title, 
      hasDescription: !!description,
      titleLength: title?.length,
      descriptionLength: description?.length
    });

    console.log('========== 准备调用LLM ==========');
    console.log('模型: DeepSeek Chat, 温度: 0.3');
    console.log('System Prompt 长度:', systemPrompt.length);
    console.log('User Prompt 长度:', userPrompt.length);
    
    const llmResponse = await invokeLLM(
      [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      {
        temperature: 0.3,
        model: 'deepseek-v4-flash'
      }
    );

    console.log('========== LLM调用完成 ==========');
    console.log('响应长度:', llmResponse.content.length, '字符');
    console.log('响应前500字符:', llmResponse.content.substring(0, 500));

    // 解析JSON响应
    let result;
    try {
      const jsonMatch = llmResponse.content.match(/\{[\s\S]*\}/);
      let jsonString = jsonMatch ? jsonMatch[0] : llmResponse.content;
      
      // 尝试解析JSON
      try {
        result = JSON.parse(jsonString);
      } catch (firstError) {
        // 如果第一次解析失败，尝试修复JSON中的控制字符
        // LLM有时会在字符串中间插入未转义的换行符
        console.log('首次解析失败，尝试修复JSON...');
        
        // 方法1: 将JSON中的实际换行符替换为转义的换行符（在字符串值内）
        // 这是一个简化的修复，适用于大多数情况
        jsonString = jsonString
          .replace(/:\s*"/g, ':"') // 移除冒号后的空格
          .replace(/"\s*}/g, '"}') // 移除结束大括号前的空格
          .replace(/"\s*,/g, '",'); // 移除逗号前的空格
        
        // 方法2: 使用更健壮的JSON修复方式
        // 尝试逐字段提取
        result = extractJsonFields(jsonString);
      }
      
      console.log('========== JSON解析成功 ==========');
      if (result.title_es) console.log('西语标题:', result.title_es, `(${result.title_es.length}字符)`);
      if (result.title_pt) console.log('葡语标题:', result.title_pt, `(${result.title_pt.length}字符)`);
      if (result.description_es) console.log('西语描述长度:', result.description_es.length, '字符');
      if (result.description_pt) console.log('葡语描述长度:', result.description_pt.length, '字符');
      if (result.description_es) console.log('西语描述前200字符:', result.description_es.substring(0, 200));
    } catch (parseError) {
      console.error('========== JSON解析失败 ==========');
      console.error('错误:', parseError);
      console.error('原始响应:', llmResponse.content);
      throw new Error('解析LLM响应失败，请重试');
    }

    // 验证结果（根据输入验证）
    const errors: string[] = [];
    if (title) {
      if (!result.title_es || !result.title_pt) {
        errors.push('标题');
      }
    }
    if (description) {
      if (!result.description_es || !result.description_pt) {
        errors.push('描述');
      }
    }
    
    if (errors.length > 0) {
      console.error(`生成的内容不完整，缺失: ${errors.join(', ')}`, result);
      throw new Error(`生成的内容不完整，缺失: ${errors.join(', ')}，请重试`);
    }

    // 使用LLM审查和优化标题语法（如果标题存在）
    if (result.title_es || result.title_pt) {
      console.log('正在审查和优化标题语法...');
      const optimizedTitles = await optimizeTitles(
        { 
          es: result.title_es || '', 
          pt: result.title_pt || '' 
        }
      );
      
      if (result.title_es) {
        result.title_es = optimizedTitles.es;
      }
      if (result.title_pt) {
        result.title_pt = optimizedTitles.pt;
      }
      
      console.log('标题优化完成:', {
        title_es: result.title_es,
        title_es_length: result.title_es?.length || 0,
        title_pt: result.title_pt,
        title_pt_length: result.title_pt?.length || 0
      });
    }

    // 清理表情符号和特殊符号（但保留项目符号用于参数）
    const cleanText = (text: string) => {
      return text
        .replace(/https?:\/\/[^\s]+/gi, '') // 删除HTTP链接
        .replace(/www\.[^\s]+/gi, '') // 删除www链接
        .replace(/[\u{1F600}-\u{1F64F}]/gu, '') // emoji
        .replace(/[\u{1F300}-\u{1F5FF}]/gu, '') // symbols
        .replace(/[\u{1F680}-\u{1F6FF}]/gu, '') // transport
        .replace(/[\u{1F700}-\u{1F77F}]/gu, '') // alchemical
        .replace(/[\u{1F780}-\u{1F7FF}]/gu, '') // geometric
        .replace(/[\u{1F800}-\u{1F8FF}]/gu, '') // arrows
        .replace(/[\u{1F900}-\u{1F9FF}]/gu, '') // supplemental
        .replace(/[\u{1FA00}-\u{1FA6F}]/gu, '') // chess
        .replace(/[\u{1FA70}-\u{1FAFF}]/gu, '') // symbols extended
        .replace(/[\u{2600}-\u{26FF}]/gu, '') // misc
        .replace(/[\u{2700}-\u{27BF}]/gu, '') // dingbats
        .replace(/[★✓✓✔✅❌]/g, '') // common symbols
        .replace(/【|】|「|」|『|』|《|》|〈|〉|（|）|〔|〕]/g, '') // brackets
        .replace(/─│┌┐└┘├┤┬┴┼═║╔╗╚╝╠╣╦╩╬]/g, '') // box drawing
        .replace(/→←↑↓↔↕↖↗↘↙/g, '') // arrows
        .trim();
    };

    // 清理描述（如果存在）
    if (result.description_es) {
      result.description_es = cleanText(result.description_es);
    }
    if (result.description_pt) {
      result.description_pt = cleanText(result.description_pt);
    }

    // 格式化参数（确保每行一个参数）
    const formatParameters = (params: any) => {
      if (!Array.isArray(params)) return [];
      return params
        .filter(p => p && typeof p === 'string')
        .map(p => {
          let cleaned = cleanText(p);
          // 确保以•开头
          if (!cleaned.startsWith('•')) {
            cleaned = '• ' + cleaned;
          }
          // 替换其他项目符号为•
          cleaned = cleaned.replace(/^[•●◆▪▫○◇◈◉⦿●●]+\s*/g, '• ');
          return cleaned;
        })
        .filter(p => p.length > 0);
    };

    // 格式化参数（如果存在）
    if (result.parameters_es) {
      result.parameters_es = formatParameters(result.parameters_es);
    }
    if (result.parameters_pt) {
      result.parameters_pt = formatParameters(result.parameters_pt);
    }

    // 处理关键词分层（如果LLM返回的是对象格式）
    const flattenKeywords = (keywords: any): string[] => {
      if (Array.isArray(keywords)) {
        return keywords.map((k: string) => k.toLowerCase().trim());
      }
      if (typeof keywords === 'object' && keywords !== null) {
        // 如果是分层对象，合并所有层
        const allKeywords: string[] = [];
        if (keywords.core) allKeywords.push(...keywords.core);
        if (keywords.attribute) allKeywords.push(...keywords.attribute);
        if (keywords.scene) allKeywords.push(...keywords.scene);
        if (keywords.longtail) allKeywords.push(...keywords.longtail);
        return allKeywords.map((k: string) => k.toLowerCase().trim());
      }
      return [];
    };

    // 展平关键词（保持向后兼容）
    if (result.keywords_es) {
      const flatKeywordsEs = flattenKeywords(result.keywords_es);
      result.keywords_es = flatKeywordsEs;
      
      // 同时保存分层关键词
      if (typeof result.keywords_es !== 'object' || Array.isArray(result.keywords_es)) {
        const originalKeywords = result.keywords_es;
        result.keywords_layered_es = {
          core: originalKeywords.slice(0, 4),
          attribute: originalKeywords.slice(4, 9),
          scene: originalKeywords.slice(9, 13),
          longtail: originalKeywords.slice(13, 16)
        };
      }
    }
    if (result.keywords_pt) {
      const flatKeywordsPt = flattenKeywords(result.keywords_pt);
      result.keywords_pt = flatKeywordsPt;
      
      if (typeof result.keywords_pt !== 'object' || Array.isArray(result.keywords_pt)) {
        const originalKeywords = result.keywords_pt;
        result.keywords_layered_pt = {
          core: originalKeywords.slice(0, 4),
          attribute: originalKeywords.slice(4, 9),
          scene: originalKeywords.slice(9, 13),
          longtail: originalKeywords.slice(13, 16)
        };
      }
    }

    // 计算质量评分
    const qualityScore = {
      title_es: result.title_es ? scoreTitle(result.title_es, 'es') : null,
      title_pt: result.title_pt ? scoreTitle(result.title_pt, 'pt') : null,
      description_es: result.description_es ? scoreDescription(result.description_es, 'es') : null,
      description_pt: result.description_pt ? scoreDescription(result.description_pt, 'pt') : null,
    };

    // 检查禁用词
    const forbiddenCheck = {
      title_es: result.title_es ? checkForbiddenWords(result.title_es, 'es') : [],
      title_pt: result.title_pt ? checkForbiddenWords(result.title_pt, 'pt') : [],
      description_es: result.description_es ? checkForbiddenWords(result.description_es, 'es') : [],
      description_pt: result.description_pt ? checkForbiddenWords(result.description_pt, 'pt') : [],
    };

    // 获取优化建议
    const suggestions = {
      title_es: result.title_es ? getTitleOptimizationSuggestions(result.title_es, 'es') : [],
      title_pt: result.title_pt ? getTitleOptimizationSuggestions(result.title_pt, 'pt') : [],
    };

    // 添加质量评分到结果
    result.quality = {
      score: qualityScore,
      forbiddenWords: forbiddenCheck,
      suggestions: suggestions,
    };

    console.log('========== 质量评分 ==========');
    console.log('西语标题评分:', qualityScore.title_es?.overall || 'N/A');
    console.log('葡语标题评分:', qualityScore.title_pt?.overall || 'N/A');
    console.log('西语描述评分:', qualityScore.description_es?.overall || 'N/A');
    console.log('葡语描述评分:', qualityScore.description_pt?.overall || 'N/A');
    console.log('生成成功');

    return NextResponse.json(result);

  } catch (error) {
    console.error('生成Listing失败:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : '生成失败，请重试'
      },
      { status: 500 }
    );
  }
}
