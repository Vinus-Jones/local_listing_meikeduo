'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import AutoImageTranslation from '@/components/auto-image-translation';
import ListingDisplay from '@/components/listing-display';
import { Upload, Loader2 } from 'lucide-react';

interface ListingResult {
  title_es?: string;
  title_pt?: string;
  description_es?: string;
  description_pt?: string;
  parameters_es?: string[];
  parameters_pt?: string[];
  keywords_es?: string[];
  keywords_pt?: string[];
}

export default function MercadoLibreListingGenerator() {
  const [manualTitle, setManualTitle] = useState('');
  const [manualDescription, setManualDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ListingResult | null>(null);
  const [error, setError] = useState('');

  // 图片上传相关状态（支持多张图片）
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [imageAnalyses, setImageAnalyses] = useState<string[]>([]);
  const [analyzingIndices, setAnalyzingIndices] = useState<Set<number>>(new Set());
  const [imageAnalysisComplete, setImageAnalysisComplete] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 从URL参数读取并自动填充
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const title = params.get('title');
    const description = params.get('description');

    if (title) {
      setManualTitle(decodeURIComponent(title));
    }
    if (description) {
      setManualDescription(decodeURIComponent(description));
    }
  }, []);

  const handleGenerate = async () => {
    // 优先使用文本输入（如果用户已经输入了标题或描述）
    if (manualTitle.trim() || manualDescription.trim()) {
      // 使用文本生成
      setLoading(true);
      setError('');
      setResult(null);

      try {
        const response = await fetch('/api/generate-listing-manual', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            title: manualTitle.trim() || undefined,
            description: manualDescription.trim() || undefined,
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || '生成失败');
        }

        setResult(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : '生成失败，请重试');
      } finally {
        setLoading(false);
      }
      return;
    }

    // 如果没有文本输入，但有图片，使用图片识别结果生成
    if (uploadedImages.length > 0) {
      if (!imageAnalysisComplete) {
        // 先进行图片识别
        setError('请先点击"识别图片"或"批量识别"按钮进行图片识别');
        return;
      }
      
      // 使用合并的识别结果填充到文本框
      const mergedAnalysis = getMergedAnalysis();
      if (mergedAnalysis) {
        setManualDescription(mergedAnalysis);
      }
      
      // 使用第一张图片的生成结果
      if (imageAnalyses.length > 0 && imageAnalyses[0]) {
        // 使用第一张图片作为主要来源生成Listing
        await handleGenerateFromImage(0);
        return;
      }
    }

    // 既没有文本也没有图片
    setError('请输入产品标题或描述（至少一项），或上传产品图片进行识别');
  };

  // 处理图片上传
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // 支持批量上传
    const filesArray = Array.from(files);
    const newImages: string[] = [];
    
    let processedCount = 0;
    filesArray.forEach((file) => {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        newImages.push(base64);
        
        processedCount++;
        // 所有文件处理完成后更新状态
        if (processedCount === filesArray.length) {
          setUploadedImages(prev => [...prev, ...newImages]);
          setImageAnalyses(prev => [...prev, ...new Array(newImages.length).fill('')]);
        }
      };
      
      reader.readAsDataURL(file);
    });
  };

  // 删除指定图片
  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
    setImageAnalyses(prev => prev.filter((_, i) => i !== index));
    setAnalyzingIndices(prev => {
      const newSet = new Set(prev);
      newSet.delete(index);
      return newSet;
    });
  };

  // 清空所有图片
  const clearAllImages = () => {
    setUploadedImages([]);
    setImageAnalyses([]);
    setAnalyzingIndices(new Set());
    setImageAnalysisComplete(false);
  };

  // 从单张图片生成Listing
  const handleGenerateFromImage = async (imageIndex: number) => {
    if (!uploadedImages[imageIndex]) {
      setError('请上传产品图片');
      return;
    }

    setAnalyzingIndices(prev => new Set([...prev, imageIndex]));
    setError('');
    setLoading(true);

    try {
      const response = await fetch('/api/generate-listing-from-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          image: uploadedImages[imageIndex],
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '生成失败');
      }

      // 更新该图片的识别结果
      setImageAnalyses(prev => {
        const newAnalyses = [...prev];
        newAnalyses[imageIndex] = data.imageAnalysis || '';
        return newAnalyses;
      });
      
      setImageAnalysisComplete(true);
      
      // 如果返回了完整结果，直接设置
      if (data.title_es && data.title_pt && data.description_es && data.description_pt) {
        setResult({
          title_es: data.title_es,
          title_pt: data.title_pt,
          description_es: data.description_es,
          description_pt: data.description_pt,
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : '生成失败，请重试');
    } finally {
      setAnalyzingIndices(prev => {
        const newSet = new Set(prev);
        newSet.delete(imageIndex);
        return newSet;
      });
      setLoading(false);
    }
  };

  // 批量识别所有图片
  const handleBatchAnalyze = async () => {
    if (uploadedImages.length === 0) {
      setError('请先上传图片');
      return;
    }

    setLoading(true);
    setError('');
    
    // 标记所有图片为正在识别
    const allIndices = new Set(uploadedImages.map((_, i) => i));
    setAnalyzingIndices(allIndices);

    try {
      // 并行识别所有图片
      const promises = uploadedImages.map(async (image, index) => {
        try {
          const response = await fetch('/api/generate-listing-from-image', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ image }),
          });

          const data = await response.json();

          if (!response.ok) {
            console.error(`图片 ${index + 1} 识别失败:`, data.error);
            return { index, analysis: '', error: data.error };
          }

          return { index, analysis: data.imageAnalysis || '', data };
        } catch (err) {
          console.error(`图片 ${index + 1} 识别错误:`, err);
          return { index, analysis: '', error: '识别失败' };
        }
      });

      const results = await Promise.all(promises);
      
      // 更新所有图片的识别结果
      const newAnalyses = [...imageAnalyses];
      results.forEach(({ index, analysis }) => {
        if (analysis) {
          newAnalyses[index] = analysis;
        }
      });
      setImageAnalyses(newAnalyses);
      setImageAnalysisComplete(true);

    } catch (err) {
      setError(err instanceof Error ? err.message : '批量识别失败，请重试');
    } finally {
      setAnalyzingIndices(new Set());
      setLoading(false);
    }
  };

  // 获取合并后的识别结果
  const getMergedAnalysis = (): string => {
    const validAnalyses = imageAnalyses.filter(a => a && a.trim());
    if (validAnalyses.length === 0) return '';
    
    // 合并多张图片的识别结果
    let merged = '';
    validAnalyses.forEach((analysis, index) => {
      merged += `=== 图片 ${index + 1} 识别结果 ===\n${analysis}\n\n`;
    });
    
    return merged.trim();
  };

  const loadExample = () => {
    setManualTitle('Succulents Botanical Collection Artificial Plants Fake Succulents in Pot for Housewarming, Birthday, Home Decor, Gift');
    setManualDescription('【Botanical Collection】Set of 4 artificial succulents in pots, featuring realistic details and vibrant colors. Perfect for home decor, office spaces, or as a thoughtful gift for housewarming and birthdays. These lifelike fake plants require no watering or maintenance, making them ideal for busy individuals or those without green thumbs. Each succulent is crafted with premium quality materials to ensure durability and long-lasting beauty. The variety of styles and colors adds a natural touch to any space. Great for DIY projects, wedding centerpieces, or room decoration.');
    setError('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-6xl mx-auto">
        {/* 标题区域 */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
            美客多产品Listing生成器
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            支持文本输入或图片识别（支持批量上传），自动生成优化的拉美西语和巴西葡语Listing
          </p>
        </div>

        {/* 使用说明 */}
        <Card className="mb-6 shadow-lg bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="pt-6">
            <div className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
              <p className="font-semibold text-base">📋 如何使用：</p>
              <div className="space-y-2">
                <div>
                  <p className="font-medium text-blue-700 dark:text-blue-300">方式一：文本输入</p>
                  <ol className="list-decimal ml-6 mt-1 space-y-1">
                    <li>打开亚马逊产品页面，复制<strong>产品标题</strong>（页面顶部的加粗文字）</li>
                    <li>复制<strong>产品描述</strong>（包括五点描述和详细描述）</li>
                    <li>粘贴到下方的输入框中</li>
                    <li>点击"生成Listing"按钮</li>
                  </ol>
                </div>
                <div>
                  <p className="font-medium text-green-700 dark:text-green-300">方式二：单张图片识别</p>
                  <ol className="list-decimal ml-6 mt-1 space-y-1">
                    <li>准备一张清晰的产品图片（主图或详情图）</li>
                    <li>点击"上传产品图片"按钮</li>
                    <li>上传图片后，点击"批量识别"按钮</li>
                    <li>查看识别结果，点击"应用到文本框"或直接生成Listing</li>
                  </ol>
                </div>
                <div>
                  <p className="font-medium text-orange-700 dark:text-orange-300">方式三：批量图片识别（推荐）</p>
                  <ol className="list-decimal ml-6 mt-1 space-y-1">
                    <li>准备多张产品图片（主图、细节图、包装图等）</li>
                    <li>点击"上传产品图片"按钮，选择多张图片</li>
                    <li>点击"批量识别"按钮，AI将自动识别所有图片</li>
                    <li>查看合并的识别结果，点击"应用到文本框"填充</li>
                    <li>基于识别结果补充细节，点击"生成Listing"</li>
                  </ol>
                </div>
                <div>
                  <p className="font-medium text-purple-700 dark:text-purple-300">方式四：文本+图片混合</p>
                  <ol className="list-decimal ml-6 mt-1 space-y-1">
                    <li>上传图片进行批量识别，获取全面的产品信息</li>
                    <li>点击"应用到文本框"将识别结果填充</li>
                    <li>基于识别结果，补充或修改文本内容</li>
                    <li>点击"生成Listing"按钮，使用修改后的内容生成</li>
                  </ol>
                </div>
              </div>
              <p className="mt-2 text-xs text-gray-500">
                💡 提示：批量识别可以获取更全面的产品信息，推荐使用多张图片（主图+细节图）
              </p>
            </div>
          </CardContent>
        </Card>

        {/* 输入区域 */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle>输入产品信息</CardTitle>
            <CardDescription>
              可以使用文本输入或图片识别，也可以两者结合使用
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* 文本输入区域 */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="manual-title" className="mb-2 block font-medium">
                    产品标题
                  </Label>
                  <Input
                    id="manual-title"
                    type="text"
                    placeholder="例如：Succulents Botanical Collection Artificial Plants..."
                    value={manualTitle}
                    onChange={(e) => setManualTitle(e.target.value)}
                    disabled={loading}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    提示：可以手动输入，也可以从图片识别结果填充
                  </p>
                </div>
                <div>
                  <Label htmlFor="manual-description" className="mb-2 block font-medium">
                    产品描述（包括五点描述）
                  </Label>
                  <Textarea
                    id="manual-description"
                    placeholder="例如：【Botanical Collection】Set of 4 artificial succulents...&#10;Features:&#10;- Realistic appearance&#10;- Low maintenance&#10;- Durable material..."
                    value={manualDescription}
                    onChange={(e) => setManualDescription(e.target.value)}
                    disabled={loading}
                    rows={8}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    提示：可以手动输入，也可以从图片识别结果填充或修改
                  </p>
                </div>
              </div>

              {/* 图片上传区域 */}
              <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                <Label className="mb-4 block font-medium">
                  上传产品图片（可选，支持批量上传，用于识别和补充信息）
                </Label>
                {uploadedImages.length === 0 ? (
                  <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      variant="outline"
                      size="lg"
                      disabled={loading}
                    >
                      <Upload className="w-5 h-5 mr-2" />
                      上传产品图片（支持批量）
                    </Button>
                    <p className="text-xs text-gray-500 mt-2">
                      支持 JPG、PNG、WebP 格式，最大 10MB，可选择多张图片
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* 图片预览网格 */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {uploadedImages.map((image, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={image}
                            alt={`产品图片 ${index + 1}`}
                            className="w-full h-48 object-cover rounded-lg border-2 border-gray-200 dark:border-gray-700"
                          />
                          {/* 删除按钮 */}
                          <Button
                            onClick={() => removeImage(index)}
                            variant="destructive"
                            size="sm"
                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                            disabled={loading}
                          >
                            ✕
                          </Button>
                          {/* 识别状态标签 */}
                          <div className="absolute bottom-2 left-2 right-2">
                            {analyzingIndices.has(index) ? (
                              <div className="bg-blue-500 text-white text-xs px-2 py-1 rounded flex items-center gap-1">
                                <Loader2 className="w-3 h-3 animate-spin" />
                                识别中...
                              </div>
                            ) : imageAnalyses[index] ? (
                              <div className="bg-green-500 text-white text-xs px-2 py-1 rounded">
                                已识别
                              </div>
                            ) : (
                              <div className="bg-gray-500 text-white text-xs px-2 py-1 rounded">
                                未识别
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* 操作按钮 */}
                    <div className="flex gap-2">
                      <Button
                        onClick={() => fileInputRef.current?.click()}
                        variant="outline"
                        className="flex-1"
                        disabled={loading}
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        添加更多图片
                      </Button>
                      <Button
                        onClick={clearAllImages}
                        variant="outline"
                        className="flex-1"
                        disabled={loading}
                      >
                        清空所有图片
                      </Button>
                      <Button
                        onClick={handleBatchAnalyze}
                        disabled={loading || analyzingIndices.size > 0}
                        size="lg"
                        className="flex-1"
                      >
                        {loading && analyzingIndices.size > 0 ? (
                          <>
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            批量识别中...
                          </>
                        ) : (
                          <>
                            <Loader2 className="w-5 h-5 mr-2" />
                            批量识别
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}

                {imageAnalysisComplete && imageAnalyses.some(a => a) && (
                  <div className="mt-4 space-y-3">
                    <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
                      <div className="flex items-center justify-between mb-2">
                        <Label className="font-semibold text-blue-900 dark:text-blue-100">
                          图片识别结果（{uploadedImages.length}张图片）
                        </Label>
                        <Button
                          onClick={() => {
                            // 将合并的识别结果应用到文本框
                            const mergedAnalysis = getMergedAnalysis();
                            if (mergedAnalysis) {
                              setManualDescription(mergedAnalysis);
                              alert('已将图片识别结果填充到文本框，您可以继续编辑和补充！');
                            }
                          }}
                          variant="outline"
                          size="sm"
                          disabled={loading}
                        >
                          应用到文本框
                        </Button>
                      </div>
                      <div className="max-h-60 overflow-y-auto text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">
                        {getMergedAnalysis()}
                      </div>
                    </div>
                    <p className="text-xs text-gray-500">
                      💡 提示：您可以基于识别结果继续编辑文本框内容，或直接点击下方"生成Listing"按钮
                    </p>
                  </div>
                )}
              </div>

              {/* 操作按钮 */}
              <div className="flex gap-4 border-t border-gray-200 dark:border-gray-700 pt-6">
                <Button
                  onClick={loadExample}
                  disabled={loading}
                  variant="outline"
                  className="flex-1"
                >
                  加载示例
                </Button>
                <Button
                  onClick={handleGenerate}
                  disabled={loading}
                  size="lg"
                  className="flex-1"
                >
                  {loading ? '生成中...' : '生成Listing'}
                </Button>
              </div>

              {error && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 dark:bg-red-900/20 dark:border-red-800 dark:text-red-400">
                  {error}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* 图片自动翻译区域 */}
        <AutoImageTranslation />

        {/* 结果展示区域 */}
        {result && (
          <ListingDisplay result={result} onResultUpdate={setResult} />
        )}

        {/* 生成规则 */}
        {!result && (
          <Card className="mt-8 shadow-lg bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
            <CardContent className="pt-6">
              <div className="space-y-3 text-sm text-gray-700 dark:text-gray-300">
                <p className="font-semibold">📝 生成规则（对标亚马逊A+页面）：</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li><strong>标题：</strong>60字符以内，包含产品类型+核心特征</li>
                  <li><strong>语言：</strong>地道拉美西语（墨西哥/智利/哥伦比亚市场习惯）</li>
                  <li><strong>风格：</strong>简洁易懂，移动端友好，短句分段</li>
                  <li><strong>结构：</strong>产品简介 → 核心价值 → 使用场景 → 功能优势 → 材质特点 → 包装清单 → 使用提示 → 贴心说明</li>
                  <li><strong>禁止：</strong>表情符号、链接、夸大宣传、违规承诺</li>
                  <li><strong>格式：</strong>纯文本分段，适合直接粘贴到美客多</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
