# 美客多Listing生成器 - 书签脚本使用指南

## 什么是书签脚本？

书签脚本（Bookmarklet）是一段JavaScript代码，可以保存为浏览器书签。当你点击这个书签时，它会自动执行，抓取当前页面的数据并跳转到生成器页面自动填充。

## 书签脚本代码

复制以下代码：

```javascript
javascript:(function(){const t=document.getElementById('productTitle')?.innerText?.trim()||document.querySelector('.product-title')?.innerText?.trim()||document.querySelector('h1')?.innerText?.trim()||'';const d=document.getElementById('productDescription')?.innerText?.trim()||document.getElementById('feature-bullets')?.innerText?.trim()||document.querySelector('#productDescription')?.innerText?.trim()||document.querySelector('.a-list-item')?.innerText?.trim()||'';if(t&&d){const e=encodeURIComponent(t),n=encodeURIComponent(d);window.open(`http://localhost:5000/?title=${e}&description=${n}`,'_blank')}else{alert('无法自动抓取产品信息！\n\n请手动复制产品标题和描述。\n\n1. 标题：通常在页面顶部，加粗显示\n2. 描述：在"About this item"部分')}})();
```

## 如何添加书签脚本

### Chrome / Edge / Brave 浏览器

#### 方法1：拖拽添加（推荐）
1. 在浏览器中右键点击书签栏，选择"添加书签"
2. 名称填写：`美客多抓取`
3. 网址粘贴上面的JavaScript代码
4. 保存

#### 方法2：手动创建
1. 按 `Ctrl + Shift + O`（Mac: `Cmd + Shift + O`）打开书签管理器
2. 点击右上角的三个点，选择"添加新书签"
3. 名称填写：`美客多抓取`
4. 网址粘贴上面的JavaScript代码
5. 保存

### Firefox 浏览器

1. 按 `Ctrl + Shift + O`（Mac: `Cmd + Shift + O`）打开书签管理器
2. 点击"管理书签工具栏"
3. 点击"新建书签"
4. 名称填写：`美客多抓取`
5. 位置粘贴上面的JavaScript代码
6. 保存

## 如何使用

1. 打开亚马逊产品页面
2. 点击浏览器书签栏中的"美客多抓取"
3. 系统会自动抓取产品信息并打开新页面
4. 检查自动填充的内容是否正确
5. 点击"生成Listing"按钮

## 如果自动抓取失败？

如果书签脚本无法自动抓取（提示错误），请手动操作：

1. 在亚马逊页面复制产品标题
2. 复制产品描述（包括五点描述）
3. 打开工具页面：`http://localhost:5000/`
4. 手动粘贴到输入框
5. 点击"生成Listing"

## 注意事项

⚠️ **重要提示：**

- 书签脚本中的URL `http://localhost:5000/` 是本地开发地址
- 如果你部署到了服务器，需要修改代码中的URL为你的实际地址
- 例如：如果你的域名是 `example.com`，则改为 `https://example.com/`

### 修改URL的方法

1. 复制上面的JavaScript代码
2. 找到 `http://localhost:5000/`
3. 替换为你的实际URL
4. 重新保存书签

## 书签脚本说明

### 支持的亚马逊页面元素

脚本会尝试以下方式抓取标题：
- `#productTitle` - 亚马逊标准标题
- `.product-title` - 其他变体
- `h1` - 页面主标题

脚本会尝试以下方式抓取描述：
- `#productDescription` - 产品描述
- `#feature-bullets` - 五点描述
- `.a-list-item` - 特性列表

### 代码逻辑

```javascript
// 1. 尝试抓取标题
const title = document.getElementById('productTitle')?.innerText?.trim();

// 2. 尝试抓取描述
const description = document.getElementById('productDescription')?.innerText?.trim();

// 3. 如果成功抓取，跳转到工具页面并传递参数
if (title && description) {
  const encodedTitle = encodeURIComponent(title);
  const encodedDesc = encodeURIComponent(description);
  window.open(`http://localhost:5000/?title=${encodedTitle}&description=${encodedDesc}`, '_blank');
}

// 4. 如果失败，提示用户手动操作
else {
  alert('无法自动抓取...');
}
```

## 常见问题

### Q: 点击书签没有反应？
A: 检查：
1. 确保URL是以 `javascript:` 开头
2. 确保没有空格或换行
3. 尝试右键点击书签，选择"编辑"查看是否正确

### Q: 抓取的数据不完整？
A: 可能原因：
1. 页面还在加载中，稍等片刻再点击
2. 页面结构发生变化，脚本无法识别
3. 建议手动复制

### Q: 提示"无法自动抓取"？
A: 页面结构可能不符合预期，请使用手动复制方式

### Q: 如何删除书签？
A: 右键点击书签 → 删除

## 技术说明

- 代码使用URL参数传递数据
- `encodeURIComponent()` 确保特殊字符正确编码
- `window.open('_blank')` 在新标签页打开工具页面
- 不涉及任何数据上传，完全在本地处理

## 更新记录

- 2024-01-XX: 初始版本，支持Amazon标准页面抓取

## 反馈与支持

如果遇到问题或有改进建议，请联系开发者。
