# 美客多产品Listing生成器

一个智能工具，帮助你将亚马逊产品信息快速转换为美客多（Mercado Libre）平台适用的Listing内容，支持拉美西语和巴西葡语两种语言。

## 功能特点

- ✅ 手动输入产品信息
- ✅ 智能翻译为拉美西语（墨西哥、哥伦比亚、智利等）
- ✅ 智能翻译为巴西葡语（巴西市场）
- ✅ 标题自动优化，控制在60字符以内
- ✅ 描述合并优化，避免侵权和表情符号
- ✅ 一键复制功能
- ✅ 实时字符计数
- ✅ 示例数据加载功能

## 使用方法

### 步骤 1：复制亚马逊产品信息

1. 打开亚马逊产品页面
2. **复制产品标题**
   - 标题通常在页面顶部
   - 加粗显示，字体较大
   - 例如：`Succulents Botanical Collection Artificial Plants Fake Succulents in Pot...`

3. **复制产品描述**
   - 找到"About this item"或"About this product"部分
   - 复制所有五点描述（bullet points）
   - 如果有详细描述，也一并复制
   - 例如：
     ```
     【Botanical Collection】Set of 4 artificial succulents in pots, featuring realistic details and vibrant colors. Perfect for home decor, office spaces, or as a thoughtful gift for housewarming and birthdays.

     Features:
     - Realistic appearance
     - Low maintenance
     - Durable material
     - Multiple color options
     - Beautifully packaged
     ```

### 步骤 2：输入到工具

1. 访问应用页面
2. 在"产品标题"输入框中粘贴标题
3. 在"产品描述"文本框中粘贴描述（包括五点描述）
4. 点击 **"生成Listing"** 按钮

### 步骤 3：复制使用

生成完成后，可以分别复制：
- 拉美西语标题和描述
- 巴西葡语标题和描述

### 快速体验

如果你想先试试功能，可以点击 **"加载示例"** 按钮，系统会自动填入示例产品信息，然后点击"生成Listing"即可。

## 使用示例

### 输入示例

**产品标题：**
```
Succulents Botanical Collection Artificial Plants Fake Succulents in Pot for Housewarming, Birthday, Home Decor, Gift
```

**产品描述：**
```
【Botanical Collection】Set of 4 artificial succulents in pots, featuring realistic details and vibrant colors. Perfect for home decor, office spaces, or as a thoughtful gift for housewarming and birthdays. These lifelike fake plants require no watering or maintenance, making them ideal for busy individuals or those without green thumbs. Each succulent is crafted with premium quality materials to ensure durability and long-lasting beauty. The variety of styles and colors adds a natural touch to any space. Great for DIY projects, wedding centerpieces, or room decoration.
```

### 输出示例

**拉美西语标题（60字符）：**
```
Set de 4 Suculentas Artificiales con Maceta para Decoración
```

**巴西葡语标题（60字符）：**
```
Conjunto de 4 Suculentas Artificiais com Vaso para Decoração
```

**拉美西语描述：**
```
Set de 4 Suculentas Artificiales con Maceta para Decoración y Regalos. Colección botánica de 4 suculentas artificiales en maceta, con detalles realistas y colores vibrantes. Ideal para decorar el hogar, espacios de oficina o como regalo detallado para inauguraciones de casa y cumpleaños. Estas plantas falsas de aspecto natural no requieren riego ni mantenimiento, por lo que son perfectas para personas ocupadas o que no tienen experiencia en jardinería. Cada suculenta está elaborada con materiales de alta calidad para garantizar durabilidad y belleza duradera. La variedad de estilos y colores aporta un toque natural a cualquier espacio. También son adecuadas para proyectos de bricolaje, centros de mesa de bodas o decoración de habitaciones.
```

**巴西葡语描述：**
```
Conjunto de 4 Suculentas Artificiais com Vaso para Decoração e Presentes. Coleção botânica de 4 suculentas artificiais em vaso, com detalhes realistas e cores vibrantes. Perfeito para decorar a casa, espaços de escritório ou como presente atencioso para inaugurações de casa e aniversários. Essas plantas falsas de aparência natural não precisam de irrigação nem manutenção, sendo ideais para pessoas ocupadas ou que não têm experiência com jardinagem. Cada suculenta é fabricada com materiais de alta qualidade para garantir durabilidade e beleza duradoura. A variedade de estilos e cores adiciona um toque natural a qualquer ambiente. Também são adequadas para projetos de faça você mesmo, centros de mesa de casamentos ou decoração de ambientes.
```

## 生成规则

### 标题限制
- 拉美西语：≤60字符
- 巴西葡语：≤60字符
- 避免使用品牌词和商标
- 突出产品核心卖点
- 语言地道，符合当地表达习惯

### 描述规范
- 合并标题和产品描述
- 避免侵权内容
- 不包含任何表情符号
- 语言地道，符合当地习惯
- 突出产品特点和优势

### 输出格式
- 纯文本格式
- 易于复制和编辑
- 适用于美客多平台发布

## 常见问题

### Q: 为什么不能直接输入亚马逊链接？

A: 亚马逊有强大的反爬虫机制，阻止自动化工具抓取页面内容。因此我们采用手动输入的方式，你可以从亚马逊页面复制产品信息后粘贴到工具中。

### Q: 手动输入需要复制哪些内容？

A: 需要复制两部分：
1. **产品标题** - 通常在页面顶部，加粗显示
2. **产品描述** - 包括五点描述（bullet points）和详细描述

### Q: 五点描述是什么？

A: 五点描述（bullet points）是亚马逊产品页面中"About this item"部分的要点列表，通常以圆点或横线开头，列出产品的主要特点和优势。

### Q: 生成的内容可以直接发布吗？

A: 可以直接使用，但建议：
1. 检查翻译的准确性
2. 根据实际产品调整细节
3. 添加当地市场的关键词
4. 确保符合美客多的发布规则

### Q: 标题超过60字符怎么办？

A: 工具会自动截断到60字符，但你可以：
1. 手动编辑标题，使其更简洁
2. 重新生成，修改原始标题
3. 在美客多发布时使用完整版本（如果平台允许）

### Q: "加载示例"按钮有什么用？

A: 点击后会自动填入示例产品信息，让你可以快速体验工具的功能，了解输入格式和输出效果。

## 技术说明

- **框架：** Next.js 16 + React 19
- **语言：** TypeScript
- **样式：** Tailwind CSS 4
- **组件库：** shadcn/ui
- **AI能力：** coze-coding-dev-sdk (LLM)

## 更新日志

### v2.0 (2026-03-01)
- ✅ 移除不可用的自动抓取功能
- ✅ 优化界面，默认显示手动输入
- ✅ 添加详细的使用说明
- ✅ 新增"加载示例"功能
- ✅ 改进用户提示和引导
- ✅ 简化操作流程

### v1.0 (2026-03-01)
- ✅ 初始版本
- ✅ 支持手动输入产品信息
- ✅ 生成拉美西语和巴西葡语Listing
- ✅ 一键复制功能

## 许可证

MIT License

## 支持

如遇到问题或有改进建议，请通过以下方式联系：
- 提交 Issue
- 发送反馈邮件
