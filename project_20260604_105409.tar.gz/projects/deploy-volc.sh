#!/bin/bash
#===============================================
# 快速部署到火山引擎 (ByteDance Cloud)
# https://www.volcengine.com/
#===============================================

set -e

echo "=========================================="
echo "MercardoLibre Listing - 火山引擎部署"
echo "=========================================="

# 1. 检查必要工具
echo ""
echo "[1/5] 检查必要工具..."

if ! command -v docker &> /dev/null; then
    echo "安装 Docker..."
    curl -fsSL https://get.docker.com | sh
fi

if ! command -v docker-compose &> /dev/null; then
    echo "安装 Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

echo "✓ 必要工具已就绪"

# 2. 构建镜像
echo ""
echo "[2/5] 构建 Docker 镜像（使用国内镜像源）..."

# 修改 Dockerfile 使用国内镜像源
sed -i 's|npm install -g pnpm@9|npm install -g pnpm@9|g' Dockerfile
sed -i 's|https://registry.npmmirror.com|npm config set registry https://registry.npmmirror.com|g' Dockerfile

docker build -t mercadolibre-listing:latest .

echo "✓ 镜像构建完成"

# 3. 启动容器
echo ""
echo "[3/5] 启动容器..."

docker stop mercadolibre-listing 2>/dev/null || true
docker rm mercadolibre-listing 2>/dev/null || true

docker run -d \
    --name mercadolibre-listing \
    --restart unless-stopped \
    -p 5000:5000 \
    -e NODE_ENV=production \
    -e PORT=5000 \
    -e DEEPSEEK_API_KEY="sk-f4fc430e2bc345b8afe2d37aee02dd13" \
    mercadolibre-listing:latest

echo "✓ 容器已启动"

# 4. 等待服务启动
echo ""
echo "[4/5] 等待服务启动..."

for i in {1..30}; do
    if curl -s http://localhost:5000 > /dev/null 2>&1; then
        echo "✓ 服务启动成功！"
        break
    fi
    echo "等待启动... ($i/30)"
    sleep 2
done

# 5. 显示结果
echo ""
echo "[5/5] 部署完成！"
echo ""
echo "=========================================="
echo "访问地址: http://你的服务器IP:5000"
echo "API地址:  http://你的服务器IP:5000/api/generate-listing-manual"
echo ""
echo "管理命令:"
echo "  查看日志: docker logs -f mercadolibre-listing"
echo "  停止服务: docker stop mercadolibre-listing"
echo "  启动服务: docker start mercadolibre-listing"
echo "  重启服务: docker restart mercadolibre-listing"
echo "=========================================="
