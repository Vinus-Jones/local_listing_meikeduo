#!/bin/bash
#===============================================
# MercardoLibre Listing Generator - 部署脚本
# 适用于阿里云、腾讯云、火山引擎
#===============================================

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 项目名称
PROJECT_NAME="mercadolibre-listing"

# 打印带颜色的消息
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查命令
check_command() {
    if ! command -v $1 &> /dev/null; then
        print_error "$1 未安装，请先安装"
        exit 1
    fi
}

# 显示帮助
show_help() {
    echo "用法: $0 [命令]"
    echo ""
    echo "命令:"
    echo "  deploy      部署应用到服务器"
    echo "  start       启动容器"
    echo "  stop        停止容器"
    echo "  restart     重启容器"
    echo "  logs        查看日志"
    echo "  status      查看状态"
    echo "  update      更新应用"
    echo "  backup      备份数据"
    echo "  restore     恢复数据"
    echo ""
    echo "示例:"
    echo "  $0 deploy           # 部署应用"
    echo "  $0 deploy --nginx   # 部署应用（含 Nginx 反向代理）"
}

# 部署函数
deploy() {
    print_info "开始部署 $PROJECT_NAME..."
    
    # 检查 Docker
    check_command docker
    check_command docker-compose
    
    # 构建并启动
    print_info "构建 Docker 镜像..."
    docker-compose build --no-cache
    
    print_info "启动容器..."
    docker-compose up -d
    
    # 等待健康检查
    print_info "等待服务启动..."
    sleep 10
    
    # 检查状态
    if docker-compose ps | grep -q "healthy"; then
        print_info "部署成功！服务已启动"
    else
        print_warn "服务已启动，请检查健康状态"
    fi
    
    print_info "访问地址: http://你的服务器IP:5000"
}

# 启动函数
start() {
    print_info "启动服务..."
    docker-compose up -d
    print_info "服务已启动"
}

# 停止函数
stop() {
    print_info "停止服务..."
    docker-compose down
    print_info "服务已停止"
}

# 重启函数
restart() {
    print_info "重启服务..."
    docker-compose restart
    print_info "服务已重启"
}

# 日志函数
show_logs() {
    docker-compose logs -f --tail=100
}

# 状态函数
show_status() {
    docker-compose ps
    echo ""
    print_info "服务健康状态:"
    curl -s http://localhost:5000 > /dev/null && print_info "✓ 服务正常" || print_error "✗ 服务异常"
}

# 更新函数
update() {
    print_info "更新应用..."
    docker-compose pull
    docker-compose up -d --build
    print_info "更新完成"
}

# 备份函数
backup() {
    BACKUP_DIR="./backups/$(date +%Y%m%d_%H%M%S)"
    mkdir -p $BACKUP_DIR
    
    print_info "备份到 $BACKUP_DIR..."
    
    # 备份 Docker 配置
    cp docker-compose.yml $BACKUP_DIR/
    cp Dockerfile $BACKUP_DIR/
    
    # 备份环境变量
    [ -f .env ] && cp .env $BACKUP_DIR/
    
    print_info "备份完成: $BACKUP_DIR"
}

# 恢复函数
restore() {
    if [ -z "$1" ]; then
        print_error "请指定备份目录"
        echo "用法: $0 restore <备份目录>"
        exit 1
    fi
    
    BACKUP_DIR=$1
    
    if [ ! -d "$BACKUP_DIR" ]; then
        print_error "备份目录不存在: $BACKUP_DIR"
        exit 1
    fi
    
    print_info "从 $BACKUP_DIR 恢复..."
    
    cp $BACKUP_DIR/docker-compose.yml ./
    cp $BACKUP_DIR/Dockerfile ./
    [ -f $BACKUP_DIR/.env ] && cp $BACKUP_DIR/.env ./
    
    docker-compose up -d
    print_info "恢复完成"
}

# 主程序
case "${1:-deploy}" in
    deploy)
        deploy
        ;;
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        restart
        ;;
    logs)
        show_logs
        ;;
    status)
        show_status
        ;;
    update)
        update
        ;;
    backup)
        backup
        ;;
    restore)
        restore $2
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        print_error "未知命令: $1"
        show_help
        exit 1
        ;;
esac
