#!/bin/bash
#===============================================
# 火山引擎一键部署脚本
# 用于在 ECS 服务器上直接部署
#===============================================

set -e

# 配置
APP_NAME="mercadolibre-listing"
PORT=5000
IMAGE_NAME="mercadolibre-listing:latest"
CONTAINER_NAME="mercadolibre-listing"

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info() { echo -e "${GREEN}[INFO]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 检查是否为 root
if [ "$EUID" -ne 0 ]; then
    error "请使用 root 权限运行此脚本"
    exit 1
fi

echo "=========================================="
echo "  MercardoLibre Listing - 一键部署"
echo "=========================================="

# 1. 安装 Docker
info "[1/6] 检查并安装 Docker..."
if ! command -v docker &> /dev/null; then
    warn "Docker 未安装，正在安装..."
    curl -fsSL https://get.docker.com | sh
    systemctl start docker
    systemctl enable docker
    info "Docker 安装完成"
else
    info "Docker 已安装: $(docker --version)"
fi

# 2. 获取服务器 IP
info "[2/6] 获取服务器信息..."
PUBLIC_IP=$(curl -s ifconfig.me || curl -s api.ipify.org)
if [ -z "$PUBLIC_IP" ]; then
    PUBLIC_IP=$(hostname -I | awk '{print $1}')
fi
info "服务器 IP: $PUBLIC_IP"

# 3. 创建工作目录
info "[3/6] 创建工作目录..."
WORK_DIR="/opt/$APP_NAME"
mkdir -p $WORK_DIR
cd $WORK_DIR

# 4. 检查 Dockerfile 是否存在
if [ ! -f "Dockerfile" ]; then
    error "Dockerfile 不存在，请先上传代码到 $WORK_DIR"
    exit 1
fi

# 5. 构建镜像
info "[4/6] 构建 Docker 镜像..."
docker build -t $IMAGE_NAME .

# 6. 停止并删除旧容器
info "[5/6] 停止旧容器..."
docker stop $CONTAINER_NAME 2>/dev/null || true
docker rm $CONTAINER_NAME 2>/dev/null || true

# 7. 启动新容器
info "[6/6] 启动容器..."
docker run -d \
    --name $CONTAINER_NAME \
    --restart unless-stopped \
    -p $PORT:$PORT \
    -e NODE_ENV=production \
    -e PORT=$PORT \
    -e DEEPSEEK_API_KEY="${DEEPSEEK_API_KEY:-sk-f4fc430e2bc345b8afe2d37aee02dd13}" \
    --log-opt max-size=10m \
    --log-opt max-file=3 \
    $IMAGE_NAME

# 等待服务启动
sleep 5

# 验证
if curl -s http://localhost:$PORT > /dev/null; then
    echo ""
    echo "=========================================="
    echo -e "${GREEN}部署成功！${NC}"
    echo "=========================================="
    echo ""
    echo "应用地址: http://$PUBLIC_IP:$PORT"
    echo "API地址:  http://$PUBLIC_IP:$PORT/api/generate-listing-manual"
    echo ""
    echo "管理命令:"
    echo "  查看日志: docker logs -f $CONTAINER_NAME"
    echo "  重启:    docker restart $CONTAINER_NAME"
    echo "  停止:    docker stop $CONTAINER_NAME"
    echo ""
    echo "安全组设置:"
    echo "  请在火山引擎控制台开放 TCP $PORT 端口"
    echo "=========================================="
else
    error "服务启动失败，请检查日志"
    docker logs $CONTAINER_NAME
    exit 1
fi
