#!/bin/bash

echo "=========================================="
echo "端口5000连接诊断工具"
echo "=========================================="
echo ""

echo "1. 检查服务状态..."
if ss -tlnp | grep -q :5000; then
    echo "✅ 端口5000正在监听"
    ss -tlnp | grep :5000
else
    echo "❌ 端口5000未监听"
fi
echo ""

echo "2. 检查本地访问..."
if curl -s http://127.0.0.1:5000 > /dev/null; then
    echo "✅ 本地访问正常 (127.0.0.1:5000)"
else
    echo "❌ 本地访问失败"
fi
echo ""

echo "3. 检查内网访问..."
if curl -s http://9.96.221.135:5000 > /dev/null; then
    echo "✅ 内网访问正常 (9.96.221.135:5000)"
else
    echo "❌ 内网访问失败"
fi
echo ""

echo "4. 检查防火墙服务..."
echo "firewalld: $(systemctl is-active firewalld 2>/dev/null || echo '未安装')"
echo "ufw: $(systemctl is-active ufw 2>/dev/null || echo '未安装')"
echo ""

echo "5. 网络接口信息..."
ip addr show | grep "inet " | grep -v "127.0.0.1"
echo ""

echo "6. 进程信息..."
ps aux | grep next-server | grep -v grep
echo ""

echo "=========================================="
echo "诊断完成"
echo "=========================================="
echo ""
echo "如果本地和内网访问都正常，但外网无法访问："
echo "- 检查云平台安全组规则"
echo "- 检查容器端口映射（如果是容器环境）"
echo "- 检查网络ACL或VPN设置"
echo ""
echo "可用的访问地址："
echo "- 服务器本地: http://127.0.0.1:5000"
echo "- 内网地址:   http://9.96.221.135:5000"
