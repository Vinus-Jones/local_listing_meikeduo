#!/bin/bash
#===============================================
# 快速部署到阿里云
# https://www.aliyun.com/
#===============================================

set -e

echo "=========================================="
echo "MercardoLibre Listing - 阿里云部署"
echo "=========================================="

# 1. 检查必要工具
echo ""
echo "[1/5] 检查必要工具..."

if ! command -v docker &> /dev/null; then
    echo "安装 Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl start docker
    systemctl enable docker
fi

# 设置 Docker 镜像加速
echo "配置 Docker 镜像加速..."
mkdir -p /etc/docker
cat > /etc/docker/daemon.json << EOF
{
  "registry-mirrors": [
    "https://mirror.ccs.tencentyun.com",
    "https://docker.mirrors.ustc.edu.cn"
  ]
}
EOF

systemctl daemon-reload
systemctl restart docker

echo "✓ Docker 已安装并配置"

# 2. 构建镜像
echo ""
echo "[2/5] 构建 Docker 镜像..."

# 使用阿里云镜像源
export DOCKER_BUILD_OPTS="--build-arg REGISTRY=https://registry.npmmirror.com"

docker build -t mercadolibre-listing:latest .

echo "✓ 镜像构建完成"

# 3. 启动容器
echo ""
echo "[3/5] 启动容器..."

docker stop mercadolibre-listing 2>/dev/null || true
docker rm mercadolibre-listing 2>/dev/null || true

docker run -d \
    --name mercadolibre-listing \
    --restart unless-stopped \
    -p 5000:5000 \
    -e NODE_ENV=production \
    -e PORT=5000 \
    -e DEEPSEEK_API_KEY="sk-f4fc430e2bc345b8afe2d37aee02dd13" \
    mercadolibre-listing:latest

echo "✓ 容器已启动"

# 4. 等待服务启动
echo ""
echo "[4/5] 等待服务启动..."

for i in {1..30}; do
    if curl -s http://localhost:5000 > /dev/null 2>&1; then
        echo "✓ 服务启动成功！"
        break
    fi
    echo "等待启动... ($i/30)"
    sleep 2
done

# 5. 开放端口
echo ""
echo "[5/5] 安全组配置..."
echo "请在阿里云安全组中开放以下端口："
echo "  - 5000 (应用端口)"
echo "  - 80 (HTTP，可选)"
echo "  - 443 (HTTPS，可选)"

# 6. 显示结果
echo ""
echo "=========================================="
echo "部署完成！"
echo ""
echo "访问地址: http://你的服务器IP:5000"
echo "API地址:  http://你的服务器IP:5000/api/generate-listing-manual"
echo ""
echo "管理命令:"
echo "  查看日志: docker logs -f mercadolibre-listing"
echo "  停止服务: docker stop mercadolibre-listing"
echo "  启动服务: docker start mercadolibre-listing"
echo "=========================================="
