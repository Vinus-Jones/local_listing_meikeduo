"""
MercadoLibre Listing Generator - Python SDK

安装: pip install requests

使用示例:

```python
from mercadolibre_sdk import MercadoLibreSDK

sdk = MercadoLibreSDK(
    base_url="https://your-domain.com",
    max_retries=3,
    retry_delay=1.0
)

# 单个生成
result = sdk.generate_listing(
    title="Wireless Bluetooth Headphones",
    features="Noise cancellation, 30h battery",
    language="es"
)

# 批量生成
results = sdk.generate_batch([
    {"productName": "Product 1", "language": "es"},
    {"productName": "Product 2", "language": "pt"},
], concurrency=3)

# 识图生成
result = sdk.generate_from_image(
    image_url="https://example.com/product.jpg",
    language="es"
)
```

完整API文档: https://your-domain.com/docs/api
"""

import json
import time
import requests
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass
from urllib.parse import urljoin


@dataclass
class ListingResult:
    """Listing生成结果"""
    title_es: Optional[str] = None
    title_pt: Optional[str] = None
    description_es: Optional[str] = None
    description_pt: Optional[str] = None
    parameters_es: Optional[List[str]] = None
    parameters_pt: Optional[List[str]] = None
    keywords_es: Optional[List[str]] = None
    keywords_pt: Optional[List[str]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ListingResult':
        return cls(
            title_es=data.get('title_es'),
            title_pt=data.get('title_pt'),
            description_es=data.get('description_es'),
            description_pt=data.get('description_pt'),
            parameters_es=data.get('parameters_es'),
            parameters_pt=data.get('parameters_pt'),
            keywords_es=data.get('keywords_es'),
            keywords_pt=data.get('keywords_pt'),
        )


@dataclass
class BatchItem:
    """批量处理的单个项目"""
    product_name: str
    features: str = ""
    target_country: str = "MX"
    language: str = "es"


@dataclass
class BatchResult:
    """批量处理结果"""
    index: int
    success: bool
    data: Optional[ListingResult] = None
    error: Optional[str] = None


@dataclass
class ProgressEvent:
    """进度事件"""
    total: int
    completed: int
    failed: int
    current: Optional[BatchItem] = None


class MercadoLibreSDK:
    """MercadoLibre Listing生成SDK"""

    def __init__(
        self,
        base_url: str,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        timeout: int = 60,
        headers: Optional[Dict[str, str]] = None
    ):
        """
        初始化SDK

        Args:
            base_url: API基础URL
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
            timeout: 请求超时（秒）
            headers: 自定义请求头
        """
        self.base_url = base_url.rstrip('/')
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.timeout = timeout
        self.headers = {
            'Content-Type': 'application/json',
            **(headers or {})
        }
        self._progress_callbacks: List[Callable[[ProgressEvent], None]] = []

    def on_progress(self, callback: Callable[[ProgressEvent], None]) -> None:
        """注册进度回调"""
        self._progress_callbacks.append(callback)

    def _emit_progress(self, event: ProgressEvent) -> None:
        """触发进度事件"""
        for callback in self._progress_callbacks:
            callback(event)

    def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        发送HTTP请求（带重试）

        Args:
            method: HTTP方法
            endpoint: API端点
            data: 请求数据

        Returns:
            响应数据

        Raises:
            requests.RequestException: 请求失败
        """
        url = urljoin(self.base_url, endpoint)
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                response = requests.request(
                    method=method,
                    url=url,
                    json=data,
                    headers=self.headers,
                    timeout=self.timeout
                )

                # 检查HTTP错误
                response.raise_for_status()

                result = response.json()

                # 检查业务错误
                if not result.get('success', True) and result.get('error'):
                    raise Exception(result['error'])

                return result.get('data', result)

            except requests.exceptions.Timeout:
                last_error = Exception('请求超时')
            except requests.exceptions.RequestException as e:
                last_error = e
            except Exception as e:
                last_error = e

            # 重试
            if attempt < self.max_retries:
                delay = self.retry_delay * (attempt + 1)
                print(f"请求失败 ({last_error})，{delay}s后重试... ({attempt + 1}/{self.max_retries})")
                time.sleep(delay)

        raise last_error or Exception('请求失败')

    def generate_listing(
        self,
        title: Optional[str] = None,
        description: Optional[str] = None,
        features: Optional[str] = None
    ) -> ListingResult:
        """
        生成单个Listing

        Args:
            title: 产品标题（英文）
            description: 产品描述（英文）
            features: 产品特性

        Returns:
            ListingResult: 生成结果
        """
        data = {}
        if title:
            data['title'] = title
        if description:
            data['description'] = description

        result = self._request('POST', '/api/generate-listing-manual', data)

        # 合并features到description
        if features and not description:
            # 如果只提供了features，构建一个简单的description
            pass

        return ListingResult.from_dict(result)

    def generate_batch(
        self,
        products: List[Dict[str, Any]],
        concurrency: int = 3
    ) -> List[BatchResult]:
        """
        批量生成Listing

        Args:
            products: 产品列表
            concurrency: 最大并发数

        Returns:
            List[BatchResult]: 批量结果
        """
        # 转换产品格式
        formatted_products = []
        for i, p in enumerate(products):
            if isinstance(p, dict):
                formatted_products.append({
                    'productName': p.get('productName', p.get('product_name', '')),
                    'features': p.get('features', ''),
                    'targetCountry': p.get('targetCountry', p.get('target_country', 'MX')),
                    'language': p.get('language', 'es'),
                })
            elif isinstance(p, BatchItem):
                formatted_products.append({
                    'productName': p.product_name,
                    'features': p.features,
                    'targetCountry': p.target_country,
                    'language': p.language,
                })

        result = self._request('POST', '/api/generate-listing-batch', {
            'products': formatted_products,
            'maxConcurrency': concurrency
        })

        # 解析结果
        batch_results = []
        for item in result.get('results', []):
            batch_result = BatchResult(
                index=item['index'],
                success=item['success'],
                error=item.get('error')
            )
            if item.get('success') and item.get('data'):
                batch_result.data = ListingResult.from_dict(item['data'])
            batch_results.append(batch_result)

        # 触发完成事件
        self._emit_progress(ProgressEvent(
            total=result.get('total', len(products)),
            completed=result.get('success', 0),
            failed=result.get('failed', 0)
        ))

        return batch_results

    def generate_from_image(
        self,
        image_url: str,
        language: str = 'es',
        enhance: bool = False
    ) -> ListingResult:
        """
        识图生成Listing

        Args:
            image_url: 图片URL
            language: 语言 (es/pt)
            enhance: 是否增强

        Returns:
            ListingResult: 生成结果
        """
        result = self._request('POST', '/api/generate-listing-image', {
            'imageUrl': image_url,
            'language': language,
            'enhance': enhance
        })
        return ListingResult.from_dict(result)

    def enhance_description(
        self,
        original_description: str,
        image_url: str,
        language: str = 'es'
    ) -> str:
        """
        图片识别优化描述

        Args:
            original_description: 原始描述
            image_url: 参考图片URL
            language: 语言

        Returns:
            str: 优化后的描述
        """
        result = self._request('POST', '/api/image-description-enhance', {
            'originalDescription': original_description,
            'imageUrl': image_url,
            'language': language
        })
        return result.get('enhancedDescription', '')

    def health_check(self) -> bool:
        """
        健康检查

        Returns:
            bool: 服务是否正常
        """
        try:
            self._request('GET', '/api/health')
            return True
        except Exception:
            return False


# 便捷函数
def create_sdk(base_url: str, **kwargs) -> MercadoLibreSDK:
    """创建SDK实例"""
    return MercadoLibreSDK(base_url=base_url, **kwargs)


# 批量处理辅助函数
def process_large_batch(
    sdk: MercadoLibreSDK,
    products: List[Dict[str, Any]],
    batch_size: int = 10,
    concurrency: int = 3,
    progress_callback: Optional[Callable[[ProgressEvent], None]] = None
) -> List[BatchResult]:
    """
    处理大量产品的批量生成（自动分批）

    Args:
        sdk: SDK实例
        products: 产品列表
        batch_size: 每批大小
        concurrency: 并发数
        progress_callback: 进度回调

    Returns:
        List[BatchResult]: 所有结果
    """
    all_results = []
    total = len(products)

    for i in range(0, total, batch_size):
        batch = products[i:i + batch_size]
        print(f"处理批次 {i // batch_size + 1}/{(total + batch_size - 1) // batch_size}")

        if progress_callback:
            sdk.on_progress(progress_callback)

        results = sdk.generate_batch(batch, concurrency=concurrency)
        all_results.extend(results)

    return all_results


if __name__ == '__main__':
    # 示例使用
    import os

    API_URL = os.environ.get('MERCADO_LIBRE_API_URL', 'http://localhost:5000')
    sdk = MercadoLibreSDK(base_url=API_URL, max_retries=3)

    # 健康检查
    if sdk.health_check():
        print("✓ 服务正常")
    else:
        print("✗ 服务异常")

    # 单个生成示例
    try:
        result = sdk.generate_listing(
            title="Wireless Bluetooth Headphones",
            features="Noise cancellation, 30 hours battery life",
            description="Premium headphones with active noise cancellation"
        )
        print(f"生成成功: {result.title_es}")
    except Exception as e:
        print(f"生成失败: {e}")
