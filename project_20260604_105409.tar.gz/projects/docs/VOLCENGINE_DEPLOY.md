# MercardoLibre Listing Generator - 火山引擎部署指南

## 概述

本文档说明如何将应用部署到火山引擎（ByteDance Cloud），实现完全远程调用。

---

## 方案对比

| 方案 | 难度 | 成本 | 适用场景 |
|------|------|------|----------|
| **云服务器 ECS** | ⭐ 简单 | 按量付费 | 个人/小团队 |
| **容器服务 VKE** | ⭐⭐ 中等 | 按量付费 | 企业级应用 |
| **Web应用托管** | ⭐ 简单 | 按量付费 | Web 应用 |

**推荐：云服务器 ECS（最简单、最便宜）**

---

## 方案一：云服务器 ECS（推荐）

### 步骤 1：创建 ECS 实例

1. 登录 [火山引擎控制台](https://console.volcengine.com/)
2. 进入 **云服务器 ECS**
3. 点击 **创建实例**
4. 配置：
   - **地域**：华北（北京）或华东（上海）- 离用户近
   - **实例规格**：入门型（1核2G）足够
   - **操作系统**：Ubuntu 22.04 LTS 或 CentOS 8
   - **带宽**：5Mbps 按量付费
   - **存储**：40GB SSD

### 步骤 2：安装 Docker

```bash
# 连接服务器后执行
curl -fsSL https://get.docker.com | sh
systemctl start docker
systemctl enable docker
```

### 步骤 3：上传代码

**方式 A：使用 Git（推荐）**
```bash
# 在服务器上安装 Git
apt update && apt install -y git

# 克隆代码
git clone https://你的代码仓库地址.git
cd mercadolibre-listing
```

**方式 B：使用 SCP 上传**
```bash
# 从本地上传
scp -r ./mercadolibre-listing user@服务器IP:/home/user/
```

### 步骤 4：构建并启动

```bash
# 构建生产镜像
docker build -t mercadolibre-listing .

# 运行容器
docker run -d \
  --name mercadolibre-listing \
  --restart unless-stopped \
  -p 5000:5000 \
  -e NODE_ENV=production \
  -e PORT=5000 \
  -e DEEPSEEK_API_KEY="sk-f4fc430e2bc345b8afe2d37aee02dd13" \
  mercadolibre-listing:latest
```

### 步骤 5：配置安全组

在火山引擎控制台的安全组中，开放端口：
- **5000** - 应用端口（必须）
- **80** - HTTP（可选）
- **443** - HTTPS（可选）

### 步骤 6：配置域名（可选）

1. 购买域名
2. 在 DNS 解析中添加 A 记录指向服务器 IP
3. 配置 Nginx 反向代理和 SSL 证书

---

## 方案二：打包现有代码部署

### 步骤 1：打包代码

当前代码已在 `/workspace/projects`，可以直接使用：

```bash
# 进入项目目录
cd /workspace/projects

# 查看关键文件
ls -la Dockerfile docker-compose.yml deploy-volc.sh
```

### 步骤 2：传输文件到 ECS

```bash
# 在本地执行（如果有本地代码）
scp -r ./mercadolibre-listing user@你的ECS_IP:/home/user/
```

### 步骤 3：在 ECS 上构建

```bash
# SSH 连接到服务器
ssh user@你的ECS_IP

# 进入项目目录
cd mercadolibre-listing

# 构建并启动
docker build -t mercadolibre-listing .
docker run -d --name mercadolibre -p 5000:5000 mercadolibre-listing
```

---

## 远程调用 API

部署完成后，通过以下地址调用：

### 基础地址
```
http://你的服务器IP:5000
```

### API 端点

| 功能 | 方法 | URL |
|------|------|-----|
| 手动生成 Listing | POST | `http://你的服务器IP:5000/api/generate-listing-manual` |
| 批量生成 Listing | POST | `http://你的服务器IP:5000/api/generate-listing-batch` |

### 调用示例

**cURL:**
```bash
curl -X POST http://你的服务器IP:5000/api/generate-listing-manual \
  -H "Content-Type: application/json" \
  -d '{"title": "Wireless Bluetooth Headphones"}'
```

**Python:**
```python
import requests

url = "http://你的服务器IP:5000/api/generate-listing-manual"
data = {"title": "Wireless Bluetooth Headphones"}

response = requests.post(url, json=data)
print(response.json())
```

**JavaScript:**
```javascript
const response = await fetch('http://你的服务器IP:5000/api/generate-listing-manual', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ title: 'Wireless Bluetooth Headphones' })
});
const data = await response.json();
console.log(data);
```

---

## HTTPS 配置（可选但推荐）

### 使用 Let's Encrypt 免费证书

```bash
# 安装 Certbot
apt install -y certbot python3-certbot-nginx

# 获取证书（需要域名）
certbot --nginx -d your-domain.com
```

### Nginx 反向代理配置

参考项目中的 `nginx.conf` 文件。

---

## 监控与维护

### 查看日志
```bash
docker logs -f mercadolibre-listing
```

### 重启服务
```bash
docker restart mercadolibre-listing
```

### 更新应用
```bash
cd /path/to/mercadolibre-listing
git pull
docker build -t mercadolibre-listing .
docker stop mercadolibre-listing
docker rm mercadolibre-listing
docker run -d --name mercadolibre -p 5000:5000 mercadolibre-listing:latest
```

---

## 成本估算

| 资源 | 配置 | 月费用（约） |
|------|------|-------------|
| ECS 云服务器 | 1核2G | ¥30-50 |
| 流量 | 100GB | ¥20 |
| **总计** | - | **¥50-70/月** |

---

## 故障排除

### 服务无法启动
```bash
# 查看日志
docker logs mercadolibre-listing

# 检查端口占用
netstat -tlnp | grep 5000
```

### API 调用超时
```bash
# 检查防火墙
ufw status
# 或
iptables -L
```

### 内存不足
```bash
# 检查内存
free -h
# 关闭不需要的服务
systemctl stop 服务名
```

---

## 下一步

1. 在火山引擎创建 ECS 实例
2. 安装 Docker
3. 上传代码或使用 Git 克隆
4. 构建并运行
5. 配置安全组开放端口
6. 开始使用！

如需帮助，请提供火山引擎账号信息或 ECS 连接详情。
