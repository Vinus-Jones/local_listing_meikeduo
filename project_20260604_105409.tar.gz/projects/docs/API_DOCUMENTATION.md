# 美客多Listing生成器 API 文档

## 概述

美客多Listing生成器API提供完整的电商产品Listing生成服务，支持将英文产品信息转换为拉美西班牙语和巴西葡萄牙语的Listing内容。

**基础URL：** `https://{domain}/api`

---

## 认证

当前API无需认证，直接调用即可。

---

## 主要API端点

### 1. 手动生成Listing（推荐）

将产品信息转换为美客多适用的Listing。

**端点：** `POST /api/generate-listing-manual`

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | string | 否 | 产品英文标题 |
| description | string | 否 | 产品英文描述 |

> 至少需要提供 title 或 description 之一

**请求示例：**

```bash
curl -X POST https://your-domain.com/api/generate-listing-manual \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Portable Bluetooth Speaker Waterproof IPX7",
    "description": "Compact wireless speaker with 360-degree sound, 12-hour battery life, USB-C charging, built-in microphone for calls, suitable for outdoor beach pool party"
  }'
```

**响应示例：**

```json
{
  "title_es": "Altavoz Bluetooth Portátil Impermeable IPX7 Sonido 360°",
  "title_pt": "Alto-falante Bluetooth Portátil Impermeável IPX7 Som 360°",
  "description_es": "Altavoz Bluetooth compacto y portátil con sonido envolvente de 360 grados. Ideal para llevar a cualquier lugar.\n\nOfrece hasta 12 horas de reproducción continua con una sola carga. Resistente al agua con certificación IPX7, perfecto para usar en la playa, piscina o bajo la lluvia. Incluye micrófono integrado para atender llamadas manos libres.\n\nSu diseño compacto lo hace fácil de transportar. Se carga rápidamente a través del puerto USB-C incluido. El sonido potente y claro mejora cualquier ambiente.\n\n• Batería: Hasta 12 horas de uso\n• Carga: Puerto USB-C\n• Resistencia al agua: IPX7\n• Conectividad: Bluetooth\n• Micrófono: Integrado para llamadas\n\nEl paquete incluye: altavoz principal y cable de carga USB-C.\n\nPara un mejor rendimiento, cargue completamente el dispositivo antes del primer uso. Evite la exposición prolongada a temperaturas extremas.",
  "description_pt": "Alto-falante Bluetooth compacto e portátil com som envolvente de 360 graus. Perfeito para levar a qualquer lugar.\n\nOferece até 12 horas de reprodução contínua com uma única carga. Resistente à água com certificação IPX7, ideal para usar na praia, piscina ou sob chuva. Inclui microfone integrado para atender chamadas em viva-voz.\n\nSeu design compacto facilita o transporte. Carrega rapidamente através da porta USB-C incluída. O som potente e claro melhora qualquer ambiente.\n\n• Bateria: Até 12 horas de uso\n• Carregamento: Porta USB-C\n• Resistência à água: IPX7\n• Conectividade: Bluetooth\n• Microfone: Integrado para chamadas\n\nO pacote inclui: alto-falante principal e cabo de carregamento USB-C.\n\nPara um melhor desempenho, carregue completamente o dispositivo antes do primeiro uso. Evite exposição prolongada a temperaturas extremas.",
  "parameters_es": [
    "• Resistencia al agua: IPX7",
    "• Autonomía de batería: Hasta 12 horas",
    "• Tipo de carga: USB-C",
    "• Sonido: 360 grados",
    "• Función: Micrófono integrado",
    "• Conectividad: Bluetooth",
    "• Uso: Portátil"
  ],
  "parameters_pt": [
    "• Resistência à água: IPX7",
    "• Autonomia da bateria: Até 12 horas",
    "• Tipo de carregamento: USB-C",
    "• Som: 360 graus",
    "• Função: Microfone integrado",
    "• Conectividade: Bluetooth",
    "• Uso: Portátil"
  ],
  "keywords_es": [
    "altavoz",
    "altavoz bluetooth",
    "inalámbrico",
    "portátil",
    "impermeable",
    "ipx7",
    "resistente al agua",
    "sonido 360",
    "batería larga duración",
    "usb-c",
    "con micrófono",
    "para playa",
    "para piscina",
    "para fiesta",
    "para exteriores"
  ],
  "keywords_pt": [
    "alto-falante",
    "alto-falante bluetooth",
    "sem fio",
    "portátil",
    "impermeável",
    "ipx7",
    "resistente à água",
    "som 360",
    "bateria longa duração",
    "usb-c",
    "com microfone",
    "para praia",
    "para piscina",
    "para festa",
    "para exteriores"
  ],
  "keywords_layered_es": {
    "core": ["altavoz", "altavoz bluetooth", "inalámbrico", "bluetooth"],
    "attribute": ["portátil", "impermeable", "ipx7", "resistente al agua", "sonido 360"],
    "scene": ["batería larga duración", "usb-c", "con micrófono", "para playa"],
    "longtail": ["para piscina", "para fiesta", "para exteriores"]
  },
  "keywords_layered_pt": {
    "core": ["alto-falante", "alto-falante bluetooth", "sem fio", "bluetooth"],
    "attribute": ["portátil", "impermeável", "ipx7", "resistente à água", "som 360"],
    "scene": ["bateria longa duração", "usb-c", "com microfone", "para praia"],
    "longtail": ["para piscina", "para festa", "para exteriores"]
  },
  "quality": {
    "score": {
      "title_es": {
        "overall": 78,
        "dimensions": {
          "keywordCoverage": 25,
          "charUtilization": 20,
          "grammar": 15,
          "localization": 10,
          "conversion": 8
        }
      },
      "title_pt": {
        "overall": 78,
        "dimensions": {
          "keywordCoverage": 25,
          "charUtilization": 20,
          "grammar": 15,
          "localization": 10,
          "conversion": 8
        }
      },
      "description_es": {
        "overall": 90,
        "dimensions": {
          "keywordCoverage": 28,
          "charUtilization": 20,
          "grammar": 15,
          "localization": 12,
          "conversion": 15
        }
      },
      "description_pt": {
        "overall": 90,
        "dimensions": {
          "keywordCoverage": 28,
          "charUtilization": 20,
          "grammar": 15,
          "localization": 12,
          "conversion": 15
        }
      }
    },
    "forbiddenWords": {
      "title_es": [],
      "title_pt": [],
      "description_es": [],
      "description_pt": []
    }
  }
}
```

---

### 2. 图片识别生成Listing

通过产品图片识别并生成Listing。

**端点：** `POST /api/generate-listing-from-image`

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| image | string | 是 | 图片URL（Base64或公开URL） |

**请求示例：**

```bash
curl -X POST https://your-domain.com/api/generate-listing-from-image \
  -H "Content-Type: application/json" \
  -d '{
    "image": "https://example.com/product-image.jpg"
  }'
```

**响应示例：**

```json
{
  "title_es": "Altavoz Bluetooth Portátil Impermeable IPX7",
  "title_pt": "Alto-falante Bluetooth Portátil Impermeável IPX7",
  "description_es": "...",
  "description_pt": "...",
  "parameters_es": [...],
  "parameters_pt": [...],
  "keywords_es": [...],
  "keywords_pt": [...],
  "quality": {...}
}
```

---

### 3. 图片生成产品描述

通过产品图片生成产品描述。

**端点：** `POST /api/generate-description-from-image`

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| image | string | 是 | 图片URL |
| targetLanguage | string | 是 | 目标语言：`es`（西班牙语）或 `pt`（葡萄牙语） |

**请求示例：**

```bash
curl -X POST https://your-domain.com/api/generate-description-from-image \
  -H "Content-Type: application/json" \
  -d '{
    "image": "https://example.com/product-image.jpg",
    "targetLanguage": "es"
  }'
```

**响应示例：**

```json
{
  "success": true,
  "imageAnalysis": "产品图片识别结果...",
  "generatedDescription": "生成的产品描述..."
}
```

---

### 4. Listing精细化调整

对现有Listing进行精细化调整。

**端点：** `POST /api/refine-listing`

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| content | string | 是 | 要优化的Listing内容 |
| language | string | 是 | 语言：`es` 或 `pt` |
| refinementType | string | 否 | 优化类型：`title`（标题）、`description`（描述）、`keywords`（关键词） |

**请求示例：**

```bash
curl -X POST https://your-domain.com/api/refine-listing \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Altavoz Bluetooth Portátil",
    "language": "es",
    "refinementType": "title"
  }'
```

---

### 5. 图片优化分析

基于产品图片优化现有描述。

**端点：** `POST /api/analyze-image-optimization`

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| image | string | 是 | 产品图片URL |
| currentDescription | string | 是 | 当前的产品描述 |
| targetLanguage | string | 是 | 目标语言：`es` 或 `pt` |

**请求示例：**

```bash
curl -X POST https://your-domain.com/api/analyze-image-optimization \
  -H "Content-Type: application/json" \
  -d '{
    "image": "https://example.com/product-image.jpg",
    "currentDescription": "当前的产品描述...",
    "targetLanguage": "es"
  }'
```

---

### 6. 图片翻译

翻译图片中的文字。

**端点：** `POST /api/translate-image`

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| image | string | 是 | 图片URL（Base64或公开URL） |
| targetLanguage | string | 是 | 目标语言 |

**请求示例：**

```bash
curl -X POST https://your-domain.com/api/translate-image \
  -H "Content-Type: application/json" \
  -d '{
    "image": "https://example.com/product-image.jpg",
    "targetLanguage": "es"
  }'
```

---

### 7. 自动翻译图片

自动识别图片内容并翻译。

**端点：** `POST /api/translate-image-auto`

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| image | string | 是 | 图片URL |
| targetLanguages | array | 是 | 目标语言数组：`["es", "pt"]` |

---

## 响应字段说明

### 标题字段

| 字段 | 类型 | 说明 |
|------|------|------|
| title_es | string | 西班牙语标题（30-60字符） |
| title_pt | string | 葡萄牙语标题（30-60字符） |

### 描述字段

| 字段 | 类型 | 说明 |
|------|------|------|
| description_es | string | 西班牙语产品描述 |
| description_pt | string | 葡萄牙语产品描述 |

描述内容包含以下部分：
- **属性介绍**：主要技术参数（如IPX7防水、蓝牙5.0）
- **用途说明**：产品用途和使用场景
- **特征描述**：产品特点
- **参数信息**：技术规格
- **包装清单**：包装内含物品
- **使用说明**：使用注意事项

### 参数字段

| 字段 | 类型 | 说明 |
|------|------|------|
| parameters_es | array | 西班牙语参数列表 |
| parameters_pt | array | 葡萄牙语参数列表 |

### 关键词字段

| 字段 | 类型 | 说明 |
|------|------|------|
| keywords_es | array | 西班牙语关键词（15-20个） |
| keywords_pt | array | 葡萄牙语关键词（15-20个） |
| keywords_layered_es | object | 分层关键词（核心词、属性词、场景词、长尾词） |
| keywords_layered_pt | object | 分层关键词 |

### 质量评分字段

| 字段 | 类型 | 说明 |
|------|------|------|
| quality.score | object | 各字段质量评分 |
| quality.forbiddenWords | object | 检测到的禁用词 |
| quality.suggestions | object | 优化建议 |

**评分维度：**

| 维度 | 权重 | 说明 |
|------|------|------|
| keywordCoverage | 30% | 关键词覆盖度 |
| charUtilization | 20% | 字符利用率 |
| grammar | 20% | 语法正确性 |
| localization | 15% | 本地化程度 |
| conversion | 15% | 转化元素 |

---

## 错误响应

**HTTP 400 - 请求参数错误**

```json
{
  "error": "错误信息描述"
}
```

**HTTP 500 - 服务器错误**

```json
{
  "error": "生成失败，请重试"
}
```

---

## SDK示例

### Python SDK

```python
import requests
import json

class MercadolibreListingGenerator:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip('/')
    
    def generate_listing(self, title: str = None, description: str = None):
        """
        生成美客多Listing
        
        Args:
            title: 产品英文标题
            description: 产品英文描述
            
        Returns:
            dict: 生成的Listing数据
        """
        payload = {}
        if title:
            payload["title"] = title
        if description:
            payload["description"] = description
        
        response = requests.post(
            f"{self.base_url}/api/generate-listing-manual",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"API调用失败: {response.text}")
    
    def generate_from_image(self, image_url: str):
        """
        通过图片生成Listing
        
        Args:
            image_url: 产品图片URL
            
        Returns:
            dict: 生成的Listing数据
        """
        response = requests.post(
            f"{self.base_url}/api/generate-listing-from-image",
            json={"image": image_url},
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"API调用失败: {response.text}")

# 使用示例
api = MercadolibreListingGenerator("https://your-domain.com")

# 手动生成Listing
result = api.generate_listing(
    title="Portable Bluetooth Speaker Waterproof IPX7",
    description="Compact wireless speaker with 360-degree sound, 12-hour battery"
)

print(f"西班牙语标题: {result['title_es']}")
print(f"葡萄牙语标题: {result['title_pt']}")
print(f"西班牙语关键词: {result['keywords_es']}")
```

### JavaScript/TypeScript SDK

```typescript
interface ListingRequest {
  title?: string;
  description?: string;
}

interface ListingResponse {
  title_es: string;
  title_pt: string;
  description_es: string;
  description_pt: string;
  parameters_es: string[];
  parameters_pt: string[];
  keywords_es: string[];
  keywords_pt: string[];
  keywords_layered_es: {
    core: string[];
    attribute: string[];
    scene: string[];
    longtail: string[];
  };
  quality: {
    score: {
      title_es: { overall: number };
      title_pt: { overall: number };
      description_es: { overall: number };
      description_pt: { overall: number };
    };
    forbiddenWords: Record<string, string[]>;
  };
}

class MercadolibreListingGenerator {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
  }

  async generateListing(request: ListingRequest): Promise<ListingResponse> {
    const response = await fetch(`${this.baseUrl}/api/generate-listing-manual`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      throw new Error(`API调用失败: ${response.statusText}`);
    }

    return response.json();
  }

  async generateFromImage(imageUrl: string): Promise<ListingResponse> {
    const response = await fetch(`${this.baseUrl}/api/generate-listing-from-image`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ image: imageUrl }),
    });

    if (!response.ok) {
      throw new Error(`API调用失败: ${response.statusText}`);
    }

    return response.json();
  }
}

// 使用示例
const api = new MercadolibreListingGenerator('https://your-domain.com');

async function main() {
  const result = await api.generateListing({
    title: 'Portable Bluetooth Speaker Waterproof IPX7',
    description: 'Compact wireless speaker with 360-degree sound, 12-hour battery'
  });

  console.log('西班牙语标题:', result.title_es);
  console.log('葡萄牙语标题:', result.title_pt);
  console.log('西班牙语关键词:', result.keywords_es);
  console.log('质量评分:', result.quality.score);
}

main();
```

### Node.js 示例

```javascript
const axios = require('axios');

class MercadolibreListingGenerator {
  constructor(baseUrl) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
  }

  async generateListing({ title, description }) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/api/generate-listing-manual`,
        { title, description },
        {
          headers: { 'Content-Type': 'application/json' }
        }
      );
      return response.data;
    } catch (error) {
      console.error('API调用失败:', error.message);
      throw error;
    }
  }

  async generateFromImage(imageUrl) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/api/generate-listing-from-image`,
        { image: imageUrl },
        {
          headers: { 'Content-Type': 'application/json' }
        }
      );
      return response.data;
    } catch (error) {
      console.error('API调用失败:', error.message);
      throw error;
    }
  }
}

// 使用示例
const api = new MercadolibreListingGenerator('https://your-domain.com');

async function main() {
  const result = await api.generateListing({
    title: 'Portable Bluetooth Speaker',
    description: 'Waterproof IPX7, 12-hour battery, USB-C'
  });

  console.log(result.title_es);
  console.log(result.keywords_es);
}

main();
```

---

## 最佳实践

### 1. 标题优化建议

- 提供详细的产品标题以获得更准确的翻译
- 标题长度建议在20-100字符之间
- 包含核心关键词（产品类型+主要功能）

### 2. 描述优化建议

- 提供完整的产品描述以获得更丰富的内容
- 描述应包含：功能特点、技术参数、使用场景、包装清单
- 描述长度建议在100-500字符之间

### 3. 关键词策略

- 使用分层关键词覆盖不同搜索意图
- 核心词：产品类型
- 属性词：功能特性
- 场景词：使用场景
- 长尾词：精准需求

### 4. 错误处理

```python
import time

def retry_on_failure(func, max_retries=3, delay=1):
    """失败重试装饰器"""
    for i in range(max_retries):
        try:
            return func()
        except Exception as e:
            if i == max_retries - 1:
                raise e
            print(f"请求失败，{delay}秒后重试... ({i+1}/{max_retries})")
            time.sleep(delay)
```

---

## 速率限制

当前API无速率限制，但建议：

- 单个请求间隔 ≥ 1秒
- 批量处理时添加适当延迟
- 错误时实现重试机制

---

## 技术支持

如有问题，请检查：

1. 请求参数格式是否正确
2. 网络连接是否正常
3. 服务是否正常运行

---

## 更新日志

### v2.0.0 (2025-01)
- 标题长度约束调整为30-60字符
- 描述内容包含属性、用途、特征、参数、包装、使用说明
- 新增关键词分层体系
- 新增质量评分系统

### v1.0.0 (2024-12)
- 初始版本
- 支持手动输入和图片识别生成Listing
- 支持西班牙语和葡萄牙语
