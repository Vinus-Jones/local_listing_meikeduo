# 美客多Listing生成器 - 效率优化指南

## 一、API访问地址

### 公网访问
- **应用地址**: `https://${COZE_PROJECT_DOMAIN_DEFAULT}`
- **API基础路径**: `https://${COZE_PROJECT_DOMAIN_DEFAULT}/api`

### 可用端点
| 端点 | 方法 | 用途 | 并发建议 |
|------|------|------|----------|
| `/api/generate-listing-manual` | POST | 单个生成（标题+描述） | 1 |
| `/api/generate-listing-batch` | POST | 批量生成（最多10个） | 1 |
| `/api/generate-listing` | POST | 单个生成（产品名+特性） | 1 |
| `/api/generate-listing-image` | POST | 识图生成 | 1 |
| `/api/generate-listing-image-batch` | POST | 批量识图（最多5张） | 1 |
| `/api/image-description-enhance` | POST | 图片描述增强 | 1 |

---

## 二、提高调用效率

### 1. 批量处理（推荐）

**单次批量最多10个产品**，可以显著减少HTTP请求开销：

```python
# Python SDK
sdk = MercadoLibreSDK(base_url="https://your-domain.com")
results = sdk.generate_batch([
    {"productName": "Product 1", "features": "...", "language": "es"},
    {"productName": "Product 2", "features": "...", "language": "pt"},
    # ... 最多10个
], concurrency=3)
```

```typescript
// TypeScript SDK
const sdk = new MercadoLibreSDK({ baseUrl: "https://your-domain.com" });
const results = await sdk.generateBatch([
  { productName: "Product 1", language: "es" },
  { productName: "Product 2", language: "pt" },
], { concurrency: 3 });
```

### 2. 合理设置并发数

| 场景 | 推荐并发数 | 说明 |
|------|----------|------|
| 单次请求 | 1 | 避免阻塞 |
| 批量生成 | 3-5 | 平衡速度和成功率 |
| 批量识图 | 2 | 图片处理较耗时 |

### 3. 使用异步处理

对于大量产品，建议使用异步队列处理：

```python
import asyncio
from concurrent.futures import ThreadPoolExecutor

async def async_generate_batch(sdk, products):
    loop = asyncio.get_event_loop()
    
    # 分批处理，每批5个
    batch_size = 5
    all_results = []
    
    with ThreadPoolExecutor(max_workers=3) as executor:
        for i in range(0, len(products), batch_size):
            batch = products[i:i + batch_size]
            
            # 异步提交批次
            futures = [
                loop.run_in_executor(executor, sdk.generate_listing, **p)
                for p in batch
            ]
            
            batch_results = await asyncio.gather(*futures, return_exceptions=True)
            all_results.extend(batch_results)
            
            # 批次间延迟
            if i + batch_size < len(products):
                await asyncio.sleep(0.5)
    
    return all_results
```

### 4. 缓存策略

对于相似产品，可以实现本地缓存：

```typescript
class CachedListingSDK extends MercadoLibreSDK {
  private cache = new Map<string, ListingResult>();
  
  async generateListing(params: GenerateListingParams): Promise<ListingResult> {
    // 生成缓存key
    const cacheKey = this.generateKey(params);
    
    // 检查缓存
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey)!;
    }
    
    // 调用API
    const result = await super.generateListing(params);
    
    // 存入缓存（30分钟过期）
    this.cache.set(cacheKey, result);
    setTimeout(() => this.cache.delete(cacheKey), 30 * 60 * 1000);
    
    return result;
  }
  
  private generateKey(params: GenerateListingParams): string {
    return JSON.stringify({
      title: params.title?.substring(0, 50),
      features: params.features?.substring(0, 100)
    });
  }
}
```

---

## 三、提高成功率

### 1. 重试机制（已内置）

SDK已内置自动重试机制：
- **最大重试**: 3次
- **重试延迟**: 递增（1s, 2s, 3s）
- **重试条件**: 网络错误、5xx服务器错误

### 2. 手动重试策略

对于关键任务，建议添加业务层重试：

```python
def generate_with_retry(sdk, params, max_attempts=5):
    """带业务层重试的生成"""
    for attempt in range(max_attempts):
        try:
            result = sdk.generate_listing(**params)
            
            # 验证结果完整性
            if result.title_es and result.description_es:
                return result
            
            # 如果结果不完整，尝试修复
            if attempt < max_attempts - 1:
                print(f"结果不完整，重试... ({attempt + 1}/{max_attempts})")
                time.sleep(2)
                continue
            
        except Exception as e:
            if attempt < max_attempts - 1:
                print(f"生成失败: {e}，重试...")
                time.sleep(3)
            else:
                raise
    
    return None
```

### 3. 输入质量优化

高质量输入 → 高质量输出：

```python
def preprocess_input(title: str, features: str) -> dict:
    """预处理输入"""
    # 清理输入
    cleaned_title = title.strip()
    cleaned_features = features.strip()
    
    # 补充信息
    if len(cleaned_title) < 10:
        cleaned_title = cleaned_title + " " + cleaned_features[:50]
    
    # 格式化特性
    features_list = [
        f.strip() for f in cleaned_features.split(',')
        if f.strip()
    ]
    
    return {
        "title": cleaned_title,
        "features": ", ".join(features_list[:10])  # 最多10个特性
    }
```

### 4. 错误处理

```python
from enum import Enum

class ErrorType(Enum):
    NETWORK_ERROR = "网络错误"
    SERVER_ERROR = "服务器错误"
    INVALID_INPUT = "输入无效"
    INCOMPLETE_RESULT = "结果不完整"
    TIMEOUT = "请求超时"

def handle_error(error: Exception, context: str) -> ErrorType:
    """分类处理错误"""
    error_msg = str(error).lower()
    
    if "timeout" in error_msg:
        return ErrorType.TIMEOUT
    elif "connection" in error_msg or "network" in error_msg:
        return ErrorType.NETWORK_ERROR
    elif "400" in error_msg or "invalid" in error_msg:
        return ErrorType.INVALID_INPUT
    elif "500" in error_msg or "server" in error_msg:
        return ErrorType.SERVER_ERROR
    else:
        return ErrorType.INCOMPLETE_RESULT

# 使用示例
try:
    result = sdk.generate_listing(title="...", features="...")
except Exception as e:
    error_type = handle_error(e, "generate_listing")
    
    if error_type == ErrorType.INVALID_INPUT:
        # 修复输入后重试
        pass
    elif error_type == ErrorType.SERVER_ERROR:
        # 服务器问题，等待后重试
        time.sleep(10)
    else:
        # 其他错误，记录并告警
        alert(f"Error: {error_type.value} - {e}")
```

### 5. 熔断器模式

防止连续失败导致系统过载：

```python
from datetime import datetime, timedelta

class CircuitBreaker:
    def __init__(self, failure_threshold=5, timeout=60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failures = 0
        self.last_failure_time = None
        self.state = "closed"  # closed, open, half_open
    
    def call(self, func, *args, **kwargs):
        if self.state == "open":
            if self.last_failure_time + self.timeout < datetime.now():
                self.state = "half_open"
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = func(*args, **kwargs)
            
            if self.state == "half_open":
                self.state = "closed"
                self.failures = 0
            
            return result
            
        except Exception as e:
            self.failures += 1
            self.last_failure_time = datetime.now()
            
            if self.failures >= self.failure_threshold:
                self.state = "open"
            
            raise e

# 使用熔断器
breaker = CircuitBreaker(failure_threshold=5, timeout=60)

def safe_generate(sdk, params):
    return breaker.call(sdk.generate_listing, **params)
```

---

## 四、性能监控

### 1. 请求日志

```python
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mercadolibre")

def logged_generate(sdk, params):
    start_time = datetime.now()
    logger.info(f"开始生成: {params.get('title', '')[:50]}")
    
    try:
        result = sdk.generate_listing(**params)
        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"生成成功，耗时: {duration:.2f}s")
        return result
    except Exception as e:
        duration = (datetime.now() - start_time).total_seconds()
        logger.error(f"生成失败: {e}，耗时: {duration:.2f}s")
        raise
```

### 2. 统计指标

```python
from collections import defaultdict
import time

class MetricsCollector:
    def __init__(self):
        self.requests = 0
        self.successes = 0
        self.failures = 0
        self.total_duration = 0
        self.errors_by_type = defaultdict(int)
    
    def record(self, success: bool, duration: float, error_type: str = None):
        self.requests += 1
        if success:
            self.successes += 1
        else:
            self.failures += 1
            if error_type:
                self.errors_by_type[error_type] += 1
        self.total_duration += duration
    
    @property
    def success_rate(self) -> float:
        if self.requests == 0:
            return 0
        return self.successes / self.requests
    
    @property
    def avg_duration(self) -> float:
        if self.requests == 0:
            return 0
        return self.total_duration / self.requests
    
    def report(self):
        return {
            "total_requests": self.requests,
            "successes": self.successes,
            "failures": self.failures,
            "success_rate": f"{self.success_rate:.1%}",
            "avg_duration": f"{self.avg_duration:.2f}s",
            "errors": dict(self.errors_by_type)
        }

# 使用
metrics = MetricsCollector()

for product in products:
    start = time.time()
    try:
        result = sdk.generate_listing(**product)
        metrics.record(True, time.time() - start)
    except Exception as e:
        metrics.record(False, time.time() - start, type(e).__name__)

print(metrics.report())
```

---

## 五、最佳实践总结

| 优化项 | 方法 | 预期提升 |
|--------|------|----------|
| **批量处理** | 每次10个产品 | 减少90%请求开销 |
| **并发控制** | 批量并发3-5 | 提速3-5倍 |
| **缓存复用** | 相似产品缓存 | 减少50% API调用 |
| **输入预处理** | 清理、格式化 | 提升20%成功率 |
| **重试机制** | 自动+手动重试 | 提升15%最终成功率 |
| **熔断器** | 防止雪崩 | 系统稳定性 |
| **监控告警** | 日志+指标 | 快速定位问题 |

---

## 六、快速开始代码

### Python 完整示例

```python
from mercadolibre_sdk import MercadoLibreSDK
import os

# 初始化SDK
API_URL = os.environ.get('MERCADO_LIBRE_API_URL', 'https://your-domain.com')
sdk = MercadoLibreSDK(
    base_url=API_URL,
    max_retries=3,
    retry_delay=1.0,
    timeout=60
)

# 准备产品列表
products = [
    {"productName": "Wireless Earbuds", "features": "Bluetooth 5.0, 24h battery", "language": "es"},
    {"productName": "Smart Watch", "features": "Heart rate monitor, waterproof", "language": "pt"},
    {"productName": "Portable Charger", "features": "20000mAh, fast charging", "language": "es"},
    # ... 更多产品
]

# 批量生成
print("开始批量生成...")
results = sdk.generate_batch(products, concurrency=3)

# 统计结果
success = sum(1 for r in results if r.success)
print(f"成功: {success}/{len(results)}")

# 保存结果
for i, result in enumerate(results):
    if result.success:
        print(f"产品{i+1}: {result.data.title_es}")
```

### TypeScript 完整示例

```typescript
import { MercadoLibreSDK } from './mercadolibre-sdk';

const sdk = new MercadoLibreSDK({
  baseUrl: 'https://your-domain.com',
  maxRetries: 3,
  timeout: 60000,
});

// 进度回调
sdk.onProgress((event) => {
  console.log(`进度: ${event.completed}/${event.total} (失败: ${event.failed})`);
});

// 批量生成
const products = [
  { productName: 'Wireless Earbuds', features: 'Bluetooth 5.0, 24h battery', language: 'es' },
  { productName: 'Smart Watch', features: 'Heart rate monitor', language: 'pt' },
];

const results = await sdk.generateBatch(products, { concurrency: 3 });

// 处理结果
results.forEach((result, index) => {
  if (result.success) {
    console.log(`产品${index + 1}: ${result.data?.title_es}`);
  } else {
    console.error(`产品${index + 1}失败: ${result.error}`);
  }
});
```

---

如有问题，请查看完整API文档或联系技术支持。
